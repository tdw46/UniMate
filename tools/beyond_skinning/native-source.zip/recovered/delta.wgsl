struct Params {
    n_words : u32,
    grid_x  : u32,
    tol     : f32,
    _pad1   : u32,
};
@group(0) @binding(0) var<storage, read>       a      : array<u32>;
@group(0) @binding(1) var<storage, read>       b      : array<u32>;
@group(0) @binding(2) var<storage, read_write> out    : array<atomic<u32>, 2>;
@group(0) @binding(3) var<uniform>             params : Params;
var<workgroup> wg_max : atomic<u32>;
var<workgroup> wg_cnt : atomic<u32>;
@compute @workgroup_size(256, 1, 1)
fn max_delta(
    @builtin(workgroup_id) wid : vec3<u32>,
    @builtin(local_invocation_id) lid : vec3<u32>,
) {
    if (lid.x == 0u) {
        atomicStore(&wg_max, 0u);
        atomicStore(&wg_cnt, 0u);
    }
    workgroupBarrier();
    let wg = wid.x + wid.y * params.grid_x;
    let tid = wg * 256u + lid.x;
    if (tid < params.n_words) {
        let pa = unpack2x16float(a[tid]);
        let pb = unpack2x16float(b[tid]);
        let dx = abs(pa.x - pb.x);
        let dy = abs(pa.y - pb.y);
        atomicMax(&wg_max, bitcast<u32>(max(dx, dy)));
        let moving = u32(dx > params.tol) + u32(dy > params.tol);
        if (moving != 0u) {
            atomicAdd(&wg_cnt, moving);
        }
    }
    workgroupBarrier();
    if (lid.x == 0u) {
        atomicMax(&out[0], atomicLoad(&wg_max));
        atomicAdd(&out[1], atomicLoad(&wg_cnt));
    }
}