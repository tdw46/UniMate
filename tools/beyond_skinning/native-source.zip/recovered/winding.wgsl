struct Node {
    cx: f32, cy: f32, cz: f32, r: f32,
    px: f32, py: f32, pz: f32,
    left: i32, right: i32,
    start: u32, end: u32,
    pad: u32,
};
struct Tri {
    ax: f32, ay: f32, az: f32,
    bx: f32, by: f32, bz: f32,
    cx: f32, cy: f32, cz: f32,
    p0: f32, p1: f32, p2: f32,
};
@group(0) @binding(0) var<storage, read> nodes: array<Node>;
@group(0) @binding(1) var<storage, read> tris: array<Tri>;
@group(0) @binding(2) var<storage, read> points: array<f32>;
@group(0) @binding(3) var<storage, read_write> out: array<f32>;
const FOUR_PI: f32 = 12.566370614359172;
const BETA: f32 = 2.0;
fn tri_solid_angle(q: vec3<f32>, t: Tri) -> f32 {
    let pa = vec3<f32>(t.ax, t.ay, t.az) - q;
    let pb = vec3<f32>(t.bx, t.by, t.bz) - q;
    let pc = vec3<f32>(t.cx, t.cy, t.cz) - q;
    let la = length(pa);
    let lb = length(pb);
    let lc = length(pc);
    let bc = cross(pb, pc);
    let num = dot(pa, bc);
    let denom = la * lb * lc + dot(pa, pb) * lc + dot(pb, pc) * la + dot(pc, pa) * lb;
    if (abs(denom) < 1e-12 && abs(num) < 1e-12) {
        return 0.0;
    }
    return 2.0 * atan2(num, denom);
}
@compute @workgroup_size(64)
fn main(
    @builtin(global_invocation_id) gid: vec3<u32>,
    @builtin(num_workgroups) nwg: vec3<u32>,
) {
    let i = gid.x + gid.y * nwg.x * 64u;
    let np = arrayLength(&out);
    if (i >= np) {
        return;
    }
    let q = vec3<f32>(points[3u * i], points[3u * i + 1u], points[3u * i + 2u]);
    var wn = 0.0;
    var stack: array<i32, 64>;
    var sp = 0;
    stack[0] = 0;
    sp = 1;
    loop {
        if (sp <= 0) {
            break;
        }
        sp = sp - 1;
        let ni = stack[sp];
        let nd = nodes[ni];
        let d = vec3<f32>(nd.cx, nd.cy, nd.cz) - q;
        let dist2 = dot(d, d);
        let thr = BETA * nd.r;
        if (dist2 > thr * thr) {
            let dist = sqrt(dist2);
            wn = wn + dot(vec3<f32>(nd.px, nd.py, nd.pz), d) / (dist2 * dist);
        } else if (nd.left < 0) {
            var t = nd.start;
            loop {
                if (t >= nd.end) {
                    break;
                }
                wn = wn + tri_solid_angle(q, tris[t]);
                t = t + 1u;
            }
        } else {
            if (sp < 63) {
                stack[sp] = nd.right;
                sp = sp + 1;
            }
            if (sp < 63) {
                stack[sp] = nd.left;
                sp = sp + 1;
            }
        }
    }
    out[i] = wn / FOUR_PI;
}