struct Params {
    n_bones    : u32,
    n_pts      : u32,
    grid_x     : u32,
    _pad0      : u32,
    omega      : f32,
    seed_words : u32,
    _pad2      : u32,
    _pad3      : u32,
};
@group(0) @binding(0) var<storage, read>       row_ptr        : array<u32>;
@group(0) @binding(1) var<storage, read>       col_idx        : array<u32>;
@group(0) @binding(2) var<storage, read>       weights        : array<f32>;
@group(0) @binding(3) var<storage, read>       d_inv          : array<f32>;
@group(0) @binding(4) var<storage, read>       dirichlet_mask : array<u32>;
@group(0) @binding(5) var<storage, read>       d_value        : array<u32>;
@group(0) @binding(6) var<storage, read>       w_in           : array<vec2<u32>>;
@group(0) @binding(7) var<storage, read_write> w_out          : array<vec2<u32>>;
@group(0) @binding(8) var<uniform>             params         : Params;
@compute @workgroup_size(256, 1, 1)
fn matvec_h(
    @builtin(workgroup_id) wid : vec3<u32>,
    @builtin(local_invocation_id) lid : vec3<u32>,
) {
    let wg = wid.x + wid.y * params.grid_x;
    let tid = wg * 256u + lid.x;
    let nb4 = params.n_bones / 4u;
    let total = params.n_pts * nb4;
    if (tid >= total) {
        return;
    }
    let i = tid / nb4;
    let c = tid % nb4;
    let cell0 = i * params.n_bones + c * 4u;
    let w0 = cell0 / 32u; let b0 = cell0 % 32u;
    let mbits = (dirichlet_mask[w0] >> b0) & 0xFu;
    if (mbits != 0u) {
        let dbits = (d_value[w0] >> b0) & 0xFu;
        var sv = 1.0;
        if (params.seed_words != 0u) {
            sv = unpack2x16float(d_value[params.seed_words + i / 2u])[i & 1u];
        }
        let lo = sv * vec2<f32>(f32(dbits & 1u), f32((dbits >> 1u) & 1u));
        let hi = sv * vec2<f32>(f32((dbits >> 2u) & 1u), f32((dbits >> 3u) & 1u));
        w_out[tid] = vec2<u32>(pack2x16float(lo), pack2x16float(hi));
        return;
    }
    let s = row_ptr[i];
    let e = row_ptr[i + 1u];
    if (s == e) {
        w_out[tid] = vec2<u32>(0u, 0u);
        return;
    }
    var acc = vec4<f32>(0.0);
    for (var k: u32 = s; k < e; k = k + 1u) {
        let packed = w_in[col_idx[k] * nb4 + c];
        let v = vec4<f32>(unpack2x16float(packed.x), unpack2x16float(packed.y));
        acc = acc + weights[k] * v;
    }
    var step = d_inv[i] * acc;
    if (params.omega != 1.0) {
        let prev_p = w_out[tid];
        let prev = vec4<f32>(unpack2x16float(prev_p.x), unpack2x16float(prev_p.y));
        step = params.omega * (step - prev) + prev;
    }
    w_out[tid] = vec2<u32>(pack2x16float(step.xy), pack2x16float(step.zw));
}