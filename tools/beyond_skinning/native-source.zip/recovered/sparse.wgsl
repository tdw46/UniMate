struct Params {
    n_pts   : u32,
    k       : u32,
    grid_x  : u32,
    mask_words : u32,
    omega   : f32,
    seed_words : u32,
    _pad2   : u32,
    _pad3   : u32,
};
@group(0) @binding(0) var<storage, read>       row_ptr   : array<u32>;
@group(0) @binding(1) var<storage, read>       col_idx   : array<u32>;
@group(0) @binding(2) var<storage, read>       weights   : array<f32>;
@group(0) @binding(3) var<storage, read>       d_inv     : array<f32>;
@group(0) @binding(4) var<storage, read>       bits      : array<u32>;
@group(0) @binding(5) var<storage, read>       edge_map  : array<u32>;
@group(0) @binding(6) var<storage, read>       w_in      : array<vec4<u32>>;
@group(0) @binding(7) var<storage, read_write> w_out     : array<u32>;
@group(0) @binding(8) var<uniform>             params    : Params;
fn row_slot(r0: vec4<u32>, r1: vec4<u32>, m: u32) -> f32 {
    let w = m >> 1u;
    let v = select(r0, r1, w >= 4u);
    return unpack2x16float(v[w & 3u])[m & 1u];
}
@compute @workgroup_size(256, 1, 1)
fn matvec_sparse(
    @builtin(workgroup_id) wid : vec3<u32>,
    @builtin(local_invocation_id) lid : vec3<u32>,
) {
    let wg = wid.x + wid.y * params.grid_x;
    let tid = wg * 256u + lid.x;
    let k = params.k;
    let kp = k / 2u;
    let total = params.n_pts * kp;
    if (tid >= total) {
        return;
    }
    let i = tid / kp;
    let sp = tid % kp;
    let s0 = sp * 2u;
    let cell0 = i * k + s0;
    let masked = ((bits[i / 32u] >> (i % 32u)) & 1u) != 0u;
    var sv = 1.0;
    if (masked && params.seed_words != 0u) {
        sv = unpack2x16float(bits[params.seed_words + i / 2u])[i & 1u];
    }
    if (masked) {
        let mw = params.mask_words;
        let d0 = sv * f32((bits[mw + cell0 / 32u] >> (cell0 % 32u)) & 1u);
        let c1 = cell0 + 1u;
        let d1 = sv * f32((bits[mw + c1 / 32u] >> (c1 % 32u)) & 1u);
        w_out[tid] = pack2x16float(vec2<f32>(d0, d1));
        return;
    }
    let e0 = row_ptr[i];
    let e1 = row_ptr[i + 1u];
    if (e0 == e1) {
        w_out[tid] = 0u;
        return;
    }
    var acc0 = 0.0;
    var acc1 = 0.0;
    for (var e: u32 = e0; e < e1; e = e + 1u) {
        let wgt = weights[e];
        let j = col_idx[e];
        let r0 = w_in[j * 2u];
        let r1 = w_in[j * 2u + 1u];
        let b0 = e * k + s0;
        let em = edge_map[b0 / 4u] >> ((b0 % 4u) * 8u);
        let m0 = em & 0xFFu;
        if (m0 != 0xFFu) {
            acc0 = acc0 + wgt * row_slot(r0, r1, m0);
        }
        let m1 = (em >> 8u) & 0xFFu;
        if (m1 != 0xFFu) {
            acc1 = acc1 + wgt * row_slot(r0, r1, m1);
        }
    }
    let dinv = d_inv[i];
    var o0 = dinv * acc0;
    var o1 = dinv * acc1;
    if (params.omega != 1.0) {
        let prev = unpack2x16float(w_out[tid]);
        o0 = params.omega * (o0 - prev.x) + prev.x;
        o1 = params.omega * (o1 - prev.y) + prev.y;
    }
    w_out[tid] = pack2x16float(vec2<f32>(o0, o1));
}