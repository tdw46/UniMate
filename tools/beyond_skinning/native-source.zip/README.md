# BVT Solver native build

Source from preparation-217, with only the module name and Python callback
namespaces changed. Python orchestration ships next to this archive.

Use Rust 1.98.0, the committed Cargo.lock and CPython 3.11+.
Set PYO3_PYTHON to the build interpreter. Run cargo build --release --locked
in reconstruction/runtime; use --no-default-features for the CPU artifact.
Set CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS=true and
CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS=true to match qualified arithmetic.
The extension module entry point is _bvt_solver (abi3-py311).

On Windows, apply windows-adapter.patch from the archive root first.
This retains the qualified Vulkan adapter policy. Rebuild and qualify on the
actual OS/architecture; compilation alone does not establish output parity.
Update the package manifest with newly qualified hashes, not arbitrary binaries.
