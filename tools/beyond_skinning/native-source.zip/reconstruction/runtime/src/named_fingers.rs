//! Typed standalone name detector entry; independent mapping remains shared Python.
use pyo3::prelude::*;
use numpy::{PyReadonlyArray1,PyArrayMethods,PyUntypedArrayMethods};
#[pyfunction]
#[pyo3(signature=(names,parent_idx,deform=None))]
pub fn detect_fingers_by_name(py:Python<'_>,names:Vec<String>,parent_idx:PyReadonlyArray1<'_,i64>,deform:Option<PyReadonlyArray1<'_,bool>>)->PyResult<Py<PyAny>> {
 let p=crate::array_input::owned_one(&parent_idx).to_vec();
 let d=deform.map(|x|(0..x.len()).map(|i|unsafe{x.data().cast::<u8>().offset(i as isize*x.strides()[0]).read()&1!=0}).collect::<Vec<_>>());
 let names=names.iter().map(|n|n.split_once(':').map_or(n.as_str(),|(_,r)|r).trim().to_lowercase()).collect::<Vec<_>>();
 py.import("beyond_skinning.rig_mapping")?.getattr("_public_named_fingers")?.call1((names,p,d)).map(Bound::unbind)
}
