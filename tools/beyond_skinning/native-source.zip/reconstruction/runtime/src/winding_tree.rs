//! Independent mesh-to-winding-tree reconstruction, native 0xd9810/0x16d4a0.
//! This is a preprocessing component, not the complete cloud generator.
use numpy::PyReadonlyArray2;
use rayon::prelude::*;
use pyo3::{prelude::*, exceptions::PyValueError, types::PyBytes};
use crate::types::{WindingNode, WindingTriangle};
use crate::types::CapturedWindingTriangle as Triangle;
#[derive(Clone)]
pub(crate) struct Node { start:usize,end:usize,center:[f32;3],area:[f32;3],radius:f32,left:i32,right:i32 }
fn norm(p:[f32;3])->f32 { ((p[0]*p[0]+p[1]*p[1])+p[2]*p[2]).sqrt() }
fn delta(a:[f32;3],b:[f32;3])->[f32;3] {std::array::from_fn(|k|a[k]-b[k])}
fn branch(tris:&mut [Triangle], nodes:&mut Vec<Node>,start:usize,end:usize)->usize {
    let mut area=[0.0f32;3]; let mut weighted=[0.0f32;3]; let mut total=0.0f32;
    for t in &tris[start..end] {
        for k in 0..3 {area[k]=t.area[k]+area[k];}
        let a=norm(t.area); total=total+a;
        for k in 0..3 {weighted[k]=weighted[k]+t.center[k]*a;}
    }
    let center=if !(total>1e-20) {
        let mut sum=[0.0f32;3];
        for t in &tris[start..end] {for k in 0..3 {sum[k]=sum[k]+t.center[k];}}
        sum.map(|x|x/(end-start) as f32)
    } else {let inverse=1.0/total; weighted.map(|x|x*inverse)};
    let mut radius=0.0f32;
    for t in &tris[start..end] { let r=t.radius+norm(delta(t.center,center)); if r>radius {radius=r;} }
    let index=nodes.len(); nodes.push(Node{start,end,center,area,radius,left:-1,right:-1});
    if end-start>16 {
        let mut lo=[f32::INFINITY;3]; let mut hi=[f32::NEG_INFINITY;3];
        for t in &tris[start..end] {for k in 0..3 {lo[k]=lo[k].min(t.center[k]); hi[k]=hi[k].max(t.center[k]);}}
        let ext=std::array::from_fn::<_,3,_>(|k|hi[k]-lo[k]);
        let axis=if ext[0]>=ext[1] && ext[0]>=ext[2] {0} else if ext[1]>=ext[2] {1} else {2};
        let mid=(end-start)/2;
        tris[start..end].select_nth_unstable_by(mid,|a,b|a.center[axis].partial_cmp(&b.center[axis]).unwrap_or(std::cmp::Ordering::Equal));
        let left=branch(tris,nodes,start,start+mid);
        let right=branch(tris,nodes,start+mid,end);
        nodes[index].left=left as i32; nodes[index].right=right as i32;
    }
    index
}
pub(crate) fn owned_tree(py:Python<'_>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>)->PyResult<(Vec<Triangle>,Vec<Node>)>{
    let v=vertices.as_array(); let f=faces.as_array();
    if v.ncols()!=3 || f.ncols()!=3 || f.iter().any(|&i|i<0 || i as usize>=v.nrows()) {return Err(PyValueError::new_err("expected finite Nx3 vertices and valid Mx3 triangle indices"));}
    let mut tris=Vec::with_capacity(f.nrows());
    for face in f.rows() {
        let points=std::array::from_fn::<_,3,_>(|j|std::array::from_fn(|k|v[[face[j] as usize,k]]));
        let center=std::array::from_fn(|k|((points[0][k]+points[1][k])+points[2][k])/3.0);
        let b=delta(points[1],points[0]); let c=delta(points[2],points[0]);
        let area=[(c[2]*b[1]-c[1]*b[2])*0.5,(b[2]*c[0]-b[0]*c[2])*0.5,(b[0]*c[1]-b[1]*c[0])*0.5];
        let mut radius=norm(delta(points[0],center)); if !(0.0<radius) {radius=0.0;}
        for p in &points[1..] {let r=norm(delta(*p,center)); if !(r<radius) {radius=r;}}
        tris.push(Triangle{points,center,area,radius});
    }
    let mut nodes=Vec::new(); let n=tris.len(); if n>0 {py.allow_threads(||branch(&mut tris,&mut nodes,0,n));}
    Ok((tris,nodes))
}
#[pyfunction]
pub fn build_winding_tree<'py>(py:Python<'py>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>)->PyResult<Vec<Bound<'py,PyBytes>>>{
    let (tris,nodes)=owned_tree(py,vertices,faces)?;
    // Native node's last four bytes are uninitialized alignment padding. Exclude
    // those bytes from the semantic comparison and zero all GPU padding.
    let mut host_nodes=Vec::new(); let mut gpu_nodes=Vec::new();
    for node in nodes {
        host_nodes.extend_from_slice(&(node.start as u64).to_le_bytes()); host_nodes.extend_from_slice(&(node.end as u64).to_le_bytes());
        for x in node.center.into_iter().chain(node.area).chain([node.radius]) {host_nodes.extend_from_slice(&x.to_le_bytes());}
        host_nodes.extend_from_slice(&node.left.to_le_bytes()); host_nodes.extend_from_slice(&node.right.to_le_bytes());
        gpu_nodes.push(WindingNode{center:node.center,radius:node.radius,area_vector:node.area,left:node.left,right:node.right,start:node.start as u32,end:node.end as u32,pad:0});
    }
    let gpu_tris:Vec<_>=tris.iter().map(|t|WindingTriangle{a:t.points[0],b:t.points[1],c:t.points[2],pad:[0.0;3]}).collect();
    Ok(vec![PyBytes::new(py,bytemuck::cast_slice(&tris)),PyBytes::new(py,&host_nodes),PyBytes::new(py,bytemuck::cast_slice(&gpu_nodes)),PyBytes::new(py,bytemuck::cast_slice(&gpu_tris))])
}

#[cfg(feature="gpu")]
#[pyfunction]
pub fn winding_values<'py>(py:Python<'py>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,queries:PyReadonlyArray2<'_,f32>)->PyResult<Bound<'py,PyBytes>> {
    let q=queries.as_array();
    if q.ncols()!=3 || q.iter().any(|x|!x.is_finite()){return Err(PyValueError::new_err("expected finite Nx3 query positions"));}
    let points:Vec<f32>=q.rows().into_iter().flat_map(|r|[r[0],r[1],r[2]]).collect();
    let buffers=build_winding_tree(py,vertices,faces)?;
    let nodes=buffers[2].as_bytes().to_vec();let triangles=buffers[3].as_bytes().to_vec();
    let result=py.allow_threads(||crate::gpu::winding(&nodes,&triangles,bytemuck::cast_slice(&points))).map_err(PyValueError::new_err)?;
    Ok(PyBytes::new(py,&result))
}

// The Windows oracle imports UCRT atan2f. MinGW's static fallback is
// substantially slower on the paired runner. Import the OS math entrypoint
// directly; preserve the native platform implementation everywhere else.
#[cfg(target_os="windows")]
#[link(name="ucrtbase", kind="raw-dylib")]
extern "C" { #[link_name="atan2f"] fn ucrt_atan2f(y:f32,x:f32)->f32; }
#[inline]
fn platform_atan2(y:f32,x:f32)->f32 {
 #[cfg(target_os="windows")] { unsafe { ucrt_atan2f(y,x) } }
 #[cfg(not(target_os="windows"))] { y.atan2(x) }
}

fn dot(a:[f32;3],b:[f32;3])->f32{(a[0]*b[0]+a[1]*b[1])+a[2]*b[2]}
pub(crate) fn solid_angle(tris:&[Triangle],nodes:&[Node],i:usize,q:[f32;3])->f32{
 let nd=&nodes[i];let d=delta(nd.center,q);let dist2=dot(d,d);let threshold=nd.radius+nd.radius;
 if !(dist2<=threshold*threshold){return dot(d,nd.area)/(dist2*dist2.sqrt());}
 if nd.left>=0{return solid_angle(tris,nodes,nd.left as usize,q)+solid_angle(tris,nodes,nd.right as usize,q);}
 let mut sum=0.0f32;
 for t in &tris[nd.start..nd.end]{
  let a=delta(t.points[0],q);let b=delta(t.points[1],q);let c=delta(t.points[2],q);
  let la=norm(a);let lb=norm(b);let lc=norm(c);
  let num=a[2]*(b[0]*c[1]-b[1]*c[0])+(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2]));
  let den=lb*dot(a,c)+(la*dot(b,c)+(la*lb*lc+dot(a,b)*lc));
  let angle=if den.abs()<1e-12 && num.abs()<1e-12{0.0}else{let x=platform_atan2(num,den);x+x};sum=sum+angle;
 }sum
}
// Four independent queries share traversal and vectorizable arithmetic. The
// tree, each triangle's expression order, and left+right reduction are unchanged.
type Four=[f32;4];
// Explicit baseline SIMD avoids scalarization across recursive packet calls.
// No fused arithmetic, reciprocal approximations, or horizontal reductions.
#[inline(always)] fn add4(a:Four,b:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vaddq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_add_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]+b[i])}
}
#[inline(always)] fn sub4(a:Four,b:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vsubq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_sub_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]-b[i])}
}
#[inline(always)] fn mul4(a:Four,b:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vmulq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_mul_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]*b[i])}
}
#[inline(always)] fn div4(a:Four,b:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vdivq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_div_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]/b[i])}
}
#[inline(always)] fn sqrt4(a:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vsqrtq_f32(std::mem::transmute(a)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_sqrt_ps(std::mem::transmute(a)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {a.map(f32::sqrt)}
}
#[inline(always)] fn dot4(a:[Four;3],b:[Four;3])->Four{add4(add4(mul4(a[0],b[0]),mul4(a[1],b[1])),mul4(a[2],b[2]))}
#[inline(always)] fn delta4(a:[f32;3],q:&[Four;3])->[Four;3]{std::array::from_fn(|k|sub4([a[k];4],q[k]))}
fn solid_angles4(tris:&[Triangle],nodes:&[Node],index:usize,q:&[Four;3],active:u8)->Four{
 // A packet with one surviving lane has no shared traversal left. Use the
 // same scalar recurrence instead of carrying three inactive lanes recursively.
 if active.is_power_of_two(){
  let lane=active.trailing_zeros() as usize;let mut output=[0.0;4];
  output[lane]=solid_angle(tris,nodes,index,[q[0][lane],q[1][lane],q[2][lane]]);
  return output;
 }
 let nd=&nodes[index];let d=delta4(nd.center,q);let dist2=dot4(d,d);let threshold=nd.radius+nd.radius;
 // Derive the same ordered comparison mask directly on SSE. Passing the
 // immutable packet by reference also avoids copying it at each recursive call.
 #[cfg(target_arch="x86_64")]
 let near=unsafe {use std::arch::x86_64::*;(_mm_movemask_ps(_mm_cmple_ps(std::mem::transmute(dist2),_mm_set1_ps(threshold*threshold))) as u8)&active};
 #[cfg(not(target_arch="x86_64"))]
 let near={let mut mask=0u8;for lane in 0..4{if active&(1<<lane)!=0 && dist2[lane]<=threshold*threshold{mask|=1<<lane;}}mask};
 let mut output=[0.0f32;4];
 if near!=active{
  let value=div4(dot4(d,nd.area.map(|x|[x;4])),mul4(dist2,sqrt4(dist2)));
  for lane in 0..4{if active&(1<<lane)!=0 && near&(1<<lane)==0{output[lane]=value[lane];}}
 }
 if near==0{return output;}
 if nd.left>=0{
  let left=solid_angles4(tris,nodes,nd.left as usize,q,near);
  let right=solid_angles4(tris,nodes,nd.right as usize,q,near);
  for lane in 0..4{if near&(1<<lane)!=0{output[lane]=left[lane]+right[lane];}}
  return output;
 }
 let mut sum=[0.0f32;4];
 for t in &tris[nd.start..nd.end]{
  let a=delta4(t.points[0],q);let b=delta4(t.points[1],q);let c=delta4(t.points[2],q);
  let la=sqrt4(dot4(a,a));let lb=sqrt4(dot4(b,b));let lc=sqrt4(dot4(c,c));
  let num=add4(mul4(a[2],sub4(mul4(b[0],c[1]),mul4(b[1],c[0]))),add4(mul4(a[0],sub4(mul4(b[1],c[2]),mul4(b[2],c[1]))),mul4(a[1],sub4(mul4(b[2],c[0]),mul4(b[0],c[2])))));
  let den=add4(mul4(lb,dot4(a,c)),add4(mul4(la,dot4(b,c)),add4(mul4(mul4(la,lb),lc),mul4(dot4(a,b),lc))));
  for lane in 0..4{if near&(1<<lane)==0{continue;}
   let angle=if den[lane].abs()<1e-12 && num[lane].abs()<1e-12{0.0}else{let x=platform_atan2(num[lane],den[lane]);x+x};
   sum[lane]=sum[lane]+angle;
  }
 }
 for lane in 0..4{if near&(1<<lane)!=0{output[lane]=sum[lane];}}
 output
}
fn query_tree(tris:&[Triangle],nodes:&[Node],points:&[[f32;3]])->Vec<f32>{
 let mut result=vec![0.0f32;points.len()];
 if nodes.is_empty(){return result;}
 // Spatially coherent packets share more traversal. Sorting is confined to
 // 256 independent queries in stack scratch; scatter restores original order.
 // No per-query arithmetic, tree or left/right reduction is changed.
 result.par_chunks_mut(256).zip(points.par_chunks(256)).for_each(|(out,points)|{
  let n=points.len();let mut order=[(0u32,0u16);256];
  for i in 0..n{order[i].1=i as u16;}
  if n>=32 {
   let mut lo=[f32::INFINITY;3];let mut hi=[f32::NEG_INFINITY;3];
   for p in points{for k in 0..3{lo[k]=lo[k].min(p[k]);hi[k]=hi[k].max(p[k]);}}
   fn spread(mut x:u32)->u32{x&=0x3ff;x=(x|(x<<16))&0x030000ff;x=(x|(x<<8))&0x0300f00f;x=(x|(x<<4))&0x030c30c3;(x|(x<<2))&0x09249249}
   let scale=std::array::from_fn::<_,3,_>(|k|{let extent=hi[k] as f64-lo[k] as f64;if extent>0.0{1023.0/extent}else{0.0}});
   for i in 0..n{let xyz=std::array::from_fn::<_,3,_>(|k|(((points[i][k] as f64-lo[k] as f64)*scale[k]) as u32).min(1023));order[i].0=spread(xyz[0])|(spread(xyz[1])<<1)|(spread(xyz[2])<<2);}
   order[..n].sort_unstable();
  }
  for packet in order[..n].chunks(4){
   if packet.len()<4{for &(_,i) in packet{out[i as usize]=solid_angle(tris,nodes,0,points[i as usize]);}continue;}
   let q=std::array::from_fn(|k|std::array::from_fn(|lane|points[packet[lane].1 as usize][k]));
   let values=solid_angles4(tris,nodes,0,&q,15);
   for lane in 0..4{out[packet[lane].1 as usize]=values[lane];}
  }
 });result
}
/// Native CPU tree query returns solid angles before the caller's 4*pi division.
#[pyfunction]
pub fn winding_solid_angles_cpu<'py>(py:Python<'py>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,queries:PyReadonlyArray2<'_,f32>)->PyResult<Bound<'py,PyBytes>>{
 let q=queries.as_array();if q.ncols()!=3 || q.iter().any(|x|!x.is_finite()){return Err(PyValueError::new_err("expected finite Nx3 query positions"));}
 let points:Vec<[f32;3]>=q.rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect();let (tris,nodes)=owned_tree(py,vertices,faces)?;
 let result:Vec<f32>=py.allow_threads(||query_tree(&tris,&nodes,&points));
 Ok(PyBytes::new(py,bytemuck::cast_slice(&result)))
}

/// A single detector owns this immutable snapshot; no process-global mesh cache.
/// Private preparation shares the original branch builder and query recurrence.
#[pyclass(module="_bvt_solver", frozen)]
pub struct _WindingQuery { triangles:Vec<Triangle>, nodes:Vec<Node> }
#[pymethods]
impl _WindingQuery {
 #[new]
 fn new(py:Python<'_>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>)->PyResult<Self>{
  let (triangles,nodes)=owned_tree(py,vertices,faces)?;
  Ok(Self{triangles,nodes})
 }
 fn query<'py>(&self,py:Python<'py>,queries:PyReadonlyArray2<'_,f32>)->PyResult<Bound<'py,PyBytes>>{
  let q=queries.as_array();
  if q.ncols()!=3 || q.iter().any(|x|!x.is_finite()){return Err(PyValueError::new_err("expected finite Nx3 query positions"));}
  let points:Vec<[f32;3]>=q.rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect();
  let result:Vec<f32>=py.allow_threads(||query_tree(&self.triangles,&self.nodes,&points));
  Ok(PyBytes::new(py,bytemuck::cast_slice(&result)))
 }
 fn owned_bytes(&self)->usize{
  self.triangles.capacity()*std::mem::size_of::<Triangle>()+self.nodes.capacity()*std::mem::size_of::<Node>()
 }
}

/// Packed geometry and its GPU lease live only for the owning detector.
#[cfg(feature="gpu")]
#[pyclass(module="_bvt_solver",frozen)]
pub struct _PreparedGpuWinding {
 nodes:Vec<WindingNode>,triangles:Vec<WindingTriangle>,
 prepared:std::sync::Mutex<Option<crate::gpu::PreparedWinding>>,
}
#[cfg(feature="gpu")]
#[pymethods]
impl _PreparedGpuWinding {
 #[new]
 fn new(py:Python<'_>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>)->PyResult<Self>{
  let (tris,nodes)=owned_tree(py,vertices,faces)?;
  let nodes=nodes.into_iter().map(|n|WindingNode{center:n.center,radius:n.radius,area_vector:n.area,left:n.left,right:n.right,start:n.start as u32,end:n.end as u32,pad:0}).collect();
  let triangles=tris.into_iter().map(|t|WindingTriangle{a:t.points[0],b:t.points[1],c:t.points[2],pad:[0.0;3]}).collect();
  Ok(Self{nodes,triangles,prepared:std::sync::Mutex::new(None)})
 }
 fn query<'py>(&self,py:Python<'py>,queries:PyReadonlyArray2<'_,f32>)->PyResult<Bound<'py,PyBytes>>{
  let q=queries.as_array();
  if q.ncols()!=3 || q.iter().any(|x|!x.is_finite()){return Err(PyValueError::new_err("expected finite Nx3 query positions"));}
  let points:Vec<[f32;3]>=q.rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect();
  if self.nodes.is_empty() || points.is_empty(){return Ok(PyBytes::new(py,&vec![0u8;points.len()*4]));}
  let result=py.allow_threads(||{
   let mut guard=self.prepared.lock().unwrap_or_else(|e|e.into_inner());
   if guard.as_ref().is_some_and(|p|!p.healthy()){*guard=None;}
   if guard.is_none(){*guard=Some(crate::gpu::PreparedWinding::new(bytemuck::cast_slice(&self.nodes),bytemuck::cast_slice(&self.triangles))?);}
   guard.as_ref().unwrap().query(bytemuck::cast_slice(&points))
  }).map_err(PyValueError::new_err)?;
  Ok(PyBytes::new(py,&result))
 }
}
