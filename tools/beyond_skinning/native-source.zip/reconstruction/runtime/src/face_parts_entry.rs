//! Owned typed input boundary for the public face planner.
use pyo3::prelude::*;
use pyo3::types::PyList;
use numpy::{IntoPyArray,PyReadonlyArray1,PyReadonlyArray2,PyReadonlyArray3,PyArrayMethods,PyUntypedArrayMethods};
type Mesh<'a>=(String,PyReadonlyArray2<'a,f32>,PyReadonlyArray2<'a,f32>,PyReadonlyArray2<'a,f64>,PyReadonlyArray2<'a,i64>,PyReadonlyArray2<'a,i64>);
#[pyfunction]
#[pyo3(signature=(names,parent_idx,deform,segments,meshes,keep=None))]
pub fn plan_face_parts(py:Python<'_>,names:Vec<String>,parent_idx:PyReadonlyArray1<'_,i64>,deform:PyReadonlyArray1<'_,bool>,segments:PyReadonlyArray3<'_,f32>,meshes:Vec<Mesh<'_>>,keep:Option<Vec<String>>)->PyResult<Py<PyAny>> {
 if parent_idx.len()!=names.len()||deform.len()!=names.len()||segments.shape()!=[names.len(),2,3]{return Err(pyo3::exceptions::PyValueError::new_err("names, parent_idx, deform and segments (N, 2, 3) must share length"));}
 let inputs=PyList::empty(py);
 for (name,v,b,m,e,f) in meshes {
  if v.shape()[1]!=3||b.shape()[1]!=3||m.shape()!=[4,4]||e.shape()[1]!=2||f.shape()[1]!=3{return Err(pyo3::exceptions::PyValueError::new_err("mesh part: vertices must be (N, 3), the matrix (4, 4), the edges (M, 2), the triangles (T, 3)"));}
  inputs.append((name,crate::array_input::owned_two(&v).into_pyarray(py),crate::array_input::owned_two(&b).into_pyarray(py),crate::array_input::owned_two(&m).into_pyarray(py),crate::array_input::owned_two(&e).into_pyarray(py),crate::array_input::owned_two(&f).into_pyarray(py)))?;
 }
 let p=crate::array_input::owned_one(&parent_idx).into_pyarray(py);
 let d=(0..deform.len()).map(|i|unsafe{deform.data().cast::<u8>().offset(i as isize*deform.strides()[0]).read()}).collect::<Vec<_>>();
 let s=crate::array_input::owned_three(&segments).into_pyarray(py);
 py.import("beyond_skinning.face_parts_public")?.getattr("assemble")?.call1((names,p,d,s,inputs,keep)).map(Bound::unbind)
}
