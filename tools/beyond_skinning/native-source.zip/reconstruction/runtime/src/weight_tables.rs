//! Bounded facial table consumers. No entropy, shared cache or GIL release.
use pyo3::{prelude::*,types::PyList,exceptions::PyValueError};
use numpy::{PyReadonlyArray1,PyReadonlyArray2,PyArray2};
use std::{collections::HashSet,hash::BuildHasherDefault};
type IdSet=HashSet<i32,BuildHasherDefault<rustc_hash::FxHasher>>;
#[pyfunction]
pub fn weight_adjacency(n:usize,edges:PyReadonlyArray2<'_,i64>)->PyResult<Vec<Vec<usize>>>{
 let e=crate::array_input::two(&edges);
 if e.ncols()!=2{return Err(PyValueError::new_err("weight adjacency shape mismatch"));}
 let mut adj=vec![Vec::new();n];
 for edge in e.rows(){let (a,b)=(edge[0],edge[1]);
  if a>=0&&b>=0&&(a as usize)<n&&(b as usize)<n&&a!=b{adj[a as usize].push(b as usize);adj[b as usize].push(a as usize);}
 }
 Ok(adj)
}
#[pyfunction]
pub fn weight_component_entries(weights:PyReadonlyArray2<'_,f32>,bones:PyReadonlyArray2<'_,i32>,adj:&Bound<'_,PyList>,selected:PyReadonlyArray1<'_,bool>)->PyResult<usize>{
 let w=crate::array_input::two(&weights);let b=crate::array_input::two(&bones);let m=crate::array_input::one(&selected);let n=w.nrows();
 if b.dim()!=w.dim()||adj.len()!=n||m.len()!=n{return Err(PyValueError::new_err("weight component shape mismatch"));}
 let mut visited=vec![false;n];let mut total=0usize;
 for start in 0..n {
  if visited[start]{continue;}visited[start]=true;let mut stack=vec![start];let mut owners=IdSet::default();let mut chosen=0usize;let mut unchanged=0usize;
  while let Some(i)=stack.pop(){
   let mut local=IdSet::default();for j in 0..w.ncols(){if b[(i,j)]>=0&&w[(i,j)]>0.0{local.insert(b[(i,j)]);}}
   owners.extend(local.iter().copied());if m[i]{chosen+=1;}else{unchanged+=local.len();}
   let neighbors=adj.get_item(i)?.downcast_into::<PyList>()?;
   for j in neighbors.iter(){let j=j.extract::<usize>()?;if j>=n{return Err(PyValueError::new_err("weight component neighbor outside rows"));}
    if !visited[j]{visited[j]=true;stack.push(j);}
   }
  }
  total=chosen.checked_mul(owners.len()).and_then(|v|v.checked_add(unchanged)).and_then(|v|total.checked_add(v)).ok_or_else(||PyValueError::new_err("weight component count overflow"))?;
 }
 Ok(total)
}
#[pyfunction]
pub fn weight_finalize_tables<'py>(py:Python<'py>,weights:PyReadonlyArray2<'py,f32>,bones:PyReadonlyArray2<'py,i32>,rows:&Bound<'py,PyList>,selected:PyReadonlyArray1<'py,bool>,top_k:usize,nonfinite:&Bound<'py,PyAny>)->PyResult<(Bound<'py,PyArray2<f32>>,Bound<'py,PyArray2<i32>>)>{
 let w=crate::array_input::two(&weights);let b=crate::array_input::two(&bones);let m=crate::array_input::one(&selected);let (n,k)=w.dim();
 if b.dim()!=w.dim()||rows.len()!=n||m.len()!=n||top_k>k{return Err(PyValueError::new_err("invalid prepared weight rows"));}
 let mut ow=ndarray::Array2::from_shape_fn((n,k),|ij|w[ij]);let mut ob=ndarray::Array2::from_shape_fn((n,k),|ij|b[ij]);
 for i in 0..n {
  if !m[i]{continue;}
  let slots=rows.get_item(i)?.getattr("slots")?.downcast_into::<PyList>()?;
  let mut pairs=Vec::<(i32,f32)>::new();let mut total=-0.0f32;let mut finite=true;
  for slot in slots.iter(){if !slot.is_none(){let pair=slot.extract::<(i32,f32)>()?;total+=pair.1;finite &= pair.1.is_finite();pairs.push(pair);}}
  if !finite||!total.is_finite(){
   // Preserve Python's non-total NaN comparator and exact scalar normalization.
   pairs=nonfinite.call1((pairs,top_k))?.extract()?;
  }else{
   if total>0.0{for pair in &mut pairs{pair.1/=total;}}
   pairs.sort_by(|a,b|b.1.partial_cmp(&a.1).unwrap().then_with(||b.0.cmp(&a.0)));
   pairs.truncate(top_k);
  }
  for j in 0..k{ow[(i,j)]=0.0;ob[(i,j)]=-1;}
  for (j,(id,v)) in pairs.into_iter().take(top_k).enumerate(){ob[(i,j)]=id;ow[(i,j)]=v;}
 }
 Ok((PyArray2::from_owned_array(py,ow),PyArray2::from_owned_array(py,ob)))
}
