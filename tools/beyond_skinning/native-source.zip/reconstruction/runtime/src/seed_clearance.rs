//! Clearance predicate 0x1978d0, over finite bounded point clouds.
//! Direct segment queries replace the native grid acceleration without changing
//! its inclusive f32 predicate. This is a research route, not a production index.
use numpy::PyReadonlyArray2;
use pyo3::{prelude::*,exceptions::PyValueError};
#[pyfunction]
pub fn seed_bone_clearance(points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,step:f32)->PyResult<Vec<u8>>{
 let p=points.as_array();let h=heads.as_array();let t=tails.as_array();
 if p.ncols()!=3 || h.ncols()!=3 || h.shape()!=t.shape() || p.nrows()==0 || p.nrows().saturating_mul(h.nrows())>4_000_000 || !step.is_finite() || step<=0.0 || p.iter().chain(h.iter()).chain(t.iter()).any(|v|!v.is_finite()) {return Err(PyValueError::new_err("invalid or oversized research clearance inputs"));}
 let threshold=step*step;
 Ok((0..h.nrows()).map(|i|{
  let d:[f32;3]=std::array::from_fn(|k|t[[i,k]]-h[[i,k]]);
  let l=(d[0]*d[0]+d[1]*d[1])+d[2]*d[2];
  for v in p.rows(){
   let q:[f32;3]=std::array::from_fn(|k|v[k]-h[[i,k]]);
   let f=if l<=1e-12 {0.0}else{(((d[0]*q[0]+d[1]*q[1])+d[2]*q[2])/l).max(0.0).min(1.0)};
   let e:[f32;3]=std::array::from_fn(|k|q[k]-d[k]*f);
   if e[2]*e[2]+(e[0]*e[0]+e[1]*e[1])<=threshold{return 0;}
  }1
 }).collect())
}
