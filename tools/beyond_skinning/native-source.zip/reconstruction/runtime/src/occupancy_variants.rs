//! Owned occupancy variants used by sampling. Dense bit storage, sparse membership,
//! and implicit one-cell dilation share the native three-probe semantics.
use rustc_hash::FxHashSet;
use pyo3::{prelude::*,exceptions::{PyValueError,PyMemoryError}};
type DenseInput=([f32;3],f32,f32,[i32;3],[i64;3],Vec<u64>,[i32;3],[i64;3],Vec<u64>);
#[derive(FromPyObject)]
pub enum SetInput {Dense(u8,[i32;3],[i64;3],Vec<u64>),Sparse(u8,Vec<[i32;3]>)}
#[derive(FromPyObject)]
pub enum LevelInput {
 #[pyo3(transparent)] Dense(DenseInput),
 General([f32;3],f32,f32,SetInput,Option<SetInput>),
}
enum VoxelSet {Dense([i32;3],[i64;3],Vec<u64>),Sparse(FxHashSet<[i32;3]>)}
impl VoxelSet {
 fn parse(input:SetInput)->PyResult<Self>{match input{
  SetInput::Dense(0,min,dims,bits)=>{let cells=dims.iter().try_fold(1usize,|a,&b|if b>0{a.checked_mul(b as usize)}else{None});if cells.is_none_or(|n|n>16_000_000 || (n+63)/64!=bits.len()){return Err(PyValueError::new_err("invalid dense occupancy storage"));}Ok(Self::Dense(min,dims,bits))},
  SetInput::Sparse(1,points)=>{let mut unique=FxHashSet::default();
   for (index,point) in points.into_iter().enumerate() {
    if index%1024==0 {crate::cancel::check();}
    if !unique.contains(&point) {
     unique.try_reserve(1).map_err(|_|PyMemoryError::new_err("sparse occupancy allocation failed"))?;
     unique.insert(point);
    }
   }
   Ok(Self::Sparse(unique))},
  _=>Err(PyValueError::new_err("invalid occupancy variant tag")),
 }}
 fn contains(&self,xyz:[i32;3])->bool{match self{
  Self::Sparse(points)=>points.contains(&xyz),
  Self::Dense(min,dims,bits)=>{let c=std::array::from_fn::<_,3,_>(|i|xyz[i] as i64-min[i] as i64);if (0..3).any(|i|c[i]<0 || c[i]>=dims[i]){return false;}let key=(c[0]+(c[1]+c[2]*dims[1])*dims[0]) as usize;bits[key/64]>>(key%64)&1!=0}
 }}
}
pub struct Level {pub origin:[f32;3],pub inverse:f32,pub cell:f32,solid:VoxelSet,dilated:Option<VoxelSet>}
impl Level {
 pub fn solid(&self,xyz:[i32;3])->bool{self.solid.contains(xyz)}
 pub fn dilated(&self,xyz:[i32;3])->bool{if let Some(set)=&self.dilated{return set.contains(xyz);}
  for x in -1i32..=1{for y in -1i32..=1{for z in -1i32..=1{if self.solid.contains([xyz[0].wrapping_add(x),xyz[1].wrapping_add(y),xyz[2].wrapping_add(z)]){return true;}}}}false
 }
}
pub fn prepare(inputs:Vec<LevelInput>)->PyResult<Vec<Level>>{inputs.into_iter().map(|input|{
 let (origin,inverse,cell,solid,dilated)=match input{
  LevelInput::Dense((o,inv,cell,sm,sd,sb,dm,dd,db))=>(o,inv,cell,SetInput::Dense(0,sm,sd,sb),Some(SetInput::Dense(0,dm,dd,db))),
  LevelInput::General(o,inv,cell,s,d)=>(o,inv,cell,s,d),
 };
 if origin.iter().any(|x|!x.is_finite()) || !(inverse>0.0 && inverse.is_finite() && cell>0.0 && cell.is_finite()){return Err(PyValueError::new_err("invalid occupancy transform"));}
 Ok(Level{origin,inverse,cell,solid:VoxelSet::parse(solid)?,dilated:dilated.map(VoxelSet::parse).transpose()?})
}).collect()}

/// One sampling call owns this immutable snapshot across its bounded blocks.
#[pyclass(module="_bvt_solver", frozen)]
pub struct _PreparedOccupancy { pub(crate) levels:std::sync::Arc<Vec<Level>> }
#[pymethods]
impl _PreparedOccupancy {
 #[new]
 fn new(inputs:Vec<LevelInput>)->PyResult<Self>{Ok(Self{levels:std::sync::Arc::new(prepare(inputs)?)})}
}
