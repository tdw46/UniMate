//! Surface voxel construction, reconstructed from 0xd9db0/0x76024/0x171b38.
use std::collections::BTreeMap;
use numpy::PyReadonlyArray2;
use ndarray::ArrayView2;
use pyo3::{prelude::*,exceptions::PyValueError,types::PyDict};
fn sub(a:[f32;3],b:[f32;3])->[f32;3]{std::array::from_fn(|k|a[k]-b[k])}
fn dot(a:[f32;3],b:[f32;3])->f32{(a[0]*b[0]+a[1]*b[1])+a[2]*b[2]}
fn cross(a:[f32;3],b:[f32;3])->[f32;3]{[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
pub fn overlaps(center:[f32;3],half:[f32;3],tri:[[f32;3];3])->bool{
 let p=tri.map(|t|sub(t,center));
 for k in 0..3 {
  let min=p[0][k].min(p[1][k]).min(p[2][k]);let max=p[0][k].max(p[1][k]).max(p[2][k]);
  if min>half[k] || max < -half[k]{return false;}
 }
 let edges=[sub(p[1],p[0]),sub(p[2],p[1]),sub(p[0],p[2])];let normal=cross(edges[0],edges[1]);
 let plane=p[0][2]*normal[2]+(p[0][0]*normal[0]+p[0][1]*normal[1]);
 if plane.abs()>dot(normal.map(f32::abs),half){return false;}
 for axis in 0..3 {for edge in edges {
  let a=match axis {0=>[0.0,-edge[2],edge[1]],1=>[edge[2],0.0,-edge[0]],_=>[-edge[1],edge[0],0.0]};
  let values=p.map(|v|dot(v,a));let r=dot(half,a.map(f32::abs));
  if values[0].min(values[1]).min(values[2])>r || values[0].max(values[1]).max(values[2]) < -r {return false;}
 }} true
}
// Four adjacent voxel centers, preserving the scalar SAT expression order.
// Stack lanes only: no retained geometry or extra per-triangle allocation.
fn overlaps4(centers:[[f32;4];3],half:[f32;3],tri:[[f32;3];3])->[bool;4]{
 use crate::sampling::{add4,sub4,mul4};
 type Packet=[[f32;4];3];
 #[inline(always)] fn dot(a:Packet,b:Packet)->[f32;4]{add4(add4(mul4(a[0],b[0]),mul4(a[1],b[1])),mul4(a[2],b[2]))}
 #[inline(always)] fn sub(a:Packet,b:Packet)->Packet{std::array::from_fn(|k|sub4(a[k],b[k]))}
 #[inline(always)] fn cross(a:Packet,b:Packet)->Packet{[
  sub4(mul4(a[1],b[2]),mul4(a[2],b[1])),
  sub4(mul4(a[2],b[0]),mul4(a[0],b[2])),
  sub4(mul4(a[0],b[1]),mul4(a[1],b[0]))]}
 let p:[Packet;3]=tri.map(|t|std::array::from_fn(|k|sub4([t[k];4],centers[k])));
 let mut keep=[true;4];
 for k in 0..3 {for j in 0..4 {
  let min=p[0][k][j].min(p[1][k][j]).min(p[2][k][j]);
  let max=p[0][k][j].max(p[1][k][j]).max(p[2][k][j]);
  if min>half[k] || max < -half[k]{keep[j]=false;}
 }}
 if !keep.iter().any(|&x|x){return keep;}
 let edges=[sub(p[1],p[0]),sub(p[2],p[1]),sub(p[0],p[2])];let normal=cross(edges[0],edges[1]);
 let plane=add4(mul4(p[0][2],normal[2]),add4(mul4(p[0][0],normal[0]),mul4(p[0][1],normal[1])));
 let radius=dot(normal.map(|a|a.map(f32::abs)),half.map(|x|[x;4]));
 for j in 0..4 {if plane[j].abs()>radius[j]{keep[j]=false;}}
 if !keep.iter().any(|&x|x){return keep;}
 for axis in 0..3 {for edge in edges {
  let a=match axis {0=>[[0.0;4],edge[2].map(|x|-x),edge[1]],1=>[edge[2],[0.0;4],edge[0].map(|x|-x)],_=>[edge[1].map(|x|-x),edge[0],[0.0;4]]};
  let values=p.map(|v|dot(v,a));let r=dot(half.map(|x|[x;4]),a.map(|v|v.map(f32::abs)));
  for j in 0..4 {if values[0][j].min(values[1][j]).min(values[2][j])>r[j] || values[0][j].max(values[1][j]).max(values[2][j]) < -r[j]{keep[j]=false;}}
  if !keep.iter().any(|&x|x){return keep;}
 }}keep
}
#[pyfunction]
pub fn triangle_box(center:[f32;3],half:[f32;3],triangle:Vec<[f32;3]>)->PyResult<bool>{
 if triangle.len()!=3 || center.iter().chain(half.iter()).chain(triangle.iter().flatten()).any(|x|!x.is_finite()) || half.iter().any(|&x|x<0.0){return Err(PyValueError::new_err("expected a finite triangle, center and nonnegative box half extents"));}
 Ok(overlaps(center,half,[triangle[0],triangle[1],triangle[2]]))
}
pub struct SurfaceGrid { pub dimensions:[u32;3], pub voxels:BTreeMap<u32,Vec<u32>>, pub insertion_keys:Vec<u32> }
pub(crate) fn surface_grid(v:ArrayView2<'_,f32>,f:ArrayView2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32)->PyResult<SurfaceGrid>{
 surface_grid_with_policy(v,f,minimum,maximum,cell,true)
}
pub(crate) fn surface_grid_with_policy(v:ArrayView2<'_,f32>,f:ArrayView2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,bounded:bool)->PyResult<SurfaceGrid>{
 surface_grid_impl(v,f,minimum,maximum,cell,false,bounded)
}
fn admit_grid(minimum:[f32;3],maximum:[f32;3],cell:f32,bounded:bool)->PyResult<([u32;3],u64)> {
 if bounded && (!(cell>0.0) || !cell.is_finite() || (0..3).any(|k|!minimum[k].is_finite() || !maximum[k].is_finite() || minimum[k]>=maximum[k])) {return Err(PyValueError::new_err("invalid surface voxel geometry or bounds"));}
 let dims=std::array::from_fn::<_,3,_>(|k|((maximum[k]-minimum[k])/cell).ceil().max(1.0) as u32);
 let cells=dims.into_iter().fold(1u64,|n,x|n.wrapping_mul(x as u64));
 if bounded {
  if dims.into_iter().try_fold(1u64,|n,x|n.checked_mul(x as u64)).is_none_or(|n|n>u32::MAX as u64) {return Err(PyValueError::new_err("voxel grid exceeds addressable cell range"));}
  if cells>16_000_000 {return Err(PyValueError::new_err("research voxel grid limit exceeded"));}
 }else{crate::bind_env::admit(cells)?;}
 Ok((dims,cells))
}
#[pyfunction]
#[pyo3(signature=(minimum,maximum,cell,bounded=true))]
pub fn grid_admission(minimum:[f32;3],maximum:[f32;3],cell:f32,bounded:bool)->PyResult<u64>{Ok(admit_grid(minimum,maximum,cell,bounded)?.1)}
fn visit_surface(v:ArrayView2<'_,f32>,f:ArrayView2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,bounded:bool,mut emit:impl FnMut(u32,u32))->PyResult<[u32;3]>{

 if v.ncols()!=3 || f.ncols()!=3 || f.iter().any(|&i|i<0 || i as usize>=v.nrows()){return Err(PyValueError::new_err("invalid surface voxel geometry or bounds"));}
 let (dims,_cells)=admit_grid(minimum,maximum,cell,bounded)?;
 let top=std::array::from_fn::<_,3,_>(|k|minimum[k]+dims[k] as f32*cell);
 for (i,face) in f.rows().into_iter().enumerate(){
  let t=std::array::from_fn::<_,3,_>(|j|std::array::from_fn(|k|v[[face[j] as usize,k]]));
  let lo=std::array::from_fn::<_,3,_>(|k|t[0][k].min(t[1][k]).min(t[2][k]));let hi=std::array::from_fn::<_,3,_>(|k|t[0][k].max(t[1][k]).max(t[2][k]));
  if (0..3).any(|k|hi[k]<minimum[k] || lo[k]>top[k]) {continue;}
  // Native uses floor-to-integer, then clamps to the finite grid.
  let a=std::array::from_fn::<_,3,_>(|k|(((lo[k]-minimum[k])/cell).floor() as i64).clamp(0,dims[k] as i64-1) as u32);
  let b=std::array::from_fn::<_,3,_>(|k|(((hi[k]-minimum[k])/cell).floor() as i64).clamp(0,dims[k] as i64-1) as u32);
  for z in a[2]..=b[2]{for y in a[1]..=b[1]{
   if a[0]>b[0]{continue;}
   // Grid coordinates are strictly below their u32 dimension, so the
   // half-open packet endpoint is representable, including the final tail.
   let packet_end=a[0]+((b[0]-a[0]+1)/4)*4;
   for x in (a[0]..packet_end).step_by(4) {
    let centers=std::array::from_fn(|k|std::array::from_fn(|lane|minimum[k]+([x+lane as u32,y,z][k] as f32+0.5)*cell));
    let keep=overlaps4(centers,[cell*0.5;3],t);
    for lane in 0..4 {if keep[lane]{let key=x+lane as u32+(y+z*dims[1])*dims[0];emit(key,i as u32);}}
   }
   for x in packet_end..=b[0]{
    let center=std::array::from_fn(|k|minimum[k]+([x,y,z][k] as f32+0.5)*cell);
    if overlaps(center,[cell*0.5;3],t){let key=x+(y+z*dims[1])*dims[0];emit(key,i as u32);}
   }
  }}
 }
 Ok(dims)
}
fn surface_grid_impl(v:ArrayView2<'_,f32>,f:ArrayView2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,record_order:bool,bounded:bool)->PyResult<SurfaceGrid>{
 let mut voxels:BTreeMap<u32,Vec<u32>>=BTreeMap::new();let mut insertion_keys=Vec::new();
 let dimensions=visit_surface(v,f,minimum,maximum,cell,bounded,|key,face|{if record_order{insertion_keys.push(key);}voxels.entry(key).or_default().push(face);})?;
 Ok(SurfaceGrid{dimensions,voxels,insertion_keys})
}
/// Adaptive emission needs membership and native partition bucket order, not
/// per-voxel face rows. Rasterize each independent leaf once, then merge in the
/// same leaf iteration order and with the same Fx capacities as the old route.
/// Scratch is bounded by the existing partition maps; no second fine grid.
pub(crate) fn surface_grid_with_buckets(v:ArrayView2<'_,f32>,f:ArrayView2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,partitions:Vec<usize>,bounded:bool)->PyResult<(SurfaceGrid,Vec<u32>)>{
 use rayon::prelude::*;
 if partitions.last().copied()!=Some(f.nrows()) || partitions.windows(2).any(|w|w[0]>w[1]){
  // Preserve geometry/admission error precedence before partition validation.
  let grid=surface_grid_with_policy(v,f,minimum,maximum,cell,bounded)?;
  let keys=surface_bucket_order_with_policy(v,f,minimum,maximum,cell,partitions,bounded)?;
  return Ok((grid,keys));
 }
 if v.ncols()!=3 || f.ncols()!=3 || f.iter().any(|&i|i<0 || i as usize>=v.nrows()){return Err(PyValueError::new_err("invalid surface voxel geometry or bounds"));}
 let (dimensions,_)=admit_grid(minimum,maximum,cell,bounded)?;
 let results:Vec<_>=partitions.par_iter().enumerate().map(|(i,&end)|{
  let begin=if i==0{0}else{partitions[i-1]};
  let mut leaf=std::collections::HashMap::<u32,(),rustc_hash::FxBuildHasher>::default();
  visit_surface(v,f.slice(ndarray::s![begin..end,..]),minimum,maximum,cell,bounded,|key,_|{leaf.insert(key,());}).map(|_|leaf)
 }).collect();
 let leaves:Vec<_>=results.into_iter().collect::<PyResult<_>>()?;
 let mut merged=std::collections::HashMap::<u32,(),rustc_hash::FxBuildHasher>::with_capacity_and_hasher(leaves.iter().map(|s|s.len()).sum(),Default::default());
 for leaf in leaves{for (key,()) in leaf{merged.insert(key,());}}
 let keys:Vec<_>=merged.into_keys().collect();
 let voxels=keys.iter().copied().map(|k|(k,Vec::new())).collect();
 Ok((SurfaceGrid{dimensions,voxels,insertion_keys:Vec::new()},keys))
}

#[pyfunction]
pub fn surface_voxels<'py>(py:Python<'py>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32)->PyResult<Bound<'py,PyDict>>{
 let grid=surface_grid(vertices.as_array(),faces.as_array(),minimum,maximum,cell)?;
 let dims=grid.dimensions;let result=grid.voxels;
 let out=PyDict::new(py);out.set_item("dimensions",dims)?;out.set_item("voxel_size",cell)?;out.set_item("origin",minimum)?;out.set_item("voxels",result)?;Ok(out)
}

/// Original 0x199c5c area vectors, sorted (voxel,face) accumulation and 1e-9 norm floor.
#[pyfunction]
#[pyo3(signature=(vertices,faces,minimum,maximum,cell,bounded=true,array_output=false))]
pub fn probe_surface<'py>(py:Python<'py>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,bounded:bool,array_output:bool)->PyResult<Bound<'py,PyDict>>{
 let v_owned=crate::array_input::owned_two(&vertices);let f_owned=crate::array_input::owned_two(&faces);
 let (d,coords,normals)=py.allow_threads(move || -> PyResult<_> {
 let v=v_owned.view();let f=f_owned.view();
 // Probe output consumes only each voxel's ordered area-vector sum. Accumulate
 // it during the same face-major visit instead of retaining per-voxel face
 // vectors and replaying them. BTree key order and per-voxel f32 add order are
 // unchanged; the last-face vector is stack-local and has no cache lifetime.
 let mut sums:BTreeMap<u32,[f32;3]>=BTreeMap::new();
 let mut last_face=None;let mut vector=[0.0f32;3];
 let d=visit_surface(v,f,minimum,maximum,cell,bounded,|key,face|{
  if last_face!=Some(face){
   let t=std::array::from_fn::<_,3,_>(|j|std::array::from_fn(|k|v[[f[[face as usize,j]] as usize,k]]));
   vector=cross(sub(t[1],t[0]),sub(t[2],t[0]));last_face=Some(face);
  }
  let n=sums.entry(key).or_insert([0.0;3]);for k in 0..3{n[k]=n[k]+vector[k];}
 })?;
 let mut coords=Vec::<[i64;3]>::new();let mut normals=Vec::<[f32;3]>::new();
 for (key,n) in sums {
  coords.push([(key%d[0]) as i64,((key/d[0])%d[1]) as i64,(key/(d[0]*d[1])) as i64]);
  let mut length=dot(n,n).sqrt();if !(1e-9<length){length=1e-9;}
  normals.push(n.map(|x|x/length));
 }

 Ok((d,coords,normals))
 })?;
 let out=PyDict::new(py);out.set_item("dimensions",d)?;if array_output {
  let n=coords.len();
  let coords=ndarray::Array2::from_shape_vec((n,3),coords.into_flattened()).map_err(|e|PyValueError::new_err(e.to_string()))?;
  let normals=ndarray::Array2::from_shape_vec((n,3),normals.into_flattened()).map_err(|e|PyValueError::new_err(e.to_string()))?;
  out.set_item("indices",numpy::PyArray2::from_owned_array(py,coords))?;
  out.set_item("normals",numpy::PyArray2::from_owned_array(py,normals))?;
 } else {out.set_item("indices",coords)?;out.set_item("normals",normals)?;}Ok(out)
}

/// Controlled native map-reduction order; explicit face partitions represent
/// Rayon leaf ownership, not an assertion about the scheduler's partitioning.
#[pyfunction]
pub fn surface_voxel_bucket_order(vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,partitions:Vec<usize>)->PyResult<Vec<u32>>{
 surface_bucket_order(vertices.as_array(),faces.as_array(),minimum,maximum,cell,partitions)
}
pub(crate) fn surface_bucket_order(v:ndarray::ArrayView2<'_,f32>,f:ndarray::ArrayView2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,partitions:Vec<usize>)->PyResult<Vec<u32>>{
 surface_bucket_order_with_policy(v,f,minimum,maximum,cell,partitions,true)
}
pub(crate) fn surface_bucket_order_with_policy(v:ndarray::ArrayView2<'_,f32>,f:ndarray::ArrayView2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,partitions:Vec<usize>,bounded:bool)->PyResult<Vec<u32>>{
 if f.nrows()==0 && partitions.is_empty(){return Ok(Vec::new());}
 if partitions.last().copied()!=Some(f.nrows()) || partitions.windows(2).any(|w|w[0]>w[1]){return Err(PyValueError::new_err("partitions must cover faces in order"));}
 let mut leaves=Vec::new();let mut begin=0;
 for end in partitions{let grid=surface_grid_impl(v,f.slice(ndarray::s![begin..end,..]),minimum,maximum,cell,true,bounded)?;
  let mut leaf=std::collections::HashMap::<u32,(),rustc_hash::FxBuildHasher>::default();for key in grid.insertion_keys{leaf.insert(key,());}leaves.push(leaf);begin=end;
 }
 let mut merged=std::collections::HashMap::<u32,(),rustc_hash::FxBuildHasher>::with_capacity_and_hasher(leaves.iter().map(|s|s.len()).sum(),Default::default());
 for leaf in leaves{for (key,()) in leaf{merged.insert(key,());}}
 Ok(merged.into_keys().collect())
}
