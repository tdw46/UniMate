//! Immutable transport ownership across released-GIL GPU work.
use pyo3::{prelude::*, types::PyBytes};

pub enum ReplayInput<'py> {
    Immutable(Bound<'py, PyBytes>),
    Owned(Vec<u8>),
}
impl<'py> FromPyObject<'py> for ReplayInput<'py> {
    fn extract_bound(value: &Bound<'py, PyAny>) -> PyResult<Self> {
        // Exact bytes only: subclasses may override sequence iteration. Keep
        // their former Vec extraction, just like bytearray/list/memoryview.
        if let Ok(bytes) = value.downcast_exact::<PyBytes>() {
            Ok(Self::Immutable(bytes.clone()))
        } else {
            value.extract::<Vec<u8>>().map(Self::Owned)
        }
    }
}
impl ReplayInput<'_> {
    pub fn as_bytes(&self) -> &[u8] {
        match self {
            Self::Immutable(value) => value.as_bytes(),
            Self::Owned(value) => value,
        }
    }
}
