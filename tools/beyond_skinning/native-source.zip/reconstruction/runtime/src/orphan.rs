//! Final orphan fill, recovered from 0x142910. Retains input edge order and
//! multi-source FIFO ties, then nearest original nonempty donor for components
//! that contain no weighted vertex. Never invents weights for an all-empty mesh.
use numpy::{PyReadonlyArray2,IntoPyArray};
use pyo3::{prelude::*,exceptions::PyValueError,types::PyDict};
use std::collections::VecDeque;
#[pyfunction]
#[pyo3(signature=(weights,bones,edges,positions,allow_nonfinite_positions=false))]
pub fn fill_orphan_weights<'py>(py:Python<'py>,weights:PyReadonlyArray2<'py,f32>,bones:PyReadonlyArray2<'py,i32>,edges:PyReadonlyArray2<'py,i64>,positions:PyReadonlyArray2<'py,f32>,allow_nonfinite_positions:bool)->PyResult<Bound<'py,PyDict>>{
 let w=weights.as_array();let b=bones.as_array();let es=edges.as_array();let p=positions.as_array();let n=w.nrows();let k=w.ncols();
 if b.shape()!=w.shape() || p.shape()!=[n,3] || es.ncols()!=2 || k>32 || (w.iter().any(|v|!v.is_finite()) || (!allow_nonfinite_positions && p.iter().any(|v|!v.is_finite()))) {return Err(PyValueError::new_err("invalid orphan fill inputs"));}
 let good:Vec<bool>=w.rows().into_iter().map(|r|{let mut s=-0.0f32;for &x in r{s+=x;}s>=1e-6}).collect();
 let donors:Vec<usize>=(0..n).filter(|&i|good[i]).collect();let mut source=vec![-1i64;n];let mut queue=VecDeque::new();let mut neighbors=vec![Vec::new();n];
 for e in es.rows(){if e[0]>=0 && e[1]>=0 && (e[0] as usize)<n && (e[1] as usize)<n {let a=e[0] as usize;let b=e[1] as usize;neighbors[a].push(b);neighbors[b].push(a);}}
 for &i in &donors{source[i]=i as i64;queue.push_back(i);}
 while let Some(i)=queue.pop_front(){for &j in &neighbors[i]{if source[j]<0{source[j]=source[i];queue.push_back(j);}}}
 let mut outw=w.to_owned();let mut outb=b.to_owned();
 for i in 0..n{if good[i]{continue;}if source[i]<0 && !donors.is_empty(){let mut best=f32::INFINITY;let mut id=donors[0];for &j in &donors{let d:[f32;3]=std::array::from_fn(|a|p[[j,a]]-p[[i,a]]);let dist=(d[0]*d[0]+d[1]*d[1])+d[2]*d[2];if dist<best{best=dist;id=j;}}source[i]=id as i64;}
  if source[i]>=0{let j=source[i] as usize;for a in 0..k{outw[[i,a]]=w[[j,a]];outb[[i,a]]=b[[j,a]];}}
 }
 // Native zero-width early return retains -1 source entries.
 if k==0{source.fill(-1);}
 let out=PyDict::new(py);out.set_item("weights",outw.into_pyarray(py))?;out.set_item("bones",outb.into_pyarray(py))?;out.set_item("sources",source)?;Ok(out)
}
