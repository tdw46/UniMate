//! Solve-space normalization and skeleton-local connected-component bounds.
use numpy::{PyReadonlyArray2,PyReadonlyArray3};
use pyo3::{prelude::*,exceptions::PyValueError,types::PyDict};
fn root(parents:&mut [usize],mut i:usize)->usize{while parents[i]!=i{parents[i]=parents[parents[i]];i=parents[i];}i}
#[pyfunction]
#[pyo3(signature=(verts,coarse_res,edges=None,segments=None))]
pub fn bind_grid<'py>(py:Python<'py>,verts:PyReadonlyArray2<'py,f32>,coarse_res:u32,edges:Option<PyReadonlyArray2<'py,i64>>,segments:Option<PyReadonlyArray3<'py,f32>>)->PyResult<Bound<'py,PyDict>>{
 let v=crate::array_input::two(&verts);let n=v.nrows();
 // The public wrapper reads optional edge/segment prefixes before bounds.
 // Wider rows are accepted; empty rows need no coordinates. Preserve the
 // original recoverable exception without actually panicking or indexing OOB.
 if let (Some(e),Some(s))=(&edges,&segments){
  use numpy::PyUntypedArrayMethods;
  if (e.shape()[0]>0&&e.shape()[1]<2)||(s.shape()[0]>0&&(s.shape()[1]<2||s.shape()[2]<3)){
   return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));
  }
 }
 if n>0&&v.ncols()<3{return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
 if n==0{return Err(PyValueError::new_err("Cannot compute grid from empty vertex array"));}
 if !(8..=2048).contains(&coarse_res){return Err(PyValueError::new_err(format!("coarse_res out of range [8, 2048]: {coarse_res}")));}
 let mut selected=vec![true;n];
 if let (Some(edges),Some(segments))=(edges,segments){
  let e=crate::array_input::two(&edges);let s=crate::array_input::owned_three(&segments);
  if s.shape()[0]>0{
   let mut parent:Vec<_>=(0..n).collect();for row in e.rows(){let a=row[0];let b=row[1];if a<0||b<0||a as usize>=n||b as usize>=n{continue;}let x=root(&mut parent,a as usize);let y=root(&mut parent,b as usize);parent[x]=y;}
   let mut lo=vec![[f32::INFINITY;3];n];let mut hi=vec![[f32::NEG_INFINITY;3];n];let mut used=vec![false;n];
   for i in 0..n{let r=root(&mut parent,i);used[r]=true;for a in 0..3{lo[r][a]=lo[r][a].min(v[(i,a)]);hi[r][a]=hi[r][a].max(v[(i,a)]);}}
   let mut sl=[f32::INFINITY;3];let mut sh=[f32::NEG_INFINITY;3];for i in 0..s.shape()[0]{for j in 0..2{for a in 0..3{sl[a]=sl[a].min(s[(i,j,a)]);sh[a]=sh[a].max(s[(i,j,a)]);}}}
   let margin=(0..3).map(|a|sh[a]-sl[a]).fold(0.0f32,f32::max)*0.5;
   let keep:Vec<_>=(0..n).map(|i|used[i]&&(0..3).all(|a|!(hi[i][a]<sl[a]-margin||sl[a].is_nan()||sh[a]+margin<lo[i][a]))).collect();
   // All or none: native falls back to the complete body.
   if (0..n).any(|i|used[i]&&keep[i])&&(0..n).any(|i|used[i]&&!keep[i]){for i in 0..n{selected[i]=keep[root(&mut parent,i)];}}
  }
 }
 let mut lo=[f32::INFINITY;3];let mut hi=[f32::NEG_INFINITY;3];
 for i in 0..n{if selected[i]{for a in 0..3{lo[a]=lo[a].min(v[(i,a)]);hi[a]=hi[a].max(v[(i,a)]);}}}
 let extent:[f32;3]=std::array::from_fn(|a|hi[a]-lo[a]);let maximum=extent.into_iter().fold(0.0f32,f32::max);
 let scale=if maximum as f64<=1e-9{1.0}else{1.8/maximum as f64};
 let mut lower=[f64::INFINITY;3];let mut upper=[f64::NEG_INFINITY;3];
 for i in 0..n{if selected[i]{for a in 0..3{let x=if (scale-1.0).abs()<=1e-6{v[(i,a)]}else{v[(i,a)]*scale as f32} as f64;lower[a]=lower[a].min(x);upper[a]=upper[a].max(x);}}}
 let min:[f32;3]=std::array::from_fn(|a|(lower[a]-(upper[a]-lower[a]).max(1e-6)*0.02) as f32);
 let max:[f32;3]=std::array::from_fn(|a|(upper[a]+(upper[a]-lower[a]).max(1e-6)*0.02) as f32);
 if (0..3).any(|a|max[a] as f64-min[a] as f64<=0.0){return Err(PyValueError::new_err(format!("Bbox extent must be strictly positive, got {:?}",(0..3).map(|a|upper[a]-lower[a]).collect::<Vec<_>>())));}
 let out=PyDict::new(py);out.set_item("scale",scale)?;out.set_item("bbox_min",min.to_vec())?;out.set_item("bbox_max",max.to_vec())?;out.set_item("extent",extent.to_vec())?;Ok(out)
}
