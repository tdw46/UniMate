//! Public face-role contract. The legacy Vec-based private bind helper is unchanged.
use pyo3::prelude::*;
use numpy::{PyReadonlyArray1,PyArrayMethods,PyUntypedArrayMethods};
use std::collections::HashMap;
fn at<T>(values:&[T],i:usize)->PyResult<&T>{values.get(i).ok_or_else(||pyo3::panic::PanicException::new_err(format!("index out of bounds: the len is {} but the index is {}",values.len(),i)))}
fn tokens(name:&str)->Vec<String>{
 let name=name.split_once(':').map_or(name,|(_,tail)|tail);let mut out=Vec::new();let mut word=String::new();let mut previous='\0';
 let flush=|word:&mut String,out:&mut Vec<String>|{if !word.is_empty(){out.push(word.to_lowercase());word.clear();}};
 for c in name.chars(){
  if c.is_ascii_alphanumeric(){
   if (previous.is_ascii_lowercase()&&(c.is_ascii_uppercase()||c.is_ascii_digit())) || (previous.is_ascii_uppercase()&&c.is_ascii_digit()) || (previous.is_ascii_digit()&&c.is_ascii_alphabetic()){flush(&mut word,&mut out);}
   word.push(c);
  }else{flush(&mut word,&mut out);if c.is_alphabetic(){out.push(c.to_lowercase().collect());}}
  previous=c;
 }
 flush(&mut word,&mut out);out
}
fn family(name:&str)->&'static str{
 let n=name.split_once(':').map_or(name,|(_,tail)|tail).trim().to_lowercase();
 if n.starts_with("cc_base_"){"cc"}else if n.starts_with("mface")||n.starts_with("mskull"){"secondlife"}
 else if !n.is_ascii(){"mmd"}
 else if n.starts_with("def-")||n.starts_with("org-")||n.contains(".t.")||n.contains(".b."){"rigify"}
 else if n.ends_with(".x")||n.ends_with(".l")||n.ends_with(".r"){"arp"}
 else if n.contains('_'){"faceit"}
 else if n.starts_with("left")||n.starts_with("right"){"mixamo"}else{"english"}
}
#[pyfunction]
#[pyo3(signature=(names,parent_idx,deform=None,head=-1),text_signature="(names, parent_idx, deform=None, head=...)")]
pub fn detect_face(names:Vec<String>,parent_idx:PyReadonlyArray1<'_,i64>,deform:Option<PyReadonlyArray1<'_,bool>>,head:i64)->PyResult<(Vec<(usize,String,String)>,String)>{
 let p=crate::array_input::owned_one(&parent_idx).to_vec();
 let d=deform.map(|a|(0..a.len()).map(|i|unsafe{a.data().cast::<u8>().offset(i as isize*a.strides()[0]).read()}).collect::<Vec<_>>());
 let mut mask=Vec::with_capacity(names.len());
 for i in 0..names.len(){
  let raw=if let Some(ref d)=d{*at(d,i)?}else{1};
  if head<0{mask.push(raw&1!=0);continue;}
  if raw!=1||i as i64==head{mask.push(false);continue;}
  at(&p,i)?;let mut current=i;let mut allowed=false;
  for _ in 0..p.len(){
   let parent=*at(&p,current)?;if parent<0{break;}
   if parent==head{allowed=true;break;}
   current=parent as usize;
   if tokens(at(&names,current)?).iter().any(|s|matches!(s.as_str(),"head"|"face"|"facial"|"skull"|"頭")){allowed=true;break;}
   at(&p,current)?;
  }
  mask.push(allowed);
 }
 let mut rows=Vec::new();let mut votes=HashMap::<&'static str,usize>::new();
 for (i,n) in names.iter().enumerate(){if !mask[i]{continue;}
  if let Some((role,side))=crate::face_roles::role(&tokens(n)){
   rows.push((i,role.to_owned(),side.to_owned()));*votes.entry(family(n)).or_default()+=1;
  }
 }
 // Native max-by (count, reverse byte length), last hash-iteration entry on ties.
 // RandomState makes equally ranked families intentionally nondeterministic.
 let winner=votes.into_iter().max_by(|(a,ac),(b,bc)|ac.cmp(bc).then_with(||b.len().cmp(&a.len()))).map(|(k,_)|k).unwrap_or("");
 Ok((rows,winner.to_owned()))
}
