//! Public bind extraction recovered from sub_b2c88; computation remains independent Python orchestration.
use pyo3::{prelude::*,types::PyDict};
use numpy::{PyReadonlyArray1,PyReadonlyArray2,PyReadonlyArray3,IntoPyArray};
use crate::array_input::{owned_one,owned_two,owned_three};
type PlainMesh<'py>=(PyReadonlyArray2<'py,f32>,PyReadonlyArray2<'py,i32>,Option<PyReadonlyArray2<'py,f32>>,Option<PyReadonlyArray2<'py,f32>>);
type FlaggedMesh<'py>=(PyReadonlyArray2<'py,f32>,PyReadonlyArray2<'py,i32>,Option<PyReadonlyArray2<'py,f32>>,Option<PyReadonlyArray2<'py,f32>>,bool);
pub enum MeshPartArg<'py> { Flagged(FlaggedMesh<'py>), Plain(PlainMesh<'py>) }
impl<'py> FromPyObject<'py> for MeshPartArg<'py> {
 fn extract_bound(value:&Bound<'py,PyAny>)->PyResult<Self> {
  let flagged=match value.extract::<FlaggedMesh<'py>>() { Ok(v)=>return Ok(Self::Flagged(v)),Err(e)=>e };
  let plain=match value.extract::<PlainMesh<'py>>() { Ok(v)=>return Ok(Self::Plain(v)),Err(e)=>e };
  Err(pyo3::exceptions::PyTypeError::new_err(format!("failed to extract enum MeshPartArg ('Flagged | Plain')\n- variant Flagged (Flagged): {flagged}\n- variant Plain (Plain): {plain}")))
 }
}
impl<'py> MeshPartArg<'py> { fn flagged(self)->FlaggedMesh<'py>{ match self { Self::Flagged(v)=>v,Self::Plain((a,b,c,d))=>(a,b,c,d,false) } } }

#[pyfunction]
#[pyo3(signature=(session, verts, faces, edges, bone_names, heads, tails, parent_idx, full_names, full_parent_idx, full_deform, full_segments, coarse_res, top_k, max_depth, refine_multiplier, fill_interior, jacobi_iters, auto_iters, auto_iters_cap, stop_moving, stop_moving_fine, quality, sample_k, fmg_iters, refine_iters_ratio, edge_cull, bleed_threshold, bucket_shape, winding_threshold, ghost_cull, sample_kernel, sample_volume, finger_isolate, finger_isolate_thresh, finger_isolate_smooth, spine_shapes, spine_from_names, trunk_seed_edge, trunk_seed_lat, trunk_seed_lat_pow, use_gpu, check_coverage, min_coverage_frac, progress=None, void_boxes=None, face=false, face_voids=false, face_refine_eyes=true, face_split=false, face_smooth=0, face_weight_smooth=0.0, face_weight_smooth_iters=0, meshes=None, viz=None, viz_bone=None, chain_ends=None))]
pub fn bind<'py>(py:Python<'py>,session:Py<crate::bind_session::BindSession>,verts:Option<PyReadonlyArray2<'py,f32>>,faces:Option<PyReadonlyArray2<'py,i32>>,edges:Option<PyReadonlyArray2<'py,i64>>,bone_names:Vec<String>,heads:PyReadonlyArray2<'py,f32>,tails:PyReadonlyArray2<'py,f32>,parent_idx:PyReadonlyArray1<'py,i64>,full_names:Vec<String>,full_parent_idx:PyReadonlyArray1<'py,i64>,full_deform:PyReadonlyArray1<'py,bool>,full_segments:PyReadonlyArray3<'py,f32>,coarse_res:u32,top_k:usize,max_depth:u32,refine_multiplier:u32,fill_interior:bool,jacobi_iters:u32,auto_iters:bool,auto_iters_cap:u32,stop_moving:f32,stop_moving_fine:f32,quality:String,sample_k:usize,fmg_iters:Option<u32>,refine_iters_ratio:u32,edge_cull:f32,bleed_threshold:f32,bucket_shape:Option<String>,winding_threshold:f32,ghost_cull:bool,sample_kernel:String,sample_volume:bool,finger_isolate:bool,finger_isolate_thresh:f32,finger_isolate_smooth:u32,spine_shapes:Option<Vec<u8>>,spine_from_names:bool,trunk_seed_edge:f32,trunk_seed_lat:f32,trunk_seed_lat_pow:f32,use_gpu:bool,check_coverage:bool,min_coverage_frac:f32,progress:Option<Py<PyAny>>,void_boxes:Option<Vec<(u32,[i32;3],[i32;3])>>,face:bool,face_voids:bool,face_refine_eyes:bool,face_split:bool,face_smooth:u32,face_weight_smooth:f32,face_weight_smooth_iters:u32,meshes:Option<Vec<MeshPartArg<'py>>>,viz:Option<String>,viz_bone:Option<String>,chain_ends:Option<PyReadonlyArray1<'py,bool>>)->PyResult<Py<PyAny>> {
 crate::cancel::check();
 let kwargs=PyDict::new(py);
 kwargs.set_item("session",session.clone_ref(py))?;
 kwargs.set_item("verts",verts.map(|x|owned_two(&x).into_pyarray(py)))?;
 kwargs.set_item("faces",faces.map(|x|owned_two(&x).into_pyarray(py)))?;
 kwargs.set_item("edges",edges.map(|x|owned_two(&x).into_pyarray(py)))?;
 kwargs.set_item("bone_names",bone_names)?;
 kwargs.set_item("heads",owned_two(&heads).into_pyarray(py))?;
 kwargs.set_item("tails",owned_two(&tails).into_pyarray(py))?;
 kwargs.set_item("parent_idx",owned_one(&parent_idx).into_pyarray(py))?;
 kwargs.set_item("full_names",full_names)?;
 kwargs.set_item("full_parent_idx",owned_one(&full_parent_idx).into_pyarray(py))?;
 kwargs.set_item("full_deform",owned_one(&full_deform).into_pyarray(py))?;
 kwargs.set_item("full_segments",owned_three(&full_segments).into_pyarray(py))?;
 kwargs.set_item("coarse_res",coarse_res)?;
 kwargs.set_item("top_k",top_k)?;
 kwargs.set_item("max_depth",max_depth)?;
 kwargs.set_item("refine_multiplier",refine_multiplier)?;
 kwargs.set_item("fill_interior",fill_interior)?;
 kwargs.set_item("jacobi_iters",jacobi_iters)?;
 kwargs.set_item("auto_iters",auto_iters)?;
 kwargs.set_item("auto_iters_cap",auto_iters_cap)?;
 kwargs.set_item("stop_moving",stop_moving)?;
 kwargs.set_item("stop_moving_fine",stop_moving_fine)?;
 kwargs.set_item("quality",quality)?;
 kwargs.set_item("sample_k",sample_k)?;
 kwargs.set_item("fmg_iters",fmg_iters)?;
 kwargs.set_item("refine_iters_ratio",refine_iters_ratio)?;
 kwargs.set_item("edge_cull",edge_cull)?;
 kwargs.set_item("bleed_threshold",bleed_threshold)?;
 kwargs.set_item("bucket_shape",bucket_shape)?;
 kwargs.set_item("winding_threshold",winding_threshold)?;
 kwargs.set_item("ghost_cull",ghost_cull)?;
 kwargs.set_item("sample_kernel",sample_kernel)?;
 kwargs.set_item("sample_volume",sample_volume)?;
 kwargs.set_item("finger_isolate",finger_isolate)?;
 kwargs.set_item("finger_isolate_thresh",finger_isolate_thresh)?;
 kwargs.set_item("finger_isolate_smooth",finger_isolate_smooth)?;
 kwargs.set_item("spine_shapes",spine_shapes)?;
 kwargs.set_item("spine_from_names",spine_from_names)?;
 kwargs.set_item("trunk_seed_edge",trunk_seed_edge)?;
 kwargs.set_item("trunk_seed_lat",trunk_seed_lat)?;
 kwargs.set_item("trunk_seed_lat_pow",trunk_seed_lat_pow)?;
 kwargs.set_item("use_gpu",use_gpu)?;
 kwargs.set_item("check_coverage",check_coverage)?;
 kwargs.set_item("min_coverage_frac",min_coverage_frac)?;
 kwargs.set_item("progress",progress)?;
 kwargs.set_item("void_boxes",void_boxes)?;
 kwargs.set_item("face",face)?;
 kwargs.set_item("face_voids",face_voids)?;
 kwargs.set_item("face_refine_eyes",face_refine_eyes)?;
 kwargs.set_item("face_split",face_split)?;
 kwargs.set_item("face_smooth",face_smooth)?;
 kwargs.set_item("face_weight_smooth",face_weight_smooth)?;
 kwargs.set_item("face_weight_smooth_iters",face_weight_smooth_iters)?;
 kwargs.set_item("meshes",meshes.map(|v|v.into_iter().map(MeshPartArg::flagged).map(|(a,b,c,d,e)|(owned_two(&a).into_pyarray(py),owned_two(&b).into_pyarray(py),c.map(|x|owned_two(&x).into_pyarray(py)),d.map(|x|owned_two(&x).into_pyarray(py)),e)).collect::<Vec<_>>()))?;
 kwargs.set_item("viz",viz)?;
 kwargs.set_item("viz_bone",viz_bone)?;
 kwargs.set_item("chain_ends",chain_ends.map(|x|owned_one(&x).into_pyarray(py)))?;
 let function=py.import("beyond_skinning.public_api")?.getattr("_bind_impl")?;
 session.bind(py).call_method1("_run_bind",(function,kwargs)).map(Bound::unbind)
}
#[pyfunction]
pub fn fail_empty_cloud()->PyResult<()> { Err(pyo3::panic::PanicException::new_err("chunk_size must not be zero")) }

/// Preserve the original Rust debug-string escaping in the public error.
#[pyfunction]
pub fn invalid_viz(value:&str)->PyResult<()> {
 Err(pyo3::exceptions::PyValueError::new_err(format!("viz must be \"cloud\", \"seeds\" or \"field\", not {:?}",value)))
}
