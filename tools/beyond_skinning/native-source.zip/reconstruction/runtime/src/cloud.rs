//! Coarse cloud and CPU interior classification recovered from 0xaaaf4,
//! 0x6078c and 0x199a48. Adaptive level emission/ghost culling remain separate.
use numpy::PyReadonlyArray2;
use pyo3::{prelude::*,exceptions::PyValueError,types::PyDict};
#[pyfunction]
#[pyo3(signature=(vertices,faces,minimum,maximum,resolution,fill_interior,threshold,bounded=true,diagnostics=false,max_output_points=None))]
pub fn coarse_cloud<'py>(py:Python<'py>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,minimum:[f32;3],maximum:[f32;3],resolution:u32,fill_interior:bool,threshold:f32,bounded:bool,diagnostics:bool,max_output_points:Option<usize>)->PyResult<Bound<'py,PyDict>>{
 if resolution==0{return Err(PyValueError::new_err("invalid coarse cloud settings"));}
 let extent: [f32;3]=std::array::from_fn(|k|maximum[k]-minimum[k]);let cell=extent[0].max(extent[1]).max(extent[2])/resolution as f32;
 // Owned arrays permit native construction to release the GIL safely.
 let v=crate::array_input::owned_two(&vertices);let f=crate::array_input::owned_two(&faces);
 let grid=py.allow_threads(||crate::voxel::surface_grid_with_policy(v.view(),f.view(),minimum,maximum,cell,bounded))?;
 let point_limit = max_output_points.unwrap_or(usize::MAX);
 if grid.voxels.len() > point_limit {
     return Err(PyValueError::new_err("coarse cloud output working-set research budget exceeded"));
 }
 let counts:Vec<usize>=if diagnostics{grid.voxels.values().map(|x|x.len()).collect()}else{Vec::new()};
 crate::cancel::check();
 let (triangles,nodes)=crate::winding_tree::owned_tree(py,vertices,faces)?;
 let (dims,surface,inside,positions,tiles,queries)=py.allow_threads(|| -> PyResult<_> {
 let dims=grid.dimensions;
 let cells=dims.into_iter().fold(1u64,|n,d|n.wrapping_mul(d as u64));
 let decode=|key:u32|[key%dims[0],key/dims[0]%dims[1],key/(dims[0]*dims[1])];
 let center=|xyz:[u32;3]|std::array::from_fn(|k|minimum[k]+(xyz[k] as f32+0.5)*cell);
 let surface:Vec<_>=grid.voxels.keys().map(|&key|decode(key)).collect();
 let mut tiles=Vec::new();let mut inside=Vec::new();let mut queries=0usize;
 // The native detector accepts fill_interior but classifies coarse interiors unconditionally.
 let _ = fill_interior;
 {
  let mut winding=|xyz:[u32;3]|{queries+=1;if nodes.is_empty(){0.0}else{crate::winding_tree::solid_angle(&triangles,&nodes,0,center(xyz))/12.566371f32}};
  let td=dims.map(|d|d.div_ceil(4));let tile_count=td.into_iter().fold(1u32,|n,d|n.wrapping_mul(d));tiles=vec![3u8;tile_count as usize];
  let ti=|c:[u32;3]|(c[0]+(c[1]+c[2]*td[1])*td[0]) as usize;
  // Any tile touching a surface voxel's one-cell neighborhood stays uncertain.
  for &c in &surface{for x in -1i64..=1{for y in -1i64..=1{for z in -1i64..=1{
   let q=[c[0] as i64+x,c[1] as i64+y,c[2] as i64+z];
   if (0..3).all(|k|q[k]>=0 && q[k]<dims[k] as i64){tiles[ti(q.map(|v|v as u32/4))]=0;}
  }}}}
  for index in 0..tiles.len(){let key=index as u32;let x=key%td[0];let y=key/td[0]%td[1];let z=key/td[0].wrapping_mul(td[1]);if tiles[index]==0{continue;}
   let lo=[x*4,y*4,z*4];let hi=std::array::from_fn::<_,3,_>(|k|(lo[k]+3).min(dims[k]-1));
   let mut probes=vec![std::array::from_fn(|k|(lo[k]+hi[k])/2)];
   for x in [lo[0],hi[0]]{for y in [lo[1],hi[1]]{for z in [lo[2],hi[2]]{probes.push([x,y,z]);}}}
   let mut min=f32::INFINITY;let mut max=f32::NEG_INFINITY;
   for p in probes{let w=winding(p);min=min.min(w);if !(w<max){max=w;}}
   let mut state=if threshold-0.2>=max{2}else{0};if min>=threshold+0.2{state=1;}tiles[index]=state;
  }
  // Both streams are ascending u32 voxel keys. Merge once instead of doing
  // a B-tree lookup for every empty/interior cell; classification order stays exact.
  let mut surface_keys=grid.voxels.keys().copied().peekable();
  for key in 0..cells as u32{if surface_keys.peek().copied()==Some(key){surface_keys.next();continue;}let c=decode(key);let state=tiles[ti(c.map(|v|v/4))];if state==1 || (state!=2 && winding(c)>=threshold){
      if inside.len() >= point_limit - surface.len() {
          return Err(PyValueError::new_err("coarse cloud output working-set research budget exceeded"));
      }
      inside.push(c);
  }}
 }
 let positions:Vec<[f32;3]>=surface.iter().chain(inside.iter()).copied().map(center).collect();
 Ok((dims,surface,inside,positions,tiles,queries))
 })?;
 let n=positions.len();let radius=(cell as f64*0.8660254037844386f64) as f32;
 let out=PyDict::new(py);out.set_item("resolution",dims)?;out.set_item("voxel_size",cell)?;out.set_item("bbox_min",minimum)?;out.set_item("voxel_indices",surface)?;out.set_item("inside_voxel_indices",inside)?;
 out.set_item("cloud_positions",positions)?;out.set_item("cloud_levels",vec![0u8;n])?;out.set_item("cloud_radii",vec![radius;n])?;out.set_item("tile_states",tiles)?;out.set_item("winding_queries",queries)?;if diagnostics{out.set_item("surface_voxels",counts.len())?;out.set_item("avg_faces_per_voxel",if counts.is_empty(){0.0}else{counts.iter().sum::<usize>() as f64/counts.len() as f64})?;out.set_item("max_faces_per_voxel",counts.iter().max().copied().unwrap_or(0))?;}Ok(out)
}

/// Maps finer surface/interior centers to replaced coarser cells. Native 0x94c7c.
/// Returns the native Fx-hash bucket iteration order for this insertion stream.
#[pyfunction]
pub fn refinement_replacement_keys(surface:PyReadonlyArray2<'_,f32>,inside:PyReadonlyArray2<'_,f32>,origin:[f32;3],cell:f32)->PyResult<Vec<[i64;3]>>{
 let a=surface.as_array();let b=inside.as_array();
 if a.ncols()!=3 || b.ncols()!=3 || !cell.is_finite() || cell<=0.0 || origin.iter().chain(a.iter()).chain(b.iter()).any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid refinement replacement input"));}
 let mut keys=std::collections::HashSet::<(i64,i64,i64),rustc_hash::FxBuildHasher>::default();
 for p in a.rows().into_iter().chain(b.rows()){
  let q:[f32;3]=std::array::from_fn(|k|((p[k]-origin[k])/cell).floor());
  if q.iter().any(|v|!v.is_finite() || v.abs()>1e15){return Err(PyValueError::new_err("replacement coordinate exceeds research bound"));}
  keys.insert((q[0] as i64,q[1] as i64,q[2] as i64));
 }
 Ok(keys.into_iter().map(|(x,y,z)|[x,y,z]).collect())
}

/// Adaptive surface emission from one already-identified marker cluster.
/// Recovers the spatial/face selection and f32 lattice arithmetic in 0x6e218.
/// Surface order is canonical here; Rayon map reduction is a separate contract.
#[pyfunction]
#[pyo3(signature=(vertices,faces,minimum,maximum,coarse_cell,marker_cell,fine_cell,markers,subdivisions=0,voids=None,coarse_outside=None,surface_partitions=None,serial_split_depth=0,bounded=true))]
pub fn adaptive_surface_points<'py>(py:Python<'py>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,minimum:[f32;3],maximum:[f32;3],coarse_cell:f32,marker_cell:f32,fine_cell:f32,markers:Vec<[i32;3]>,subdivisions:u32,voids:Option<Vec<[i32;3]>>,coarse_outside:Option<Vec<u8>>,surface_partitions:Option<Vec<usize>>,serial_split_depth:u32,bounded:bool)->PyResult<Bound<'py,PyDict>>{
 let v_owned=crate::array_input::owned_two(&vertices);let f_owned=crate::array_input::owned_two(&faces);
 let result=py.allow_threads(move || -> PyResult<_> {
  adaptive_cluster_check(&markers,subdivisions,marker_cell,fine_cell,bounded)?;
  let v=v_owned.view();let f=f_owned.view();
  let coarse=crate::voxel::surface_grid_with_policy(v,f,minimum,maximum,coarse_cell,bounded)?;
  adaptive_surface_geometry(v,f,&coarse,minimum,coarse_cell,marker_cell,fine_cell,markers,subdivisions,voids,coarse_outside,surface_partitions,serial_split_depth,bounded)
 })?;
 surface_result(py,result,false)
}
type SurfaceResult=([f32;6],[f32;3],[u32;3],Vec<u32>,Vec<[f32;3]>,Vec<[f32;3]>);
fn adaptive_cluster_check(markers:&[[i32;3]],subdivisions:u32,marker_cell:f32,fine_cell:f32,bounded:bool)->PyResult<()> {
 if (bounded && (subdivisions>16 || (markers.len() as u64).saturating_mul((subdivisions as u64).saturating_pow(3))>2_000_000 || markers.len()>2_000_000)) || markers.is_empty() || [marker_cell,fine_cell].iter().any(|&x|!x.is_finite()||x<=0.0) || (bounded && markers.iter().flatten().any(|&x|x.abs_diff(0)>2_000_000_000)){return Err(PyValueError::new_err("invalid adaptive cluster"));}
 Ok(())
}
fn adaptive_surface_geometry(v:ndarray::ArrayView2<'_,f32>,f:ndarray::ArrayView2<'_,i32>,coarse:&crate::voxel::SurfaceGrid,minimum:[f32;3],coarse_cell:f32,marker_cell:f32,fine_cell:f32,markers:Vec<[i32;3]>,subdivisions:u32,voids:Option<Vec<[i32;3]>>,coarse_outside:Option<Vec<u8>>,surface_partitions:Option<Vec<usize>>,serial_split_depth:u32,bounded:bool)->PyResult<SurfaceResult>{
 use rustc_hash::FxHashSet as HashSet;
 let mut lo=markers[0];let mut hi=lo;for q in &markers{for k in 0..3{lo[k]=lo[k].min(q[k]);hi[k]=hi[k].max(q[k]);}}
 let raw:[f32;6]=std::array::from_fn(|k|if k<3{minimum[k]+marker_cell*lo[k] as f32}else{minimum[k-3]+marker_cell*hi[k-3].wrapping_add(1) as f32});
 let inv=1.0f32/marker_cell;let bounds:[f32;6]=std::array::from_fn(|k|{let q=(raw[k]-minimum[k%3])*inv;minimum[k%3]+marker_cell*if k<3{q.floor()}else{q.ceil()}});
 let a:[f32;3]=std::array::from_fn(|k|bounds[k]-coarse_cell);let b:[f32;3]=std::array::from_fn(|k|bounds[k+3]+coarse_cell);
 let ci=1.0f32/coarse_cell;let qa:[u32;3]=std::array::from_fn(|k|((ci*(a[k]-minimum[k])).floor() as i64).clamp(0,coarse.dimensions[k] as i64-1) as u32);
 let qb:[u32;3]=std::array::from_fn(|k|((ci*(b[k]-minimum[k])).floor() as i64).clamp(0,coarse.dimensions[k] as i64-1) as u32);
 // Membership does not drive output order: emit explicitly sorted face IDs.
 // Fx sets avoid SipHash/tree work while retaining only the existing owners.
 let mut selected=HashSet::default();
 // BTree range visits the same ascending keys but skips empty x cells.
 for z in qa[2]..=qb[2]{for y in qa[1]..=qb[1]{
  if qa[0]>qb[0]{continue;}
  let base=(y+z*coarse.dimensions[1])*coarse.dimensions[0];
  for (_,ids) in coarse.voxels.range(base+qa[0]..=base+qb[0]){selected.extend(ids.iter().copied());}
 }}
 let mut selected:Vec<_>=selected.into_iter().collect();selected.sort_unstable();let sf=ndarray::Array2::from_shape_fn((selected.len(),3),|(i,k)|f[[selected[i] as usize,k]]);
 let set:HashSet<_>=markers.iter().copied().collect();let mut points=Vec::<[f32;3]>::new();
 if serial_split_depth>8{crate::voxel::surface_grid_with_policy(v,sf.view(),a,b,fine_cell,bounded)?;return Err(PyValueError::new_err("serial split depth exceeds research bound"));}
 let partitions=if serial_split_depth>0{
  fn split(begin:usize,end:usize,depth:u32,out:&mut Vec<usize>){if depth==0||end-begin<2{out.push(end);}else{let middle=begin+(end-begin)/2;split(begin,middle,depth-1,out);split(middle,end,depth-1,out);}}
  let mut leaves=Vec::new();split(0,selected.len(),serial_split_depth,&mut leaves);Some(leaves)
 }else{surface_partitions};
 let (grid,keys)=if let Some(partitions)=partitions{crate::voxel::surface_grid_with_buckets(v,sf.view(),a,b,fine_cell,partitions,bounded)?}else{let grid=crate::voxel::surface_grid_with_policy(v,sf.view(),a,b,fine_cell,bounded)?;let keys=grid.voxels.keys().copied().collect();(grid,keys)};let dims=grid.dimensions;
 for key in keys{let xyz=[key%dims[0],key/dims[0]%dims[1],key/(dims[0]*dims[1])];let p:[f32;3]=std::array::from_fn(|k|a[k]+(xyz[k] as f32+0.5)*fine_cell);
  let q:[i32;3]=std::array::from_fn(|k|crate::sampling::floor_i32((p[k]-minimum[k])*inv));if set.contains(&q){points.push(p);}
 }
 let mut inside=Vec::<[f32;3]>::new();let void_set:HashSet<_>=voids.unwrap_or_default().into_iter().collect();let mut emitted_markers=HashSet::default();let fi=1.0f32/fine_cell;
 if let Some(outside)=coarse_outside {
  let cd=coarse.dimensions;let cn=cd[0] as usize*cd[1] as usize*cd[2] as usize;
  if outside.len()!=cn || outside.iter().any(|&x|x>1){return Err(PyValueError::new_err("coarse outside mask must match coarse grid"));}
  let count=dims[0] as usize*dims[1] as usize*dims[2] as usize;
  if bounded && count>2_000_000{return Err(PyValueError::new_err("dense adaptive grid exceeds research bound"));}
  let decode=|key:usize|[key%dims[0] as usize,key/dims[0] as usize%dims[1] as usize,key/(dims[0] as usize*dims[1] as usize)];
  let center=|q:[usize;3]|std::array::from_fn::<_,3,_>(|k|a[k]+(q[k] as f32+0.5)*fine_cell);
  let mut flooded=vec![false;count];let mut queue=std::collections::VecDeque::new();
  let mut occupied=grid.voxels.keys().copied().peekable();
  for key in 0..count {
   let surface=if count<=u32::MAX as usize {if occupied.peek()==Some(&(key as u32)){occupied.next();true}else{false}}else{grid.voxels.contains_key(&(key as u32))};
   let p=center(decode(key));let delta:[f32;3]=std::array::from_fn(|k|p[k]-minimum[k]);
   let marker=delta.map(|x|crate::sampling::floor_i32(x*inv));let q=delta.map(|x|(x*ci).floor() as i64);
   let seed=!set.contains(&marker) || (0..3).any(|k|q[k]<0 || q[k]>=cd[k] as i64) || outside[(q[0]+q[1]*cd[0] as i64+q[2]*cd[0] as i64*cd[1] as i64) as usize]!=0;
   if seed && !surface{flooded[key]=true;queue.push_back(key);}
  }
  while let Some(key)=queue.pop_front(){let q=decode(key);
   for k in 0..3 {for d in [-1i64,1] {let value=q[k] as i64+d;if value<0 || value>=dims[k] as i64{continue;}
    let mut n=q;n[k]=value as usize;let index=n[0]+(n[1]+n[2]*dims[1] as usize)*dims[0] as usize;
    if !flooded[index] && !grid.voxels.contains_key(&(index as u32)){flooded[index]=true;queue.push_back(index);}
   }}
  }
  let mut occupied=grid.voxels.keys().copied().peekable();
  for key in 0..count {let surface=if count<=u32::MAX as usize {if occupied.peek()==Some(&(key as u32)){occupied.next();true}else{false}}else{grid.voxels.contains_key(&(key as u32))};if !flooded[key] && !surface {
   let p=center(decode(key));let q=std::array::from_fn(|k|crate::sampling::floor_i32((p[k]-minimum[k])*inv));if set.contains(&q){inside.push(p);}
  }}
 } else {
 // Native 0x70688 subdivides each marker, maps onto the snapped fine grid,
 // then emits non-surface centers. Explicit marker order is preserved.
 for marker in markers {if subdivisions==0 || !emitted_markers.insert(marker) || void_set.contains(&marker){continue;}
  for z in 0..subdivisions{for y in 0..subdivisions{for x in 0..subdivisions{
   let p:[f32;3]=std::array::from_fn(|k|(minimum[k]+marker[k] as f32*marker_cell)+([x,y,z][k] as f32+0.5)*fine_cell);
   let q:[i64;3]=std::array::from_fn(|k|((p[k]-a[k])*fi).floor() as i64);
   if (0..3).any(|k|q[k]<0 || q[k]>=dims[k] as i64){continue;}
   let key=q[0] as u32+(q[1] as u32+q[2] as u32*dims[1])*dims[0];
   if !grid.voxels.contains_key(&key){inside.push(std::array::from_fn(|k|a[k]+(q[k] as f32+0.5)*fine_cell));}
  }}}
 }
 }

 Ok((bounds,a,dims,selected,points,inside))
}
fn surface_result<'py>(py:Python<'py>,value:SurfaceResult,arrays:bool)->PyResult<Bound<'py,PyDict>>{
 let (bounds,a,dims,selected,points,inside)=value;
 let out=PyDict::new(py);out.set_item("detection_bounds",bounds)?;out.set_item("grid_minimum",a)?;out.set_item("grid_dimensions",dims)?;
 if arrays {
  let array=|v:Vec<[f32;3]>|numpy::PyArray2::from_owned_array(py,ndarray::Array2::from_shape_vec((v.len(),3),v.into_flattened()).unwrap());
  out.set_item("selected_faces",numpy::PyArray1::from_vec(py,selected))?;
  out.set_item("surface_points",array(points))?;out.set_item("inside_points",array(inside))?;
 }else{out.set_item("selected_faces",selected)?;out.set_item("surface_points",points)?;out.set_item("inside_points",inside)?;}
 Ok(out)
}
/// Detector-local geometry snapshot, never a process-global cache.
#[pyclass(module="_bvt_solver",frozen)]
pub struct _SurfaceQuery { vertices:ndarray::Array2<f32>,faces:ndarray::Array2<i32>,coarse:crate::voxel::SurfaceGrid,minimum:[f32;3],cell:f32,bounded:bool }
#[pymethods]
impl _SurfaceQuery {
 #[new]
 #[pyo3(signature=(vertices,faces,minimum,maximum,cell,bounded=true))]
 fn new(py:Python<'_>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,minimum:[f32;3],maximum:[f32;3],cell:f32,bounded:bool)->PyResult<Self>{
  let vertices=crate::array_input::owned_two(&vertices);let faces=crate::array_input::owned_two(&faces);
  let coarse=py.allow_threads(||crate::voxel::surface_grid_with_policy(vertices.view(),faces.view(),minimum,maximum,cell,bounded))?;
  Ok(Self{vertices,faces,coarse,minimum,cell,bounded})
 }
 #[pyo3(signature=(marker_cell,fine_cell,markers,subdivisions=0,voids=None,coarse_outside=None,surface_partitions=None,serial_split_depth=0))]
 fn query<'py>(&self,py:Python<'py>,marker_cell:f32,fine_cell:f32,markers:Vec<[i32;3]>,subdivisions:u32,voids:Option<Vec<[i32;3]>>,coarse_outside:Option<Vec<u8>>,surface_partitions:Option<Vec<usize>>,serial_split_depth:u32)->PyResult<Bound<'py,PyDict>>{
  let result=py.allow_threads(||{
   adaptive_cluster_check(&markers,subdivisions,marker_cell,fine_cell,self.bounded)?;
   adaptive_surface_geometry(self.vertices.view(),self.faces.view(),&self.coarse,self.minimum,self.cell,marker_cell,fine_cell,markers,subdivisions,voids,coarse_outside,surface_partitions,serial_split_depth,self.bounded)
  })?;
  surface_result(py,result,true)
 }
}

/// Final ordered cloud assembly, inline 0xae8xx..0xaf188; before ghost culling.
/// Level emission is an explicit input, so this does not claim automatic orchestration.
#[pyfunction]
#[pyo3(signature=(coarse_surface,coarse_inside,origin,coarse_cell,level_surfaces,level_interiors,level_cells,replace=true,bounded=true))]
pub fn assemble_adaptive_cloud<'py>(py:Python<'py>,coarse_surface:Vec<[i32;3]>,coarse_inside:Vec<[i32;3]>,origin:[f32;3],coarse_cell:f32,level_surfaces:Vec<Vec<[f32;3]>>,level_interiors:Vec<Vec<[f32;3]>>,level_cells:Vec<f32>,replace:bool,bounded:bool)->PyResult<Bound<'py,PyDict>>{
 let (positions,levels,radii)=py.allow_threads(move || assemble_owned(coarse_surface,coarse_inside,origin,coarse_cell,level_surfaces,level_interiors,level_cells,replace,bounded))?;
 let out=PyDict::new(py);out.set_item("cloud_positions",positions)?;out.set_item("cloud_levels",levels)?;out.set_item("cloud_radii",radii)?;Ok(out)
}

// Shared ordered assembly. The legacy list helper remains unchanged; the
// private array transport owns inputs before releasing the GIL.
fn assemble_owned(coarse_surface:Vec<[i32;3]>,coarse_inside:Vec<[i32;3]>,origin:[f32;3],coarse_cell:f32,level_surfaces:Vec<Vec<[f32;3]>>,level_interiors:Vec<Vec<[f32;3]>>,level_cells:Vec<f32>,replace:bool,bounded:bool)->PyResult<(Vec<[f32;3]>,Vec<u8>,Vec<f32>)>{

 // Membership only: emission continues to follow the original level streams.
 use rustc_hash::FxHashSet as HashSet;
 let count=level_cells.len();
 if (bounded && count>254) || level_surfaces.len()!=count || level_interiors.len()!=count || !(coarse_cell>0.0) || (bounded && !coarse_cell.is_finite()) || level_cells.iter().any(|&x|!(x>0.0)||(bounded && !x.is_finite())) || (bounded && origin.iter().any(|x|!x.is_finite())) || level_surfaces.iter().chain(&level_interiors).flatten().flatten().any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid adaptive cloud levels"));}
 let total=coarse_surface.len()+coarse_inside.len()+level_surfaces.iter().chain(&level_interiors).map(Vec::len).sum::<usize>();if bounded && total>2_000_000{return Err(PyValueError::new_err("adaptive cloud exceeds research bound"));}
 let replacements=|next:usize,cell:f32|->HashSet<[i64;3]>{
  if !replace || next>=count{return HashSet::default();}
  level_surfaces[next].iter().chain(&level_interiors[next]).map(|p|std::array::from_fn(|k|((p[k]-origin[k])/cell).floor() as i64)).collect()
 };
 let mut positions=Vec::new();let mut levels=Vec::new();let mut radii=Vec::new();
 let mut emit=|p:[f32;3],level:u8,cell:f32|{positions.push(p);levels.push(level);radii.push((cell as f64*0.8660254037844386) as f32);};
 let first=replacements(0,coarse_cell);
 for q in coarse_surface.iter().chain(&coarse_inside){if !first.contains(&q.map(i64::from)){emit(std::array::from_fn(|k|origin[k]+(q[k] as f32+0.5)*coarse_cell),0,coarse_cell);}}
 for j in 0..count{let cell=level_cells[j];let removed=replacements(j+1,cell);
  for &p in level_surfaces[j].iter().chain(&level_interiors[j]){
   // Native lookup truncates current coordinates; replacement insertion floors.
   let key=std::array::from_fn(|k|((p[k]-origin[k])/cell) as i64);
   if !removed.contains(&key){emit(p,(j+1) as u8,cell);}
  }
 }

 Ok((positions,levels,radii))
}

#[pyfunction]
#[pyo3(signature=(coarse_surface,coarse_inside,origin,coarse_cell,level_surfaces,level_interiors,level_cells,replace=true,bounded=true))]
pub fn _assemble_adaptive_arrays<'py>(py:Python<'py>,coarse_surface:Vec<[i32;3]>,coarse_inside:Vec<[i32;3]>,origin:[f32;3],coarse_cell:f32,level_surfaces:Vec<PyReadonlyArray2<'py,f32>>,level_interiors:Vec<PyReadonlyArray2<'py,f32>>,level_cells:Vec<f32>,replace:bool,bounded:bool)->PyResult<Bound<'py,PyDict>>{
 fn own(arrays:Vec<PyReadonlyArray2<'_,f32>>)->PyResult<Vec<Vec<[f32;3]>>>{
  arrays.into_iter().map(|array|{
   let a=array.as_array();if a.ncols()!=3{return Err(PyValueError::new_err("invalid adaptive cloud levels"));}
   Ok(a.rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect())
  }).collect()
 }
 let level_surfaces=own(level_surfaces)?;let level_interiors=own(level_interiors)?;
 let (positions,levels,radii)=py.allow_threads(move || assemble_owned(coarse_surface,coarse_inside,origin,coarse_cell,level_surfaces,level_interiors,level_cells,replace,bounded))?;
 let n=positions.len();let positions=ndarray::Array2::from_shape_vec((n,3),positions.into_iter().flatten().collect()).map_err(|e|PyValueError::new_err(e.to_string()))?;
 let out=PyDict::new(py);out.set_item("cloud_positions",numpy::PyArray2::from_owned_array(py,positions))?;out.set_item("cloud_levels",levels)?;out.set_item("cloud_radii",numpy::PyArray1::from_owned_array(py,ndarray::Array1::from_vec(radii)))?;Ok(out)
}
