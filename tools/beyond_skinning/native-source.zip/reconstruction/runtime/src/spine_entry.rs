//! Typed public torso detector; owns inputs before independent semantic mapping.
use pyo3::prelude::*;
use numpy::{PyReadonlyArray1,PyReadonlyArray3,PyArrayMethods,PyUntypedArrayMethods};
#[pyfunction]
#[pyo3(signature=(names,parent_idx,deform,segments=None))]
pub fn detect_spine(py:Python<'_>,names:Vec<String>,parent_idx:PyReadonlyArray1<'_,i64>,deform:PyReadonlyArray1<'_,bool>,segments:Option<PyReadonlyArray3<'_,f32>>)->PyResult<Py<PyAny>> {
 let p=crate::array_input::owned_one(&parent_idx).to_vec();
 let d=(0..deform.len()).map(|i|unsafe{deform.data().cast::<u8>().offset(i as isize*deform.strides()[0]).read()&1!=0}).collect::<Vec<_>>();
 if names.len()!=p.len()||names.len()!=d.len(){return Err(pyo3::exceptions::PyValueError::new_err("names, parent_idx and deform must share length"));}
 let s=if let Some(a)=segments{
  if a.shape()[0]>0&&(a.shape()[1]<2||a.shape()[2]<3){return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
  let x=crate::array_input::owned_three(&a);let v=(0..x.shape()[0]).map(|i|[[x[[i,0,0]],x[[i,0,1]],x[[i,0,2]]],[x[[i,1,0]],x[[i,1,1]],x[[i,1,2]]]]).collect::<Vec<_>>();Some(v)
 }else{None};
 let nn=names.iter().map(|n|n.split_once(':').map_or(n.as_str(),|(_,r)|r).trim().to_lowercase()).collect::<Vec<_>>();
 py.import("beyond_skinning.spine_mapping")?.getattr("detect_spine_owned")?.call1((names,nn,p,d,s)).map(Bound::unbind)
}
