//! Typed owned entry for public face seam labels; facial kernels remain shared.
use pyo3::prelude::*;
use pyo3::types::PyDict;
use numpy::{PyReadonlyArray1,PyReadonlyArray2,PyReadonlyArray3,IntoPyArray,PyArrayMethods,PyUntypedArrayMethods};
#[pyfunction]
#[pyo3(signature=(verts,edges,names,parent_idx,deform,segments,head_idx,seam=None,faces=None))]
pub fn face_seam_labels(py:Python<'_>,verts:PyReadonlyArray2<'_,f32>,edges:PyReadonlyArray2<'_,i64>,names:Vec<String>,parent_idx:PyReadonlyArray1<'_,i64>,deform:PyReadonlyArray1<'_,bool>,segments:PyReadonlyArray3<'_,f32>,head_idx:i64,seam:Option<f64>,faces:Option<PyReadonlyArray2<'_,i32>>)->PyResult<Py<PyAny>> {
 crate::cancel::check();
 if (verts.shape()[0]>0&&verts.shape()[1]<3)||(edges.shape()[0]>0&&edges.shape()[1]<2){return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
 if parent_idx.len()!=names.len()||deform.len()!=names.len()||segments.shape()[0]!=names.len(){return Err(pyo3::exceptions::PyValueError::new_err("names, parent_idx, deform and segments must agree"));}
 if !names.is_empty()&&(segments.shape()[1]<2||segments.shape()[2]<3){return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
 let v=crate::array_input::owned_two(&verts).into_pyarray(py);let e=crate::array_input::owned_two(&edges).into_pyarray(py);
 let p=crate::array_input::owned_one(&parent_idx).into_pyarray(py);
 let d=(0..deform.len()).map(|i|unsafe{deform.data().cast::<u8>().offset(i as isize*deform.strides()[0]).read()}).collect::<Vec<_>>();
 let s=crate::array_input::owned_three(&segments).into_pyarray(py);let f=faces.map(|f|crate::array_input::owned_two(&f).into_pyarray(py));
 let result=py.import("beyond_skinning.face_seam_public")?.getattr("assemble")?.call1((v,e,names,p,d,s,head_idx,seam,f))?;
 let out=PyDict::new(py);
 for (key,values) in result.downcast::<PyDict>()?.iter(){let values=values.extract::<Vec<u8>>()?;out.set_item(key,ndarray::Array1::from_vec(values).into_pyarray(py))?;}
 Ok(out.into_any().unbind())
}
