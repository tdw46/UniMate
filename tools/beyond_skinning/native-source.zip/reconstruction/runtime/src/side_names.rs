//! Recovered 0x152aa4/0x153574: numeric suffix, side markers and case policy.
use pyo3::prelude::*;
use std::sync::OnceLock;
fn split(name:&str)->(&str,&str){
 static RE:OnceLock<regex::Regex>=OnceLock::new();
 if let Some(c)=RE.get_or_init(||regex::Regex::new(r"^(.*[^.\d])(\.\d+)$").unwrap()).captures(name){let a=c.get(1).unwrap();let b=c.get(2).unwrap();(&name[a.start()..a.end()],&name[b.start()..b.end()])}else{(name,"")}
}
fn letter(c:char)->Option<char>{match c{'L'=>Some('R'),'R'=>Some('L'),'l'=>Some('r'),'r'=>Some('l'),_=>None}}
fn replace(c:&[char],at:usize,n:usize,word:&str)->String{c[..at].iter().copied().chain(word.chars()).chain(c[at+n..].iter().copied()).collect()}
fn flipped(s:&str,extra:bool)->Option<String>{
 let c:Vec<char>=s.chars().collect();let n=c.len();let delim=|x:char|"._- ".contains(x)||(extra&&":|".contains(x));
 if n>=2 {
  if delim(c[n-2]){if let Some(x)=letter(c[n-1]){return Some(replace(&c,n-1,1,&x.to_string()));}}
  if delim(c[1]){if let Some(x)=letter(c[0]){return Some(replace(&c,0,1,&x.to_string()));}}
 }
 let lower:Vec<char>=s.to_lowercase().chars().collect();
 if lower.len()==n {
  for i in 0..n {
   let (len,target)=if lower[i..].starts_with(&['l','e','f','t']){(4,"right")}else if lower[i..].starts_with(&['r','i','g','h','t']){(5,"left")}else{continue};let end=i+len;
   let before=i==0||delim(c[i-1])||(c[i-1].is_lowercase()&&c[i].is_uppercase());
   let after=end==n||delim(c[end])||!c[end].is_alphabetic()||c[end].is_uppercase();
   let start= c[i].is_uppercase() || i==0 || delim(c[i-1]);
   if before&&after&&start&&(extra||i!=0||end!=n){
    let word=if c[i..end].iter().all(|x|x.is_uppercase()){target.to_uppercase()}else if c[i].is_uppercase(){let mut word=target.to_owned();word[0..1].make_ascii_uppercase();word}else{target.to_owned()};
    return Some(replace(&c,i,len,&word));
   }
  }
 }
 if extra {
  for i in 0..n.saturating_sub(1) {
   if matches!(c[i],'L'|'R')&&c[i+1].is_uppercase()&&(i==0||c[i-1].is_lowercase()||c[i-1].is_ascii_digit()) {return Some(replace(&c,i,1,&letter(c[i]).unwrap().to_string()));}
  }
  if n==1 {if let Some(x)=letter(c[0]){return Some(x.to_string());}}
 }
 None
}
#[pyfunction]
pub fn flip_side(name:&str)->String{let (base,suffix)=split(name);match flipped(base,true){Some(x)=>x+suffix,None=>name.to_owned()}}
#[pyfunction]
pub fn blender_flips(name:&str)->bool{let (base,_)=split(name);flipped(base,false).is_some()}
