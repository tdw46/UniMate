//! Dense CPU diffusion reconstructed from 0x167f28 / 0x66f74 / 0x67688.
//! Original preprocessing is not implemented by this component.
use rayon::prelude::*;
use numpy::{PyArray2,PyReadonlyArray1,PyReadonlyArray2};
use pyo3::{exceptions::PyValueError,prelude::*};
fn error(s:&str)->PyErr{PyValueError::new_err(s.to_string())}
#[pyfunction]
#[pyo3(signature=(rows,columns,weights,dinv,fixed,seeds,iterations,initial=None,stop=None,stop_nonzero_only=false))]
pub fn solve_dense_cpu<'py>(py:Python<'py>,rows:PyReadonlyArray1<'py,u32>,columns:PyReadonlyArray1<'py,u32>,weights:PyReadonlyArray1<'py,f32>,dinv:PyReadonlyArray1<'py,f32>,fixed:PyReadonlyArray1<'py,u8>,seeds:PyReadonlyArray2<'py,f32>,iterations:u32,initial:Option<PyReadonlyArray2<'py,f32>>,stop:Option<(u32,f32,f32)>,stop_nonzero_only:bool)->PyResult<(Bound<'py,PyArray2<f32>>,u32)>{
 let rows=rows.as_slice()?;let columns=columns.as_slice()?;let weights=weights.as_slice()?;let dinv=dinv.as_slice()?;let fixed=fixed.as_slice()?;let seed_array=seeds.as_array();let n=seed_array.nrows();let k=seed_array.ncols();let seeds=seeds.as_slice()?;
 if k==0 || rows.len()!=n+1 || rows.first()!=Some(&0) || rows.last().copied().map(|x|x as usize)!=Some(columns.len()) || rows.windows(2).any(|x|x[0]>x[1]) || columns.len()!=weights.len() || columns.iter().any(|&c|c as usize>=n) || fixed.len()!=n || dinv.len()!=n {return Err(error("inconsistent dense CPU graph/seeds"));}
 if stop.is_some_and(|(batch,tol,fraction)|batch==0 || !tol.is_finite() || tol<0. || !fraction.is_finite() || !(0.0..=1.0).contains(&fraction)){return Err(error("invalid dense CPU stopping policy"));}
 let mut a=if let Some(initial)=initial {let arr=initial.as_array();if arr.shape()!=[n,k]{return Err(error("initial field shape differs from seeds"));}initial.as_slice()?.to_vec()}else{vec![0.;seeds.len()]};
 for i in 0..n {if fixed[i]&1!=0 {a[i*k..(i+1)*k].copy_from_slice(&seeds[i*k..(i+1)*k]);}}
 let (a,done)=py.allow_threads(||{
  let mut b=a.clone();let mut checkpoint=if stop.is_some(){a.clone()}else{Vec::new()};let mut omega=1.0f32;let mut done=0;
  for it in 0..iterations {
   crate::cancel::check();
   omega=if it==0 {1.}else if it==1{1.9609766}else{1./((omega * -0.98010004)*0.25+1.)};
   let update = |(block, outputs):(usize,&mut [f32])| {
    let mut row=vec![0.0f32;k];
    for (offset, output) in outputs.chunks_exact_mut(k).enumerate() {
    let i=block*128+offset;
    let start=rows[i] as usize;let end=rows[i+1] as usize;
    if fixed[i]&1!=0 {output.copy_from_slice(&seeds[i*k..(i+1)*k]);continue;}
    // Recovered recurrence (Rea/Kuna 0x167f28): keep CSR edge order
    // within each column, but walk contiguous bone rows for SIMD. Assign
    // the first product rather than add to zero (signed-zero parity).
    if start==end {row.fill(0.);} else {
     let first=&a[columns[start] as usize*k..(columns[start] as usize+1)*k];
     for (value,&input) in row.iter_mut().zip(first){*value=weights[start]*input;}
     for e in start+1..end {
      let input=&a[columns[e] as usize*k..(columns[e] as usize+1)*k];
      for (value,&input) in row.iter_mut().zip(input){*value+=weights[e]*input;}
     }
     for value in &mut row {*value*=dinv[i];}
    }
    if omega==1. {output.copy_from_slice(&row);} else {
     for (output,&value) in output.iter_mut().zip(&row){*output=*output+omega*(value-*output);}
    }
   }
   };
   if n>=4096 {b.par_chunks_mut(k*128).enumerate().for_each(update);}
   else {b.chunks_mut(k*128).enumerate().for_each(update);}
   std::mem::swap(&mut a,&mut b);done=it+1;
   if let Some((batch,tol,fraction))=stop {if done<iterations && done%batch==0 {
    let mut max_delta=0.0f32;let mut moving=0usize;let mut population=0usize;
    for (&x,&p) in a.iter().zip(&checkpoint){if !stop_nonzero_only || x!=0. || p!=0. {population+=1;}let d=(x-p).abs();max_delta=max_delta.max(d);if d>tol{moving+=1;}}
    if max_delta<=tol || moving as f64<=fraction as f64*population as f64 {break;}
    checkpoint.copy_from_slice(&a);
   }}
  }
  (a,done)
 });
 let array=ndarray::Array2::from_shape_vec((n,k),a).map_err(|e|error(&e.to_string()))?;
 Ok((PyArray2::from_owned_array(py,array),done))
}

// The recovered sparse recurrence accumulates edges in CSR order. Exposing
// the common 16-slot row width to LLVM removes repeated row/index arithmetic;
// no fused multiply-add, reassociation, approximate values or unsafe accesses.
#[inline(always)]
fn accumulate_sparse_prefix<const WIDTH:usize>(output:&mut [f32], maps:&[u8], columns:&[u32], weights:&[f32], field:&[f32]) {
 let output: &mut [f32;WIDTH]=(&mut output[..WIDTH]).try_into().unwrap();
 for ((map,&column),&weight) in maps.chunks_exact(16).zip(columns).zip(weights) {
  let begin=column as usize*16;
  let input=&field[begin..begin+16];
  let map:&[u8;16]=map.try_into().unwrap();
  for j in 0..WIDTH {let slot=map[j];if slot!=255 {output[j]+=weight*input[slot as usize];}}
 }
}

/// Sparse CPU rows retain their own group slots; the edge map maps destination
/// slots to each source row. 255 marks an absent group, never a valid slot.
#[pyfunction]
#[pyo3(signature=(rows,columns,weights,dinv,edge_map,groups,initial,fixed,seed_indices,iterations,seed_values=None,stop=None,stop_nonzero_only=false))]
pub fn solve_sparse_cpu<'py>(py:Python<'py>,rows:PyReadonlyArray1<'py,u32>,columns:PyReadonlyArray1<'py,u32>,weights:PyReadonlyArray1<'py,f32>,dinv:PyReadonlyArray1<'py,f32>,edge_map:PyReadonlyArray1<'py,u8>,groups:PyReadonlyArray2<'py,u16>,initial:PyReadonlyArray2<'py,f32>,fixed:PyReadonlyArray1<'py,u8>,seed_indices:PyReadonlyArray1<'py,u32>,iterations:u32,seed_values:Option<PyReadonlyArray1<'py,f32>>,stop:Option<(u32,f32,f32)>,stop_nonzero_only:bool)->PyResult<(Bound<'py,PyArray2<f32>>,u32)>{
 let rows=rows.as_slice()?;let columns=columns.as_slice()?;let weights=weights.as_slice()?;let dinv=dinv.as_slice()?;let fixed=fixed.as_slice()?;let shape=groups.as_array();let n=shape.nrows();let k=shape.ncols();let groups=groups.as_slice()?;let edge_map=edge_map.as_slice()?;let seed_indices=seed_indices.as_slice()?;let seed_values=seed_values.as_ref().map(|a|a.as_slice()).transpose()?;
 if k==0 || k>255 || initial.as_array().shape()!=[n,k] || rows.len()!=n+1 || rows.first()!=Some(&0) || rows.last().copied().map(|x|x as usize)!=Some(columns.len()) || rows.windows(2).any(|x|x[0]>x[1]) || columns.len()!=weights.len() || columns.iter().any(|&c|c as usize>=n) || fixed.len()!=n || dinv.len()!=n || edge_map.len()!=columns.len()*k || edge_map.iter().any(|&x|x!=255 && x as usize>=k) || seed_indices.len()!=n || seed_values.is_some_and(|v|v.len()!=n){return Err(error("inconsistent sparse CPU graph/seeds"));}
 if stop.is_some_and(|(batch,tol,fraction)|batch==0 || !tol.is_finite() || tol<0. || !fraction.is_finite() || !(0.0..=1.0).contains(&fraction)){return Err(error("invalid sparse CPU stopping policy"));}
 let mut a=initial.as_slice()?.to_vec();
 let seed_row=|i:usize,output:&mut[f32]|{for j in 0..k{output[j]=if groups[i*k+j]!=u16::MAX && groups[i*k+j] as u32==seed_indices[i]{seed_values.map_or(1.,|v|v[i])}else{0.};}};
 for i in 0..n{if fixed[i]&1!=0{seed_row(i,&mut a[i*k..(i+1)*k]);}}
 let (a,done)=py.allow_threads(||{
  let mut b=a.clone();let mut checkpoint=if stop.is_some(){a.clone()}else{Vec::new()};let mut omega=1.0f32;let mut done=0;
  // Validate actual map support once, not group names or an assumed padding
  // invariant. Malformed-but-admitted map/group combinations retain every
  // explicit destination contribution. Only trailing 255 slots may be skipped.
  let widths=if k==16&&iterations>0 {
   let mut widths=vec![0u8;n];
   for i in 0..n {
    if i%1024==0{crate::cancel::check();}
    if fixed[i]&1!=0{continue;}
    let mut width=0;
    for map in edge_map[rows[i] as usize*16..rows[i+1] as usize*16].chunks_exact(16) {
     if let Some(last)=map.iter().rposition(|&slot|slot!=255){width=width.max(last+1);if width==16{break;}}
    }
    widths[i]=width as u8;
   }widths
  }else{Vec::new()};
  for it in 0..iterations{
   crate::cancel::check();
   omega=if it==0{1.}else if it==1{1.9609766}else{1./((omega * -0.98010004)*0.25+1.)};
   let update = |(block,outputs):(usize,&mut [f32])| {
    let mut scratch=[0.0f32;255];
    for (offset,output) in outputs.chunks_exact_mut(k).enumerate() {
    let i=block*128+offset;
    if fixed[i]&1!=0{seed_row(i,output);continue;}
    if rows[i]==rows[i+1]{output.fill(0.);continue;}
    let accum=&mut scratch[..k];accum.fill(0.);
    if k==16 {
     let start=rows[i] as usize;let end=rows[i+1] as usize;
     let maps=&edge_map[start*16..end*16];let cols=&columns[start..end];let ws=&weights[start..end];
     match widths[i] {
      0=>{},
      1=>accumulate_sparse_prefix::<1>(accum,maps,cols,ws,&a),
      2=>accumulate_sparse_prefix::<2>(accum,maps,cols,ws,&a),
      3=>accumulate_sparse_prefix::<3>(accum,maps,cols,ws,&a),
      4=>accumulate_sparse_prefix::<4>(accum,maps,cols,ws,&a),
      5=>accumulate_sparse_prefix::<5>(accum,maps,cols,ws,&a),
      6=>accumulate_sparse_prefix::<6>(accum,maps,cols,ws,&a),
      7=>accumulate_sparse_prefix::<7>(accum,maps,cols,ws,&a),
      8=>accumulate_sparse_prefix::<8>(accum,maps,cols,ws,&a),
      9=>accumulate_sparse_prefix::<9>(accum,maps,cols,ws,&a),
      10=>accumulate_sparse_prefix::<10>(accum,maps,cols,ws,&a),
      11=>accumulate_sparse_prefix::<11>(accum,maps,cols,ws,&a),
      12=>accumulate_sparse_prefix::<12>(accum,maps,cols,ws,&a),
      13=>accumulate_sparse_prefix::<13>(accum,maps,cols,ws,&a),
      14=>accumulate_sparse_prefix::<14>(accum,maps,cols,ws,&a),
      15=>accumulate_sparse_prefix::<15>(accum,maps,cols,ws,&a),
      _=>accumulate_sparse_prefix::<16>(accum,maps,cols,ws,&a),
     }
    } else {
    for e in rows[i] as usize..rows[i+1] as usize{for j in 0..k{let slot=edge_map[e*k+j];if slot!=255{accum[j]+=weights[e]*a[columns[e] as usize*k+slot as usize];}}}
    }
    for j in 0..k{let value=accum[j]*dinv[i];output[j]=if omega!=1.{let p=output[j];p+omega*(value-p)}else{value};}
   }
   };
   if n>=4096 {b.par_chunks_mut(k*128).enumerate().for_each(update);}
   else {b.chunks_mut(k*128).enumerate().for_each(update);}
   std::mem::swap(&mut a,&mut b);done=it+1;
   if let Some((batch,tol,fraction))=stop{if done<iterations && done%batch==0{
    let mut max_delta=0.0f32;let mut moving=0usize;let mut population=0usize;
    for (&x,&p) in a.iter().zip(&checkpoint){if !stop_nonzero_only || x!=0. || p!=0.{population+=1;}let d=(x-p).abs();max_delta=max_delta.max(d);if d>tol{moving+=1;}}
    if max_delta<=tol || moving as f64<=fraction as f64*population as f64{break;}
    checkpoint.copy_from_slice(&a);
   }}
  }
  (a,done)
 });
 let array=ndarray::Array2::from_shape_vec((n,k),a).map_err(|e|error(&e.to_string()))?;
 Ok((PyArray2::from_owned_array(py,array),done))
}
