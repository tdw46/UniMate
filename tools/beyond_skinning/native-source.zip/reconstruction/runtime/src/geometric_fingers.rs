//! Public geometry detector extraction and owned snapshots.
use pyo3::prelude::*;
use numpy::{PyArray2,PyReadonlyArray1,PyArrayMethods,PyUntypedArrayMethods};
#[pyfunction]
pub fn detect_fingers_geometric(py:Python<'_>,heads:Bound<'_,PyArray2<f32>>,tails:Bound<'_,PyArray2<f32>>,parent_idx:PyReadonlyArray1<'_,i64>,cone_mask:PyReadonlyArray1<'_,bool>)->PyResult<Py<PyAny>> {
 let h=heads.readonly();let t=tails.readonly();
 let xyz=|a:&numpy::PyReadonlyArray2<'_,f32>|->PyResult<Vec<[f32;3]>>{
  if a.shape()[0]>0 && a.shape()[1]<3{return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
  let x=crate::array_input::two(a);Ok((0..x.nrows()).map(|i|[x[[i,0]],x[[i,1]],x[[i,2]]]).collect())
 };
 let h=xyz(&h)?;let t=xyz(&t)?;let p=crate::array_input::owned_one(&parent_idx).to_vec();
 let m=(0..cone_mask.len()).map(|i|unsafe{cone_mask.data().cast::<u8>().offset(i as isize*cone_mask.strides()[0]).read()&1!=0}).collect::<Vec<_>>();
 py.import("beyond_skinning.finger_geometry")?.getattr("_public_geometric_fingers")?.call1((h,t,p,m)).map(Bound::unbind)
}
