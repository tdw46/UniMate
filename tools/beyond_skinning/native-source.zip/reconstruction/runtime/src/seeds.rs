//! Nearest segment IDs used during seed preparation (0x5aa74).
//! Does not yet construct constrained/dense/finger/trunk seed fields.
use numpy::PyReadonlyArray2;
use rayon::prelude::*;
use pyo3::{prelude::*,exceptions::PyValueError};
// Validated three-component geometry from the recovered 0x5aa74/0x622dc
// workers. Borrow ordinary contiguous inputs; own only the strided fallback.
// Fixed row width removes ndarray stride/index work from point/bone hot loops.
fn triples<'a>(array:&'a PyReadonlyArray2<'_,f32>)->std::borrow::Cow<'a,[[f32;3]]>{
 // NumPy also calls Fortran-order arrays contiguous; only C layout is xyz
 // row storage. Preserve all other layouts through logical row extraction.
 if array.as_array().is_standard_layout(){
  if let Ok(flat)=array.as_slice(){let (rows,tail)=flat.as_chunks::<3>();debug_assert!(tail.is_empty());return std::borrow::Cow::Borrowed(rows);}
 }
 std::borrow::Cow::Owned(array.as_array().rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect())
}

#[pyfunction]
pub fn nearest_seed_bones(py:Python<'_>,points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>)->PyResult<Vec<u32>>{
 let p=points.as_array();let h=heads.as_array();let t=tails.as_array();
 if p.ncols()!=3 || h.ncols()!=3 || t.shape()!=h.shape() || p.iter().chain(h.iter()).chain(t.iter()).any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid seed segment geometry"));}
 let p=triples(&points).into_owned();let h=triples(&heads);let t=triples(&tails);
 let segments:Vec<_>=(0..h.len()).map(|i|{let d=std::array::from_fn::<_,3,_>(|k|t[i][k]-h[i][k]);let length=(d[0]*d[0]+d[1]*d[1])+d[2]*d[2];(h[i],d,length)}).collect();
 let query=|point:&[f32;3]|{
  let mut best=f32::INFINITY;let mut id=0;
  for (i,&(head,d,length)) in segments.iter().enumerate(){
   let f=if length<=1e-12{0.0}else{
    let projection=(((point[0]-head[0])*d[0]+(point[1]-head[1])*d[1])+(point[2]-head[2])*d[2])/length;
    let low=if projection<0.0{0.0}else{projection};if low<=1.0{low}else{1.0}
   };
   let delta=std::array::from_fn::<_,3,_>(|k|point[k]-(head[k]+d[k]*f));let distance=delta[2]*delta[2]+(delta[0]*delta[0]+delta[1]*delta[1]);
   if distance<best{best=distance;id=i as u32;}
  }id
 };
 // Four independent points share the bone traversal. Each lane retains the
 // scalar arithmetic, first-bone tie rule and NaN comparison behavior.
 // No horizontal sums, fused operations, or approximate reciprocals.
 let packet=|(chunk,out):(&[[f32;3]],&mut [u32])| {
  if chunk.len()!=4 {for (point,id) in chunk.iter().zip(out){*id=query(point);}return;}
  use crate::sampling::{add4,sub4,mul4};
  let points:[[f32;4];3]=std::array::from_fn(|a|std::array::from_fn(|lane|chunk[lane][a]));
  let mut best=[f32::INFINITY;4];let mut ids=[0u32;4];
  for (bone,&(head,d,length)) in segments.iter().enumerate(){
   let f=if length<=1e-12{[0.0;4]}else{
    let delta: [[f32;4];3]=std::array::from_fn(|a|sub4(points[a],[head[a];4]));
    let dot=add4(add4(mul4(delta[0],[d[0];4]),mul4(delta[1],[d[1];4])),mul4(delta[2],[d[2];4]));
    div4(dot,[length;4]).map(|x|{let low=if x<0.0{0.0}else{x};if low<=1.0{low}else{1.0}})
   };
   let delta: [[f32;4];3]=std::array::from_fn(|a|sub4(points[a],add4([head[a];4],mul4([d[a];4],f))));
   let distance=add4(mul4(delta[2],delta[2]),add4(mul4(delta[0],delta[0]),mul4(delta[1],delta[1])));
   for lane in 0..4{if distance[lane]<best[lane]{best[lane]=distance[lane];ids[lane]=bone as u32;}}
  }
  out.copy_from_slice(&ids);
 };
 Ok(py.allow_threads(||{
  let mut output=vec![0u32;p.len()];
  if p.len()>=1024 {p.par_chunks(4).zip(output.par_chunks_mut(4)).with_min_len(64).for_each(packet);}
  else {for pair in p.chunks(4).zip(output.chunks_mut(4)){packet(pair);}}
  output
 }))
}

#[inline(always)] fn div4(a:[f32;4],b:[f32;4])->[f32;4]{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*;return std::mem::transmute(vdivq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*;return std::mem::transmute(_mm_div_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]/b[i])}
}

/// Surface-to-bone-group association with inward-normal preference (0x198664).
/// Group creation and constrained seed strengths remain separate open stages.
#[pyfunction]
pub fn normal_seed_groups(points:PyReadonlyArray2<'_,f32>,normals:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,groups:Vec<Vec<usize>>)->PyResult<Vec<usize>>{
 let p=points.as_array();let ns=normals.as_array();let h=heads.as_array();let t=tails.as_array();
 if p.ncols()!=3 || ns.shape()!=p.shape() || h.ncols()!=3 || t.shape()!=h.shape() || p.iter().chain(ns.iter()).chain(h.iter()).chain(t.iter()).any(|v|!v.is_finite()) || groups.iter().flatten().any(|&i|i>=h.nrows()){return Err(PyValueError::new_err("invalid normal-guided seed group inputs"));}
 let mut result=Vec::with_capacity(p.nrows());
 for (i,point) in p.rows().into_iter().enumerate(){
  let mut nearest=0;let mut nearest_distance=f32::INFINITY;let mut candidates=Vec::with_capacity(groups.len());
  for (group,bones) in groups.iter().enumerate(){
   let mut best=f32::INFINITY;let mut closest=[0.0f32;3];
   for &bone in bones {
    let d:[f64;3]=std::array::from_fn(|k|(t[[bone,k]]-h[[bone,k]]) as f64);
    let delta:[f64;3]=std::array::from_fn(|k|(point[k]-h[[bone,k]]) as f64);
    let length=(d[0]*d[0]+d[1]*d[1])+d[2]*d[2];
    let f=((delta[0]*d[0]+delta[1]*d[1])+delta[2]*d[2])/if length==0.0{1.0}else{length};
    let low=if f<0.0{0.0}else{f};let factor=if low<=1.0{low}else{1.0};
    let q:[f64;3]=std::array::from_fn(|k|d[k]*factor+h[[bone,k]] as f64);
    let dist:[f64;3]=std::array::from_fn(|k|point[k] as f64-q[k]);
    let distance=(dist[2]*dist[2]+(dist[0]*dist[0]+dist[1]*dist[1])).sqrt() as f32;
    if distance<best {best=distance;closest=q.map(|v|v as f32);}
   }
   if best<nearest_distance {nearest=group;nearest_distance=best;}
   candidates.push((best,closest));
  }
  let limit=nearest_distance*2.5;
  let n=[ns[[i,0]],ns[[i,1]],ns[[i,2]]];let length=((n[0]*n[0]+n[1]*n[1])+n[2]*n[2]).sqrt();
  if !(length<1e-9){
   let mut score=f32::NEG_INFINITY;let mut selected=nearest;
   for (group,(distance,q)) in candidates.into_iter().enumerate(){
    if distance<=limit {
     let d=[q[0]-point[0],q[1]-point[1],q[2]-point[2]];let len=(d[2]*d[2]+(d[1]*d[1]+d[0]*d[0])).sqrt();
     if !(len<1e-9){let dot=((-n[2]/length)*d[2]+((-n[1]/length)*d[1]+(-n[0]/length)*d[0]))/len;
      if dot>score{score=dot;selected=group;}
     }
    }
   }
   if !(score<0.25){nearest=selected;}
  }
  result.push(nearest);
 }
 Ok(result)
}

/// Profile membership for seed constraints, native serial worker 0x657a4.
/// Ordinary segments are flat-ended and use a piecewise-linear head/mid/tail
/// radius. Degenerate segments become spheres using the largest radius.
#[pyfunction]
pub fn seed_profile_masks(points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,radius_head:Vec<f32>,radius_tail:Vec<f32>,radius_mid:Vec<f32>)->PyResult<Vec<Vec<u8>>>{
 let p=points.as_array();let h=heads.as_array();let t=tails.as_array();
 if p.ncols()!=3 || h.ncols()!=3 || t.shape()!=h.shape() || [radius_head.len(),radius_tail.len(),radius_mid.len()].iter().any(|&n|n!=h.nrows()) || p.iter().chain(h.iter()).chain(t.iter()).chain(radius_head.iter()).chain(radius_tail.iter()).chain(radius_mid.iter()).any(|v|!v.is_finite()) {return Err(PyValueError::new_err("invalid seed profile inputs"));}
 let mut output=vec![vec![0u8;p.nrows()];h.nrows()];
 for bone in 0..h.nrows(){let d:[f32;3]=std::array::from_fn(|k|t[[bone,k]]-h[[bone,k]]);let len2=(d[0]*d[0]+d[1]*d[1])+d[2]*d[2];
  for (i,point) in p.rows().into_iter().enumerate(){let q:[f32;3]=std::array::from_fn(|k|point[k]-h[[bone,k]]);
   let inside=if len2<1e-12 {let radius=radius_head[bone].max(radius_tail[bone]).max(radius_mid[bone]);((q[0]*q[0]+q[1]*q[1])+q[2]*q[2])<=radius*radius}
   else {let u=((d[0]*q[0]+d[1]*q[1])+d[2]*q[2])/len2;
    if u<0.0 || u>1.0 {false}else{let (start,change,v)=if u>0.5{(radius_mid[bone],radius_tail[bone]-radius_mid[bone],u-0.5)}else{(radius_head[bone],radius_mid[bone]-radius_head[bone],u)};
     let radius=start+change*(v+v);let delta:[f32;3]=std::array::from_fn(|k|point[k]-(h[[bone,k]]+d[k]*u));((delta[0]*delta[0]+delta[1]*delta[1])+delta[2]*delta[2])<=radius*radius
    }
   };output[bone][i]=inside as u8;
  }
 }Ok(output)
}

/// Independently recovered 0x622dc shape modes. Unsupported modes fail closed.
/// This is the constraint-mask stage, not complete seed-field assembly.
#[pyfunction]
#[pyo3(signature=(points,heads,tails,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers=None,cell_size=0.1,reference_length=0.0,oriented=None,base_radii=None,point_radii=None,axial_padding=0.0,body_scale=1.0,separation=1.0,custom_shapes=None))]
pub fn constrained_seed_masks(py:Python<'_>,points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,radius_head:Vec<f32>,radius_tail:Vec<f32>,radius_mid:Vec<f32>,kinds:Vec<u8>,labels:Vec<i32>,sphere_radii:Vec<f32>,centers:Option<Vec<[f32;3]>>,cell_size:f32,reference_length:f32,oriented:Option<Vec<[f32;13]>>,base_radii:Option<Vec<f32>>,point_radii:Option<Vec<f32>>,axial_padding:f32,body_scale:f32,separation:f32,custom_shapes:Option<Vec<Bound<'_,pyo3::types::PyDict>>>)->PyResult<Vec<Vec<u8>>>{
 constrained_masks_owned(py,points,heads,tails,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers,cell_size,reference_length,oriented,base_radii,point_radii,axial_padding,body_scale,separation,custom_shapes,None)
}
fn constrained_masks_owned(py:Python<'_>,points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,radius_head:Vec<f32>,radius_tail:Vec<f32>,radius_mid:Vec<f32>,kinds:Vec<u8>,labels:Vec<i32>,sphere_radii:Vec<f32>,centers:Option<Vec<[f32;3]>>,cell_size:f32,reference_length:f32,oriented:Option<Vec<[f32;13]>>,base_radii:Option<Vec<f32>>,point_radii:Option<Vec<f32>>,axial_padding:f32,body_scale:f32,separation:f32,custom_shapes:Option<Vec<Bound<'_,pyo3::types::PyDict>>>,range:Option<(usize,usize)>)->PyResult<Vec<Vec<u8>>>{
 let prepared=prepare_masks(py,points,heads,tails,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers,cell_size,reference_length,oriented,base_radii,point_radii,axial_padding,body_scale,separation,custom_shapes,range)?;
 let (begin,end)=range.unwrap_or((0,prepared.h.len()));
 prepared.compute(py,begin,end,range.is_some())
}
fn prepare_masks(_py:Python<'_>,points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,radius_head:Vec<f32>,radius_tail:Vec<f32>,radius_mid:Vec<f32>,kinds:Vec<u8>,labels:Vec<i32>,sphere_radii:Vec<f32>,centers:Option<Vec<[f32;3]>>,cell_size:f32,reference_length:f32,oriented:Option<Vec<[f32;13]>>,base_radii:Option<Vec<f32>>,point_radii:Option<Vec<f32>>,axial_padding:f32,body_scale:f32,separation:f32,custom_shapes:Option<Vec<Bound<'_,pyo3::types::PyDict>>>,range:Option<(usize,usize)>)->PyResult<_PreparedSeedMasks>{
 let p=points.as_array();let h=heads.as_array();let t=tails.as_array();let b=h.nrows();
 if !separation.is_finite() || !body_scale.is_finite() || !axial_padding.is_finite() || base_radii.as_ref().is_some_and(|v|v.len()!=b || v.iter().any(|x|!x.is_finite())) || point_radii.as_ref().is_some_and(|v|v.len()!=p.nrows() || v.iter().any(|x|!x.is_finite())) || oriented.as_ref().is_some_and(|x|x.len()!=b || x.iter().flatten().any(|v|!v.is_finite())) || !cell_size.is_finite() || !reference_length.is_finite() || p.ncols()!=3 || h.ncols()!=3 || t.shape()!=h.shape() || [radius_head.len(),radius_tail.len(),radius_mid.len(),kinds.len(),sphere_radii.len()].iter().any(|&n|n!=b) || labels.len()!=p.nrows() || centers.as_ref().is_some_and(|v|v.len()!=b) || kinds.iter().any(|k|!matches!(k,0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18)) || p.iter().chain(h.iter()).chain(t.iter()).chain(radius_head.iter()).chain(radius_tail.iter()).chain(radius_mid.iter()).chain(sphere_radii.iter()).any(|v|!v.is_finite()) || centers.as_ref().is_some_and(|v|v.iter().flatten().any(|x|!x.is_finite())) {return Err(PyValueError::new_err("unsupported or invalid constrained seed inputs"));}
 let shapes=custom_shapes.as_ref().map(|rows|rows.iter().map(crate::seed_shapes::Shape::decode).collect::<PyResult<Vec<_>>>()).transpose()?;
 if shapes.as_ref().is_some_and(|v|v.len()!=b){return Err(PyValueError::new_err("custom shape row count mismatch"));}
 if let Some((begin,end))=range{if begin>end||end>b||(end-begin).saturating_mul(p.nrows())>4_000_000{return Err(PyValueError::new_err("seed mask block budget exceeded"));}}
 // Owned geometry survives GIL release. Each row keeps the full ordered cloud.
 let p=triples(&points).into_owned();let h=triples(&heads).into_owned();let t=triples(&tails).into_owned();
 Ok(_PreparedSeedMasks{p,h,t,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers,cell_size,reference_length,oriented,base_radii,point_radii,axial_padding,body_scale,separation,shapes})

}
/// Immutable per-bind seed inputs. Each block keeps the original full cloud.
#[pyclass(module="_bvt_solver", frozen)]
pub struct _PreparedSeedMasks{p:Vec<[f32;3]>,h:Vec<[f32;3]>,t:Vec<[f32;3]>,radius_head:Vec<f32>,radius_tail:Vec<f32>,radius_mid:Vec<f32>,kinds:Vec<u8>,labels:Vec<i32>,sphere_radii:Vec<f32>,centers:Option<Vec<[f32;3]>>,cell_size:f32,reference_length:f32,oriented:Option<Vec<[f32;13]>>,base_radii:Option<Vec<f32>>,point_radii:Option<Vec<f32>>,axial_padding:f32,body_scale:f32,separation:f32,shapes:Option<Vec<crate::seed_shapes::Shape>>}
impl _PreparedSeedMasks {
 fn compute(&self,py:Python<'_>,begin:usize,end:usize,cancellable:bool)->PyResult<Vec<Vec<u8>>>{
let p=&self.p;let h=&self.h;let t=&self.t;let b=h.len();
 let radius_head=&self.radius_head;
 let radius_tail=&self.radius_tail;
 let radius_mid=&self.radius_mid;
 let kinds=&self.kinds;
 let labels=&self.labels;
 let sphere_radii=&self.sphere_radii;
 let centers=&self.centers;
 let oriented=&self.oriented;
 let base_radii=&self.base_radii;
 let point_radii=&self.point_radii;
 let shapes=&self.shapes;
 let cell_size=self.cell_size;
 let reference_length=self.reference_length;
 let axial_padding=self.axial_padding;
 let body_scale=self.body_scale;
 let separation=self.separation;
 if begin>end||end>b||(cancellable && (end-begin).saturating_mul(p.len())>4_000_000){return Err(PyValueError::new_err("seed mask block budget exceeded"));}
 let output=py.allow_threads(||{
 let mut output=vec![vec![0u8;p.len()];end-begin];
 let run=|(offset,mask_row):(usize,&mut Vec<u8>)| {
 for bone in begin+offset..begin+offset+1{if cancellable{crate::cancel::check();}let mut kind=kinds[bone];let d:[f32;3]=std::array::from_fn(|k|t[bone][k]-h[bone][k]);let len2=(d[0]*d[0]+d[1]*d[1])+d[2]*d[2];
  if kind==17 {
   if let Some(shape)=shapes.as_ref().map(|s|&s[bone]).filter(|s|!matches!(s,crate::seed_shapes::Shape::None)){
    for (i,p) in p.iter().enumerate(){mask_row[i]=shape.hit([p[0],p[1],p[2]]) as u8;}
    if !mask_row.contains(&1){let center=shape.fallback_center();let base=base_radii.as_ref().map(|v|v[bone]).unwrap_or(0.0);let mut scale=1.0f32;
     for _ in 0..6{let mut count=0;for (i,point) in p.iter().enumerate(){let radius=base.max(scale*point_radii.as_ref().map(|v|v[i]).unwrap_or(cell_size.max(1e-9)*0.87));let q:[f32;3]=std::array::from_fn(|k|point[k]-center[k]);let hit=(q[0]*q[0]+q[1]*q[1])+q[2]*q[2]<=radius*radius;mask_row[i]=hit as u8;count+=hit as usize;}if count>=2{break;}scale*=1.6;}
    }continue;
   }kind=6;
  }
  if kind==10 {
   if let Some(rows)=&oriented{let row=rows[bone];let length=row[9];if length>0.0{
    let axis=[row[3],row[4],row[5]];let lateral=[row[6],row[7],row[8]];let cross=[axis[1]*lateral[2]-axis[2]*lateral[1],axis[2]*lateral[0]-axis[0]*lateral[2],axis[0]*lateral[1]-axis[1]*lateral[0]];
    let dot=|a:[f32;3],b:[f32;3]|(a[0]*b[0]+a[1]*b[1])+a[2]*b[2];
    let hit=|q:[f32;3]|{let along=dot(axis,q);let u=along/length;let width=row[10]+u*((row[11]-row[10])*u);along>=0.0 && along<=length && dot(lateral,q).abs()<=width && dot(cross,q).abs()<=row[12]};
    for (i,point) in p.iter().enumerate(){let q=std::array::from_fn(|k|point[k]-row[k]);let shifted=std::array::from_fn(|k|q[k]-cell_size.max(0.0)*axis[k]);mask_row[i]=(hit(q)&&hit(shifted)) as u8;}
   }}continue;
  }
  if kind==18 {
   let dist=|p:[f32;3],a:[f32;3],d:[f32;3],len:f32|{let q:[f32;3]=std::array::from_fn(|k|p[k]-a[k]);let u=if len>1e-12{(((d[0]*q[0]+d[1]*q[1])+d[2]*q[2])/len).clamp(0.0,1.0)}else{0.0};let q:[f32;3]=std::array::from_fn(|k|p[k]-(a[k]+d[k]*u));(q[0]*q[0]+q[1]*q[1])+q[2]*q[2]};
   let head=std::array::from_fn(|k|h[bone][k]);let tail=std::array::from_fn(|k|t[bone][k]);let limit=len2.sqrt()*0.5;let mut neighbors=Vec::new();
   if separation>1.0{for other in 0..b{if other==bone{continue;}let a=std::array::from_fn(|k|h[other][k]);let d:[f32;3]=std::array::from_fn(|k|t[other][k]-h[other][k]);let l=(d[0]*d[0]+d[1]*d[1])+d[2]*d[2];if l.sqrt()<limit && dist(tail,a,d,l).sqrt()<limit{neighbors.push((a,d,l));}}}
   for (i,point) in p.iter().enumerate(){if labels[i]!=bone as i32{continue;}let p=[point[0],point[1],point[2]];let threshold=(separation*separation)*dist(p,head,d,len2);mask_row[i]=(!neighbors.iter().any(|&(a,d,l)|dist(p,a,d,l)<threshold)) as u8;}continue;
  }
  if kind==4 && len2.sqrt()>=1e-9 {
   let length=len2.sqrt();let axis=d.map(|x|x/length);let ref_axis=if axis[2].abs()<0.9{[0.0,0.0,1.0]}else{[1.0,0.0,0.0]};
   let cross=|a:[f32;3],b:[f32;3]|[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];let dot=|a:[f32;3],b:[f32;3]|(a[0]*b[0]+a[1]*b[1])+a[2]*b[2];
   let first=cross(axis,ref_axis);let norm=dot(first,first).sqrt().max(1e-12);let first=first.map(|x|x/norm);let second=cross(axis,first);
   let mut bins=[[radius_mid[bone];12];8];let mut samples=Vec::new();let mut count=0;
   for (i,point) in p.iter().enumerate(){let q:[f32;3]=std::array::from_fn(|k|point[k]-h[bone][k]);let u=dot(d,q)/len2;let radial=std::array::from_fn(|k|point[k]-(h[bone][k]+d[k]*u));let radius=dot(radial,radial).sqrt();let mut angle=dot(second,radial).atan2(dot(first,radial));if angle<0.0{angle+=std::f32::consts::TAU;}
    let along=((u*8.0) as i64).clamp(0,7) as usize;let around=((angle/std::f32::consts::TAU*12.0) as i64).clamp(0,11) as usize;samples.push((u,radius,along,around));
    if labels[i]==bone as i32 && u>=0.0 && u<=1.0{count+=1;bins[along][around]=bins[along][around].max(radius);}
   }
   if count>=8{let threshold=radius_mid[bone]+1e-9;
    for row in &mut bins{let mut filled:Vec<_>=row.iter().copied().filter(|&x|x>threshold).collect();if !filled.is_empty(){filled.sort_by(f32::total_cmp);let median=filled[filled.len()/2];for x in row{if *x<=threshold{*x=median;}}}}
    for (i,(u,radius,along,around)) in samples.into_iter().enumerate(){mask_row[i]=(u>=0.0 && u<=1.0 && radius<=cell_size*0.5+bins[along][around]) as u8;}continue;
   }
  }
  if kind==2 {for (i,&label) in labels.iter().enumerate(){mask_row[i]=(label==bone as i32) as u8;}continue;}
  if kind==15 || kind==16 {
   let center=centers.as_ref().map(|v|v[bone]).unwrap_or_else(||std::array::from_fn(|k|if kind==15{h[bone][k]}else{t[bone][k]}));
   if sphere_radii[bone]<=0.0 {
    let base=base_radii.as_ref().map(|v|v[bone]).unwrap_or(0.0);let mut scale=1.0f32;
    for _ in 0..6 {let mut count=0;
     for (i,point) in p.iter().enumerate(){let radius=base.max(scale*point_radii.as_ref().map(|v|v[i]).unwrap_or(cell_size.max(1e-9)*0.87));let q:[f32;3]=std::array::from_fn(|k|point[k]-center[k]);let dist=(q[0]*q[0]+q[1]*q[1])+q[2]*q[2];let hit=dist<=radius*radius;mask_row[i]=hit as u8;count+=hit as usize;}
     if count>=2{break;}scale*=1.6;
    }continue;
   }
   let r2=sphere_radii[bone]*sphere_radii[bone];let mut best=f32::INFINITY;let mut nearest=0;let mut count=0;
   for (i,point) in p.iter().enumerate(){let q:[f32;3]=std::array::from_fn(|k|point[k]-center[k]);let dist=(q[0]*q[0]+q[1]*q[1])+q[2]*q[2];let hit=dist<=r2;mask_row[i]=hit as u8;count+=hit as usize;if dist<best{best=dist;nearest=i;}}
   if count==0 && !p.is_empty(){mask_row[nearest]=1;}continue;
  }
  if kind==3 || kind==5 {
   let ids:Vec<_>=labels.iter().enumerate().filter_map(|(i,&label)|(label==bone as i32).then_some(i)).collect();
   if ids.len()>=8 {
    let mut mean=[0.0f64;3];for &i in &ids{for k in 0..3{mean[k]+=p[i][k] as f64;}}for x in &mut mean{*x/=ids.len() as f64;}
    let mut matrix=[[0.0f64;3];3];for &i in &ids{let q:[f64;3]=std::array::from_fn(|k|p[i][k] as f64-mean[k]);for a in 0..3{for b in 0..3{matrix[a][b]+=q[a]*q[b];}}}
    for row in &mut matrix{for x in row{*x/=(ids.len() as f64-1.0).max(1.0);}}
    let mut axes=[[1.0f64,0.0,0.0],[0.0,1.0,0.0],[0.0,0.0,1.0]];
    for _ in 0..50 {
     let mut pair=(0,1);for (a,b) in [(0,2),(1,2)]{if matrix[a][b].abs()>matrix[pair.0][pair.1].abs(){pair=(a,b);}}
     let (a,b)=pair;if matrix[a][b].abs()<1e-14{break;}
     let angle=(matrix[a][b]+matrix[a][b]).atan2(matrix[b][b]-matrix[a][a])*0.5;let (s,c)=angle.sin_cos();
     for k in 0..3{let x=matrix[k][a];let y=matrix[k][b];matrix[k][a]=c*x-s*y;matrix[k][b]=s*x+c*y;}
     for k in 0..3{let x=matrix[a][k];let y=matrix[b][k];matrix[a][k]=c*x-s*y;matrix[b][k]=s*x+c*y;}
     for k in 0..3{let x=axes[k][a];let y=axes[k][b];axes[k][a]=c*x-s*y;axes[k][b]=s*x+c*y;}
    }
    let eigen:[f64;3]=std::array::from_fn(|k|matrix[k][k].max(1e-9));
    let distance=|i:usize,k:usize|{let q:[f64;3]=std::array::from_fn(|j|p[i][j] as f64-mean[j]);let d=(q[0]*axes[0][k]+q[1]*axes[1][k])+q[2]*axes[2][k];d*d/eigen[k]};
    let rank=(ids.len() as f64-1.0)*0.95;let low=rank as usize;let high=(low+1).min(ids.len()-1);let fraction=rank-low as f64;
    let mut threshold=0.0f64;for k in 0..3{let mut scores:Vec<_>=ids.iter().map(|&i|distance(i,k)).collect();scores.sort_by(f64::total_cmp);threshold+=(1.0-fraction)*scores[low]+fraction*scores[high];}threshold=threshold.max(1.0);
    let padding=if kind==3{-1.0}else{axial_padding};
    for i in 0..p.len(){let score=(distance(i,0)+distance(i,1))+distance(i,2);let q:[f32;3]=std::array::from_fn(|k|p[i][k]-h[bone][k]);let u=((d[0]*q[0]+d[1]*q[1])+d[2]*q[2])/len2;
     mask_row[i]=(score<=threshold && (!(len2>1e-12 && padding>=0.0) || (u>=-padding && u<=padding+1.0))) as u8;
    }continue;
   }
  }
  // Unlike 0x657a4, these modes leave a zero-length bone's row unchanged.
  if len2<1e-12{continue;}
  if kind==14 && !(len2.sqrt()<body_scale*0.055) {
   let cap=(radius_mid[bone]/len2.sqrt()).min(0.4);
   for (i,point) in p.iter().enumerate(){let q:[f32;3]=std::array::from_fn(|k|point[k]-h[bone][k]);let u=((d[0]*q[0]+d[1]*q[1])+d[2]*q[2])/len2;let delta:[f32;3]=std::array::from_fn(|k|point[k]-(h[bone][k]+d[k]*u));let dist=(delta[0]*delta[0]+delta[1]*delta[1])+delta[2]*delta[2];mask_row[i]=(u>=cap && u<=1.0-cap && dist<=radius_mid[bone]*radius_mid[bone]) as u8;}
   continue;
  }
  if kind==6 || kind==7 || kind==11 || kind==14 {
   let base=cell_size.max(1e-9)*0.87f32;
   let scale=if reference_length>1e-9{(len2.sqrt()/reference_length).max(1.0)}else{1.0};
   let mut radius=if kind!=7{base}else{(base*scale).min(radius_mid[bone].max(base))};
   let mut accepted=false;let mut growth=1.0f32;
   for _ in 0..6 {let mut count=0;
    for (i,point) in p.iter().enumerate(){let q:[f32;3]=std::array::from_fn(|k|point[k]-h[bone][k]);let u=((d[0]*q[0]+d[1]*q[1])+d[2]*q[2])/len2;
     let delta:[f32;3]=std::array::from_fn(|k|point[k]-(h[bone][k]+d[k]*u));let dist=(delta[0]*delta[0]+delta[1]*delta[1])+delta[2]*delta[2];let effective=if kind==11{growth*point_radii.as_ref().map(|v|v[i]).unwrap_or(base)}else{radius};let hit=u>=0.0 && u<=1.0 && dist<=effective*effective;mask_row[i]=hit as u8;count+=hit as usize;
    }
    if count>1{accepted=true;break;}radius*=1.6;growth*=1.6;
   }
   if accepted{continue;}
  }
  for (i,point) in p.iter().enumerate(){let q:[f32;3]=std::array::from_fn(|k|point[k]-h[bone][k]);let mut u=((d[0]*q[0]+d[1]*q[1])+d[2]*q[2])/len2;
   let radius;
   if kind==13{u=u.clamp(0.0,1.0);radius=radius_mid[bone];}
   else if u<0.0 || u>1.0 {
    if kind==12 && u>1.0 {u=1.0;radius=radius_head[bone].max(radius_tail[bone]).max(radius_mid[bone]);}else{continue;}
   }else if kind==1{radius=radius_mid[bone];}
   else{let rh=if kind==8{0.0}else{radius_head[bone]};let rt=if kind==9{0.0}else{radius_tail[bone]};let (start,change,v)=if u>0.5{(radius_mid[bone],rt-radius_mid[bone],u-0.5)}else{(rh,radius_mid[bone]-rh,u)};radius=start+change*(v+v);}
   let delta:[f32;3]=std::array::from_fn(|k|point[k]-(h[bone][k]+d[k]*u));let distance=(delta[0]*delta[0]+delta[1]*delta[1])+delta[2]*delta[2];mask_row[i]=(distance<=radius*radius) as u8;
  }
 }
 };
 if end-begin>=4 && p.len()>=256 {output.par_iter_mut().enumerate().for_each(run);}
 else {output.iter_mut().enumerate().for_each(run);}
 output
 });Ok(output)
}}
#[pymethods]
impl _PreparedSeedMasks {
 #[new]
 #[pyo3(signature=(points,heads,tails,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers,cell_size,reference_length,oriented,base_radii,point_radii,axial_padding,body_scale,separation,custom_shapes))]
 fn new(py:Python<'_>,points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,radius_head:Vec<f32>,radius_tail:Vec<f32>,radius_mid:Vec<f32>,kinds:Vec<u8>,labels:Vec<i32>,sphere_radii:Vec<f32>,centers:Option<Vec<[f32;3]>>,cell_size:f32,reference_length:f32,oriented:Option<Vec<[f32;13]>>,base_radii:Option<Vec<f32>>,point_radii:Option<Vec<f32>>,axial_padding:f32,body_scale:f32,separation:f32,custom_shapes:Option<Vec<Bound<'_,pyo3::types::PyDict>>>)->PyResult<Self>{prepare_masks(py,points,heads,tails,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers,cell_size,reference_length,oriented,base_radii,point_radii,axial_padding,body_scale,separation,custom_shapes,None)}
 fn block<'py>(&self,py:Python<'py>,begin:usize,end:usize)->PyResult<Bound<'py,numpy::PyArray2<u8>>>{
 let rows=self.compute(py,begin,end,true)?;
 // The rows already own complete masks; copy whole slices instead of pushing
 // every byte through a flattened iterator and growing a second Vec.
 let mut flat=Vec::with_capacity((end-begin)*self.p.len());for row in rows{flat.extend_from_slice(&row);}
 let array=ndarray::Array2::from_shape_vec((end-begin,self.p.len()),flat).map_err(|e|PyValueError::new_err(e.to_string()))?;
 Ok(numpy::PyArray2::from_owned_array(py,array))
 }
}

#[pyfunction]
#[pyo3(signature=(points,heads,tails,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers,cell_size,reference_length,oriented,base_radii,point_radii,axial_padding,body_scale,separation,custom_shapes,begin,end))]
pub fn constrained_seed_mask_block<'py>(py:Python<'py>,points:PyReadonlyArray2<'_,f32>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,radius_head:Vec<f32>,radius_tail:Vec<f32>,radius_mid:Vec<f32>,kinds:Vec<u8>,labels:Vec<i32>,sphere_radii:Vec<f32>,centers:Option<Vec<[f32;3]>>,cell_size:f32,reference_length:f32,oriented:Option<Vec<[f32;13]>>,base_radii:Option<Vec<f32>>,point_radii:Option<Vec<f32>>,axial_padding:f32,body_scale:f32,separation:f32,custom_shapes:Option<Vec<Bound<'_,pyo3::types::PyDict>>>,begin:usize,end:usize)->PyResult<Bound<'py,numpy::PyArray2<u8>>>{
 let width=points.as_array().nrows();let height=end.saturating_sub(begin);
 let rows=constrained_masks_owned(py,points,heads,tails,radius_head,radius_tail,radius_mid,kinds,labels,sphere_radii,centers,cell_size,reference_length,oriented,base_radii,point_radii,axial_padding,body_scale,separation,custom_shapes,Some((begin,end)))?;
 let mut flat=Vec::with_capacity(height*width);for row in rows{flat.extend_from_slice(&row);}
 let array=ndarray::Array2::from_shape_vec((height,width),flat).map_err(|e|PyValueError::new_err(e.to_string()))?;
 Ok(numpy::PyArray2::from_owned_array(py,array))
}


/// Regular mask-to-field stage observed in 0x97f6c..0x98048 and before
/// 0x167f28. Caller supplies already filtered masks and native radius priorities.
/// Custom-profile overrides, fades and skeleton remapping are NOT included.
#[pyfunction]
pub fn regular_seed_field(masks:PyReadonlyArray2<'_,u8>,priorities:Vec<f32>)->PyResult<(Vec<u8>,Vec<u32>,Vec<f32>)>{
 let m=masks.as_array();if m.nrows()!=priorities.len() || m.iter().any(|&x|x>1) || priorities.iter().any(|x|!x.is_finite()) || m.nrows()>u32::MAX as usize{return Err(PyValueError::new_err("invalid regular seed field inputs"));}
 let mut fixed=vec![0;m.ncols()];let mut selected=vec![u32::MAX;m.ncols()];let mut best=vec![f32::INFINITY;m.ncols()];
 for i in 0..m.nrows(){for j in 0..m.ncols(){if m[[i,j]]!=0{fixed[j]=1;if priorities[i]<best[j]{best[j]=priorities[i];selected[j]=i as u32;}}}}
 Ok((fixed,selected,vec![1.0;m.ncols()]))
}
