//! Combined public finger dispatch. Input snapshots precede detector evaluation.
use pyo3::prelude::*;
use numpy::{PyArray2,PyReadonlyArray1,PyArrayMethods,PyUntypedArrayMethods};
#[pyfunction]
#[pyo3(signature=(names,heads,tails,parent_idx,cone_mask,deform=None))]
pub fn detect_fingers(py:Python<'_>,names:Vec<String>,heads:Bound<'_,PyArray2<f32>>,tails:Bound<'_,PyArray2<f32>>,parent_idx:PyReadonlyArray1<'_,i64>,cone_mask:PyReadonlyArray1<'_,bool>,deform:Option<PyReadonlyArray1<'_,bool>>)->PyResult<Py<PyAny>> {
 let xyz=|a:&numpy::PyReadonlyArray2<'_,f32>|->PyResult<Vec<[f32;3]>>{
  if a.shape()[0]>0 && a.shape()[1]<3{return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
  let x=crate::array_input::two(a);Ok((0..x.nrows()).map(|i|[x[[i,0]],x[[i,1]],x[[i,2]]]).collect())
 };
 let h=xyz(&heads.readonly())?;let t=xyz(&tails.readonly())?;
 let p=crate::array_input::owned_one(&parent_idx).to_vec();
 let bits=|x:&PyReadonlyArray1<'_,bool>|(0..x.len()).map(|i|unsafe{x.data().cast::<u8>().offset(i as isize*x.strides()[0]).read()&1!=0}).collect::<Vec<_>>();
 let m=bits(&cone_mask);let d=deform.map(|x|bits(&x));
 let n=names.iter().map(|n|n.split_once(':').map_or(n.as_str(),|(_,r)|r).trim().to_lowercase()).collect::<Vec<_>>();
 py.import("beyond_skinning.finger_geometry")?.getattr("_public_combined_fingers")?.call1((n,h,t,p,m,d)).map(Bound::unbind)
}
