//! Skeleton selection recovered from the public deform_subset implementation.
use numpy::{PyArray1,PyReadonlyArray1,PyArrayMethods,PyUntypedArrayMethods};
use pyo3::{exceptions::PyValueError,prelude::*};
use std::collections::HashSet;
#[pyfunction]
#[pyo3(signature=(parent_idx,use_deform,lengths,names,keep=None))]
pub fn deform_subset<'py>(py:Python<'py>,parent_idx:PyReadonlyArray1<'py,i64>,use_deform:PyReadonlyArray1<'py,bool>,lengths:PyReadonlyArray1<'py,f32>,names:Vec<String>,keep:Option<Vec<String>>)->PyResult<(Bound<'py,PyArray1<i64>>,Bound<'py,PyArray1<i32>>)> {
 let parents=crate::array_input::one(&parent_idx);let lengths=crate::array_input::one(&lengths);let n=parents.len();
 // NumPy accepts noncanonical Boolean storage. Read raw bytes, never create
 // invalid Rust bool references; preserve the original exact-one/low-bit rules.
 let deform:Vec<u8>=(0..use_deform.len()).map(|i|unsafe{
  use_deform.data().cast::<u8>().offset(i as isize*use_deform.strides()[0]).read()
 }).collect();
 if deform.len()!=n || lengths.len()!=n || names.len()!=n{return Err(PyValueError::new_err("parent_idx, use_deform, lengths and names must share length"));}
 let keep=keep.map(|v|v.into_iter().collect::<HashSet<_>>());
 let selected:Vec<_>=(0..n).map(|i|keep.as_ref().map_or(deform[i],|k|u8::from(deform[i]==1&&k.contains(&names[i])))).collect();
 let maximum=(0..n).filter(|&i|selected[i]==1).fold(0.0f64,|m,i|if m<(lengths[i] as f64){lengths[i] as f64}else{m});
 let selected:Vec<_>=(0..n).map(|i|selected[i]&1==1&&maximum*0.0001<(lengths[i] as f64)).collect();
 let indices:Vec<i64>=(0..n).filter(|&i|selected[i]).map(|i|i as i64).collect();let mut remap=vec![-1i32;n];
 for (j,&i) in indices.iter().enumerate(){remap[i as usize]=j as i32;}
 let subparents:Vec<i32>=indices.iter().map(|&i|{let mut p=parents[i as usize];for _ in 0..n{if p<0 || p as usize>=n{return -1;}if selected[p as usize]{return remap[p as usize];}p=parents[p as usize];}if p>=0&&(p as usize)<n&&selected[p as usize]{remap[p as usize]}else{-1}}).collect();
 Ok((PyArray1::from_vec(py,indices),PyArray1::from_vec(py,subparents)))
}

/// Core-chain double-cone eligibility: volume/aspect/direction gates intersect
/// the ascending main chain. Constants are the original default tuning values.
#[pyfunction]
pub fn core_chain_mask<'py>(py:Python<'py>,heads:numpy::PyReadonlyArray2<'py,f32>,tails:numpy::PyReadonlyArray2<'py,f32>,parent_idx:PyReadonlyArray1<'py,i64>,r_mid_all:PyReadonlyArray1<'py,f32>,char_size:f64)->PyResult<Bound<'py,PyArray1<bool>>>{
 let h=crate::array_input::two(&heads);let t=crate::array_input::two(&tails);let p=crate::array_input::one(&parent_idx);let r=crate::array_input::one(&r_mid_all);let n=h.nrows();
 // The original copies xyz from every input row, then traverses heads.len()
 // bones. Extra columns/rows are accepted. Preserve its failure order safely.
 if (h.nrows()>0&&h.ncols()<3)||(t.nrows()>0&&t.ncols()<3){return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
 if n==0{return Ok(PyArray1::from_vec(py,Vec::new()));}
 let bounds=|len:usize,index:usize|pyo3::panic::PanicException::new_err(format!("index out of bounds: the len is {len} but the index is {index}"));
 for len in [t.nrows(),p.len(),r.len()]{if len<n{return Err(bounds(len,len));}}
 if let Some(&index)=p.iter().take(n).find(|&&x|x>=n as i64){return Err(bounds(n,index as usize));}
 let mut lower=[f32::INFINITY;3];let mut upper=[f32::NEG_INFINITY;3];
 for v in h.rows().into_iter().chain(t.rows()){for a in 0..3{lower[a]=lower[a].min(v[a]);upper[a]=upper[a].max(v[a]);}}
 let ext:[f32;3]=std::array::from_fn(|a|upper[a]-lower[a]);
 let size=if !(char_size>0.0){ext.into_iter().fold(f32::NEG_INFINITY,f32::max) as f64}else{char_size};
 let min_volume=size*(size*(size*0.000289));
 let max_radius=(0.15*((ext[0]*ext[0]+ext[1]*ext[1]+ext[2]*ext[2]).sqrt() as f64)) as f32;
 let roots:Vec<usize>=(0..n).filter(|&i|p[i]<0).collect();
 let direction=if let Some(&i)=roots.first(){let d:[f64;3]=std::array::from_fn(|a|(t[[i,a]]-h[[i,a]]) as f64);let len=(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]).sqrt();if !(len>1e-9){[0.0,0.0,1.0]}else{d.map(|x|x/len)}}else{[0.0,0.0,1.0]};
 let mut lens=Vec::with_capacity(n);let mut eligible=vec![false;n];let mut children=vec![Vec::new();n];
 for i in 0..n{
  let d:[f32;3]=std::array::from_fn(|a|t[[i,a]]-h[[i,a]]);let len=(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]).sqrt();lens.push(len);
  let volume=(len*(r[i]*r[i]*std::f32::consts::PI)) as f64;
  let alignment=direction[0]*(d[0]/len) as f64+direction[1]*(d[1]/len) as f64+direction[2]*(d[2]/len) as f64;
  // Native rejects ordered failures; unordered radius/volume/alignment tests pass.
  eligible[i]=len>1e-6&&r[i]>1e-6&&!(r[i]>max_radius)&&!(volume<min_volume)&&!(alignment<0.05)&&len<r[i]*2.0;
  if p[i]>=0{children[p[i] as usize].push(i);}
 }
 let project=|i:usize|direction[0]*t[[i,0]] as f64+direction[1]*t[[i,1]] as f64+direction[2]*t[[i,2]] as f64;
 let mut chain=roots.clone();
 if let Some(&root)=roots.first(){let mut i=root;let mut height=project(i);let mut seen=vec![false;n];seen[i]=true;
  while !children[i].is_empty(){let mut candidate=children[i][0];let mut next=project(candidate);for &j in &children[i][1..]{let x=project(j);if x>next{candidate=j;next=x;}}
   if next<height+(lens[candidate] as f64)*(-0.5){break;}
   if children[candidate].is_empty()&&children[i].iter().any(|&j|j!=candidate&&children[j].is_empty()){break;}
   if seen[candidate]{break;}seen[candidate]=true;chain.push(candidate);height=next;i=candidate;
  }
 }
 let mut out=vec![false;n];for i in chain{out[i]=eligible[i];}Ok(PyArray1::from_vec(py,out))
}
