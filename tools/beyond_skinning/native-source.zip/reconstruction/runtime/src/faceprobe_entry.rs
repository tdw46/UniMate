//! Public detector entry and owned diagnostic-array transport.
use pyo3::{prelude::*,types::{PyDict,PyList}};
use numpy::{PyReadonlyArray2,PyReadonlyArrayDyn,IntoPyArray,PyUntypedArrayMethods};
use crate::bvh::MeshBvh;
fn owned(py:Python<'_>,value:&Bound<'_,PyAny>)->PyResult<Py<PyAny>>{
 macro_rules! arr {($t:ty)=>{if let Ok(a)=value.extract::<PyReadonlyArrayDyn<'_,$t>>(){return Ok(ndarray::ArrayD::from_shape_vec(a.shape().to_vec(),a.as_array().iter().copied().collect()).unwrap().into_pyarray(py).into_any().unbind());}}}
 arr!(f32);arr!(i32);arr!(u32);arr!(u8);
 if let Ok(d)=value.downcast::<PyDict>(){let out=PyDict::new(py);for(k,v)in d.iter(){out.set_item(k,owned(py,&v)?)?;}return Ok(out.into_any().unbind());}
 if let Ok(d)=value.downcast::<PyList>(){let out=PyList::empty(py);for v in d.iter(){out.append(owned(py,&v)?)?;}return Ok(out.into_any().unbind());}
 Ok(value.clone().unbind())
}
#[pyfunction]
#[pyo3(signature=(vertices,faces,bbox_min,bbox_max,resolution=128,refine_multiplier=2,max_depth=4,probe_l4_multiplier=16,fill_interior=false,winding_threshold=0.5,ghost_cull=false,mesh_bvh=None),text_signature="(vertices, faces, bbox_min, bbox_max, resolution=128, refine_multiplier=2, max_depth=4, probe_l4_multiplier=16, fill_interior=False, winding_threshold=..., ghost_cull=False, mesh_bvh=None)")]
pub fn detect_refine_faceprobe(py:Python<'_>,vertices:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,bbox_min:[f32;3],bbox_max:[f32;3],resolution:u32,refine_multiplier:u32,max_depth:u32,probe_l4_multiplier:u32,fill_interior:bool,winding_threshold:f32,ghost_cull:bool,mesh_bvh:Option<PyRef<'_,MeshBvh>>)->PyResult<Py<PyAny>>{
 crate::bind_session::validate_cloud_geometry(vertices.clone(),faces.clone(),bbox_min,bbox_max,resolution,refine_multiplier,probe_l4_multiplier)?;
 crate::cancel::check();
 let v=crate::array_input::owned_two(&vertices).into_pyarray(py);let f=crate::array_input::owned_two(&faces).into_pyarray(py);
 let mesh=mesh_bvh.map(|b|{let(v,f)=b.owned_geometry();let v=ndarray::Array2::from_shape_vec((v.len(),3),v.into_iter().flatten().collect()).unwrap().into_pyarray(py);let f=ndarray::Array2::from_shape_vec((f.len(),3),f.into_iter().flatten().collect()).unwrap().into_pyarray(py);(v,f)});
 let result=py.import("beyond_skinning.faceprobe_public")?.getattr("detect")?.call1((v,f,bbox_min,bbox_max,resolution,refine_multiplier,max_depth,probe_l4_multiplier,fill_interior,winding_threshold,ghost_cull,mesh))?;
 owned(py,&result)
}
