//! Shared cancellation flag. Native checks occur at solver iteration boundaries.
use std::sync::atomic::{AtomicBool, Ordering};
use pyo3::prelude::*;
static REQUESTED: AtomicBool = AtomicBool::new(false);
const MESSAGE: &str = "Auto Skinning was cancelled.";
#[pyfunction]
pub fn request_cancel() { REQUESTED.store(true, Ordering::Relaxed); }
#[pyfunction]
pub fn clear_cancel() { REQUESTED.store(false, Ordering::Relaxed); }
#[pyfunction]
pub fn cancel_message() -> &'static str { MESSAGE }
pub fn check() { if REQUESTED.load(Ordering::Relaxed) { panic!("{MESSAGE}"); } }

/// Explicit orchestration boundary; keep the same sticky flag and panic contract.
#[pyfunction]
pub fn check_cancel() { check(); }

pub(crate) fn requested()->bool { REQUESTED.load(Ordering::Relaxed) }
