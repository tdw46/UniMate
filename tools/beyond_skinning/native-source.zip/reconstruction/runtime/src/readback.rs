//! Native bind readback Result semantics; winding retains transport errors.
use std::sync::mpsc;

pub fn complete(rx:mpsc::Receiver<Result<(),wgpu::BufferAsyncError>>,strict:bool)->Result<(),String>{
    if strict {
        // Recovered final-field and automatic-convergence readbacks unwrap
        // both the channel receive and buffer-map Result, in that order.
        rx.recv().unwrap().unwrap();
        Ok(())
    } else {
        rx.recv().map_err(|e|e.to_string())?.map_err(|e|e.to_string())
    }
}
pub fn read(d:&wgpu::Device,readback:&wgpu::Buffer,strict:bool)->Result<Vec<u8>,String>{
    let (tx,rx)=mpsc::sync_channel(1);
    readback.slice(..).map_async(wgpu::MapMode::Read,move |r|{let _=tx.send(r);});
    d.poll(wgpu::Maintain::Wait);
    complete(rx,strict)?;
    let out=readback.slice(..).get_mapped_range().to_vec();
    readback.unmap();
    Ok(out)
}
