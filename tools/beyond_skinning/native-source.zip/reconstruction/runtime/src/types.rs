//! Typed boundaries reconstructed from captured buffers and native call sites.
//! Raw layouts are observations of the pinned ARM64 binary, NOT Rust Vec ABI.
use bytemuck::{Pod, Zeroable};
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct DenseParams {
    pub bones: u32,
    pub points: u32,
    pub grid_x: u32,
    pub pad0: u32,
    pub omega: f32,
    pub seed_words: u32,
    pub pad2: u32,
    pub pad3: u32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct SparseParams {
    pub points: u32,
    pub slots: u32,
    pub grid_x: u32,
    pub mask_words: u32,
    pub omega: f32,
    pub seed_words: u32,
    pub pad2: u32,
    pub pad3: u32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct DeltaParams {
    pub words: u32,
    pub grid_x: u32,
    pub tolerance: f32,
    pub pad: u32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct WindingNode {
    pub center: [f32; 3],
    pub radius: f32,
    pub area_vector: [f32; 3],
    pub left: i32,
    pub right: i32,
    pub start: u32,
    pub end: u32,
    pub pad: u32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct WindingTriangle {
    pub a: [f32; 3],
    pub b: [f32; 3],
    pub c: [f32; 3],
    pub pad: [f32; 3],
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedVec {
    pub capacity: u64,
    pub pointer: u64,
    pub length: u64,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedCsr {
    pub rows: CapturedVec,
    pub columns: CapturedVec,
    pub weights: CapturedVec,
    pub diagonal_inverse: CapturedVec,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedSparseRows {
    pub groups: CapturedVec,
    pub weights: CapturedVec,
    pub slots: u64,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedSolveResult {
    pub values: CapturedVec,
    pub iterations: u32,
    pub opaque_padding: u32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedStopPolicy {
    pub interval: u32,
    pub tolerance: f32,
    pub moving_fraction: f32,
    pub opaque_12: [u8; 4],
    pub flags: u8,
    pub padding: [u8; 3],
}
impl CapturedStopPolicy {
    pub fn finished(&self, maximum: f32, moving: u32, scalar_count: u64) -> bool {
        maximum <= self.tolerance
            || f64::from(moving) <= f64::from(self.moving_fraction) * (scalar_count as f64)
    }
}
const _: () = {
    assert!(std::mem::size_of::<DenseParams>() == 32);
    assert!(std::mem::size_of::<SparseParams>() == 32);
    assert!(std::mem::size_of::<DeltaParams>() == 16);
    assert!(std::mem::size_of::<WindingNode>() == 48);
    assert!(std::mem::size_of::<WindingTriangle>() == 48);
    assert!(std::mem::offset_of!(WindingNode, left) == 28);
    assert!(std::mem::offset_of!(WindingNode, start) == 36);
    assert!(std::mem::size_of::<CapturedCsr>() == 96);
    assert!(std::mem::size_of::<CapturedSparseRows>() == 56);
    assert!(std::mem::size_of::<CapturedSolveResult>() == 32);
    assert!(std::mem::size_of::<CapturedStopPolicy>() == 20);
};
/// Owned implementation structures use stable public types, never foreign pointers.
pub struct CsrGraph {
    pub rows: Vec<u32>,
    pub columns: Vec<u32>,
    pub weights: Vec<f32>,
    pub diagonal_inverse: Vec<f32>,
}
impl CsrGraph {
    pub fn validate(&self) -> Result<usize, &'static str> {
        let n = self.diagonal_inverse.len();
        if self.rows.len() != n + 1 || self.rows[0] != 0 {
            return Err("invalid CSR row boundaries");
        }
        if self.columns.len() != self.weights.len() || self.rows[n] as usize != self.columns.len() {
            return Err("CSR edge lengths differ");
        }
        if self.rows.windows(2).any(|w| w[0] > w[1])
            || self.columns.iter().any(|&j| j as usize >= n)
        {
            return Err("CSR index outside graph");
        }
        Ok(n)
    }
}
pub struct SparseRows {
    pub groups: Vec<u16>,
    pub weights: Vec<f32>,
    pub slots: usize,
}
impl SparseRows {
    pub fn validate(&self, points: usize) -> Result<(), &'static str> {
        if self.slots == 0
            || points.checked_mul(self.slots) != Some(self.groups.len())
            || self.weights.len() != self.groups.len()
        {
            return Err("sparse row dimensions differ");
        }
        if self
            .groups
            .chunks_exact(self.slots)
            .any(|row| row.windows(2).any(|w| w[0] > w[1]))
        {
            return Err("sparse slots must be sorted");
        }
        Ok(())
    }
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct KdNode {
    pub point: [f32; 3],
    pub original_index: i32,
    pub axis: u32,
    pub left: i32,
    pub right: i32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedKdTree {
    pub nodes: CapturedVec,
    pub root: i32,
    pub opaque_padding: u32,
}
const _: () = {
    assert!(std::mem::size_of::<KdNode>() == 28);
    assert!(std::mem::offset_of!(KdNode, original_index) == 12);
    assert!(std::mem::offset_of!(KdNode, axis) == 16);
    assert!(std::mem::offset_of!(KdNode, left) == 20);
    assert!(std::mem::offset_of!(KdNode, right) == 24);
    assert!(std::mem::size_of::<CapturedKdTree>() == 32);
};
/// Arc counts are snapshots only. Never alter or own foreign reference counts.
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedArcHeader {
    pub strong: u64,
    pub weak: u64,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedCloudArc {
    pub refs: CapturedArcHeader,
    pub positions: CapturedVec,
    pub levels: CapturedVec,
    pub radii: CapturedVec,
    // Verified in sub_146f4: bitwise parameter-key comparison and CSR Arc.
    pub graph_mutex_pointer: u64,
    pub graph_poison: u8,
    pub graph_alignment: [u8; 7],
    pub graph_parameters: [f32; 3],
    pub graph_padding_116: [u8; 4],
    pub graph_arc: u64,
    // OnceLock<(Arc<SpatialHash>, f32)>; storage is not the portable owner.
    pub sample_grid_arc: u64,
    pub sample_grid_cell: f32,
    pub sample_grid_padding: [u8; 4],
    pub sample_grid_once_state: u64,
    // OnceLock<Arc<Vec<OccupancyLevel>>> uses a different field order.
    pub occupancy_once_state: u64,
    pub occupancy_arc: u64,
    pub alternate_grid_mutex_pointer: u64,
    pub alternate_grid_poison: u8,
    pub alternate_grid_padding: [u8; 7],
    pub unresolved_alternate_grid_key: [[u8; 8]; 2],
    pub alternate_grid_option: u8,
    pub alternate_grid_option_padding: [u8; 7],
    pub alternate_grid_arc: u64,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct BvhNode {
    pub minimum: [f32; 3],
    pub maximum: [f32; 3],
    pub left: u32,
    pub right: u32,
    pub first: u32,
    pub count: u32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedMeshBvhArc {
    pub refs: CapturedArcHeader,
    pub vertices: CapturedVec,
    pub triangles: CapturedVec,
    pub permutation: CapturedVec,
    pub centroids: CapturedVec,
    pub nodes: CapturedVec,
}
/// Captured cage storage; numeric arrays are copied into independent owned types.
#[repr(C)]
pub struct CapturedCageBinding {
    pub rest: CapturedVec,
    pub row_offsets: CapturedVec,
    pub compact_bone_indices: CapturedVec,
    pub weights_f64: CapturedVec,
    pub row_sums_f64: CapturedVec,
    pub pose_indices: CapturedVec,
    pub rest_bone_indices: CapturedVec,
    pub edges_python_object: u64,
}
const _: () = {
    assert!(std::mem::size_of::<CapturedCloudArc>() == 216);
    assert!(std::mem::offset_of!(CapturedCloudArc, radii) == 64);
    assert!(std::mem::offset_of!(CapturedCloudArc, graph_mutex_pointer) == 88);
    assert!(std::mem::offset_of!(CapturedCloudArc, graph_poison) == 96);
    assert!(std::mem::offset_of!(CapturedCloudArc, graph_parameters) == 104);
    assert!(std::mem::offset_of!(CapturedCloudArc, graph_arc) == 120);
    assert!(std::mem::size_of::<BvhNode>() == 40);
    assert!(std::mem::offset_of!(BvhNode, left) == 24);
    assert!(std::mem::offset_of!(BvhNode, first) == 32);
    assert!(std::mem::size_of::<CapturedMeshBvhArc>() == 136);
    assert!(std::mem::offset_of!(CapturedMeshBvhArc, triangles) == 40);
    assert!(std::mem::size_of::<CapturedCageBinding>() == 176);
    assert!(std::mem::offset_of!(CapturedCageBinding, edges_python_object) == 168);
};

/// Captured dense/single-bone seed representation (0x167f28 CPU inputs).
/// dense.capacity == u64::MAX denotes None, not a dereferenceable vector.
#[repr(C)]
pub struct CapturedSeedFields {
    pub fixed: CapturedVec,
    pub indices: CapturedVec,
    pub values: CapturedVec,
    pub dense: CapturedVec,
    pub points: u64,
    pub bones: u64,
}
/// Session cache key and owned values verified by native state-transition probes.
/// The optional box record and level-summary element types remain unresolved.
#[repr(C)]
pub struct CapturedCloudCache {
    pub void_boxes: CapturedVec,
    pub refine_boxes: CapturedVec,
    pub vertex_count: u64,
    pub face_count: u64,
    pub winding_threshold_quantized: i64,
    pub coarse_resolution: u32,
    pub maximum_depth: u32,
    pub refinement_multiplier: u32,
    pub probe_multiplier: u32,
    pub fill_interior: u8,
    pub ghost_cull: u8,
    pub padding_90: [u8; 6],
    pub vertices: CapturedVec,
    pub faces: CapturedVec,
    pub level_summaries: CapturedVec,
    pub mesh_bvh_arc: u64,
    pub cloud_arc: u64,
    pub ghost_culled_count: u64,
    pub generation: u64,
    pub voxel_size: f32,
    pub padding_204: [u8; 4],
}
#[repr(C)]
pub struct CapturedBoneCache {
    pub heads: CapturedVec,
    pub tails: CapturedVec,
    pub parents: CapturedVec,
    pub shape_config_utf8: CapturedVec,
    pub preparation_arc: u64,
    pub cloud_generation: u64,
}
#[repr(C)]
pub struct CapturedBonePreparationArc {
    pub refs: CapturedArcHeader,
    pub heads: CapturedVec,
    pub tails: CapturedVec,
    pub radii: CapturedVec,
    pub middle_radii: CapturedVec,
    pub cone_mask: CapturedVec,
    pub bucket_option_tag: u8,
    pub unresolved_bucket_payload: [u8; 5],
    pub padding_142: [u8; 2],
}
/// Pinned session payload excludes the PyObject header. Algorithms remain open.
#[repr(C)]
pub struct CapturedBindSession {
    pub mutex_pointer: u64,
    pub poison: u8,
    pub alignment: [u8; 7],
    pub cloud_cache: CapturedCloudCache,
    pub bone_cache: CapturedBoneCache,
    pub generation: u64,
    pub borrow_flag: u64,
}
const _: () = {
    assert!(std::mem::size_of::<CapturedSeedFields>() == 112);
    assert!(std::mem::offset_of!(CapturedSeedFields, dense) == 72);
    assert!(std::mem::size_of::<CapturedCloudCache>() == 208);
    assert!(std::mem::offset_of!(CapturedCloudCache, vertices) == 96);
    assert!(std::mem::offset_of!(CapturedCloudCache, cloud_arc) == 176);
    assert!(std::mem::offset_of!(CapturedCloudCache, voxel_size) == 200);
    assert!(std::mem::size_of::<CapturedBoneCache>() == 112);
    assert!(std::mem::offset_of!(CapturedBoneCache, preparation_arc) == 96);
    assert!(std::mem::size_of::<CapturedBonePreparationArc>() == 144);
    assert!(std::mem::offset_of!(CapturedBonePreparationArc, bucket_option_tag) == 136);
    assert!(std::mem::size_of::<CapturedBindSession>() == 352);
    assert!(std::mem::offset_of!(CapturedBindSession, cloud_cache) == 16);
    assert!(std::mem::offset_of!(CapturedBindSession, bone_cache) == 224);
    assert!(std::mem::offset_of!(CapturedBindSession, borrow_flag) == 344);
};

#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedGraphArc {
    pub refs: CapturedArcHeader,
    pub graph: CapturedCsr,
}
const _: () = {
    assert!(std::mem::size_of::<CapturedGraphArc>() == 112);
    assert!(std::mem::offset_of!(CapturedGraphArc, graph) == 16);
};

/// Counting-sort sampling grid: sub_d8cc4 and Arc allocation in sub_77c5c.
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedSpatialHash {
    pub rows: CapturedVec,
    pub indices: CapturedVec,
    pub cell: f32,
    pub origin: [f32; 3],
    pub dimensions: [u32; 3],
    pub alignment: [u8; 4],
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedSpatialHashArc {
    pub refs: CapturedArcHeader,
    pub grid: CapturedSpatialHash,
}
const _: () = {
    assert!(std::mem::size_of::<CapturedSpatialHash>() == 80);
    assert!(std::mem::size_of::<CapturedSpatialHashArc>() == 96);
    assert!(std::mem::offset_of!(CapturedSpatialHash, cell) == 48);
    assert!(std::mem::offset_of!(CapturedSpatialHash, dimensions) == 64);
    assert!(std::mem::offset_of!(CapturedCloudArc, sample_grid_arc) == 128);
    assert!(std::mem::offset_of!(CapturedCloudArc, sample_grid_cell) == 136);
    assert!(std::mem::offset_of!(CapturedCloudArc, sample_grid_once_state) == 144);
    assert!(std::mem::offset_of!(CapturedCloudArc, occupancy_once_state) == 152);
    assert!(std::mem::offset_of!(CapturedCloudArc, occupancy_arc) == 160);
    assert!(std::mem::offset_of!(CapturedCloudArc, alternate_grid_mutex_pointer) == 168);
    assert!(std::mem::offset_of!(CapturedCloudArc, alternate_grid_option) == 200);
    assert!(std::mem::offset_of!(CapturedCloudArc, alternate_grid_arc) == 208);
};

/// Dense arm of native occupancy storage. capacity == u64::MAX selects a
/// sparse hash-table payload; u64::MAX-1 means absent. Those variants must not
/// be dereferenced as a dense Vec or interpreted using these dimension fields.
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedDenseOccupancy {
    pub bits: CapturedVec,
    pub dimensions: [i64;3],
    pub minimum: [i32;3],
    pub alignment: [u8;4],
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedOccupancyLevel {
    pub solid: CapturedDenseOccupancy,
    pub dilated: CapturedDenseOccupancy,
    pub origin: [f32;3],
    pub inverse: f32,
    pub cell: f32,
    pub alignment: [u8;4],
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedOccupancyArc {
    pub refs: CapturedArcHeader,
    pub levels: CapturedVec,
}
const _: () = {
    assert!(std::mem::size_of::<CapturedDenseOccupancy>() == 64);
    assert!(std::mem::size_of::<CapturedOccupancyLevel>() == 152);
    assert!(std::mem::offset_of!(CapturedOccupancyLevel, origin) == 128);
    assert!(std::mem::offset_of!(CapturedOccupancyLevel, inverse) == 140);
    assert!(std::mem::size_of::<CapturedOccupancyArc>() == 40);
};

/// Original ARM64 winding preprocessing storage. GPU packing uses the distinct
/// 48-byte WindingNode/WindingTriangle structures above.
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedWindingTriangle {
    pub points: [[f32;3];3], pub center:[f32;3], pub area:[f32;3], pub radius:f32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedWindingNode {
    pub start:u64, pub end:u64, pub center:[f32;3], pub area:[f32;3],
    pub radius:f32, pub left:i32, pub right:i32,
    // Native allocation leaves this alignment padding uninitialized. Never
    // compare it or use it as serialized state.
    pub padding:[u8;4],
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedWindingTree {pub triangles:CapturedVec,pub nodes:CapturedVec}
#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
pub struct CapturedSurfaceVoxelGrid {
    pub control_pointer:u64,pub bucket_mask:u64,pub growth_left:u64,pub length:u64,
    pub dimensions:[u32;3],pub cell:f32,pub origin:[f32;3],pub padding:[u8;4],
}
const _:()={
 assert!(std::mem::size_of::<CapturedWindingTriangle>()==64);
 assert!(std::mem::size_of::<CapturedWindingNode>()==56);
 assert!(std::mem::offset_of!(CapturedWindingNode,left)==44);
 assert!(std::mem::size_of::<CapturedWindingTree>()==48);
 assert!(std::mem::size_of::<CapturedSurfaceVoxelGrid>()==64);
 assert!(std::mem::offset_of!(CapturedSurfaceVoxelGrid,cell)==44);
};
