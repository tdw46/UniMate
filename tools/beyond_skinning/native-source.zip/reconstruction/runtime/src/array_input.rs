//! Borrow aligned NumPy inputs; copy only when ndarray cannot safely view them.
use ndarray::{Array1, Array2, CowArray, Ix1, Ix2};
use numpy::{Element, PyArrayMethods, PyReadonlyArray1, PyReadonlyArray2, PyUntypedArrayMethods};
fn aligned<T>(data: *const T, strides: &[isize]) -> bool {
    let n=std::mem::align_of::<T>();
    (data as usize)%n==0 && strides.iter().all(|s|s% n as isize==0)
}
// Match numpy 0.23 / ndarray element-stride conversion even for unusual
// byte strides that are not a multiple of item size. Negative axes first shift
// the origin by the original byte stride, then reverse the truncated view.
fn offset(i:usize,n:usize,stride:isize,size:usize)->isize {
    let step=(stride.unsigned_abs()/size*size) as isize;
    if stride>=0 { i as isize*step }
    else { (n-1) as isize*stride+(n-1-i) as isize*step }
}
pub fn one<'a,T:Element+Copy>(a:&'a PyReadonlyArray1<'_,T>)->CowArray<'a,T,Ix1>{
    if aligned(a.data(),a.strides()) { return a.as_array().into(); }
    // Readonly guard retains the allocation; each logical element is read
    // unaligned, without creating an invalid Rust reference to NumPy storage.
    let values=(0..a.len()).map(|i|unsafe{
        a.data().cast::<u8>().offset(offset(i,a.shape()[0],a.strides()[0],std::mem::size_of::<T>())).cast::<T>().read_unaligned()
    }).collect();
    Array1::from_vec(values).into()
}
pub fn two<'a,T:Element+Copy>(a:&'a PyReadonlyArray2<'_,T>)->CowArray<'a,T,Ix2>{
    if aligned(a.data(),a.strides()) { return a.as_array().into(); }
    let shape=a.shape();
    let values=(0..shape[0]).flat_map(|i|(0..shape[1]).map(move|j|(i,j))).map(|(i,j)|unsafe{
        a.data().cast::<u8>().offset(offset(i,a.shape()[0],a.strides()[0],std::mem::size_of::<T>())+offset(j,a.shape()[1],a.strides()[1],std::mem::size_of::<T>())).cast::<T>().read_unaligned()
    }).collect();
    Array2::from_shape_vec((shape[0],shape[1]),values).expect("NumPy logical shape").into()
}

/// Own a standard-layout snapshot, including zero-length/zero-stride arrays.
pub fn owned_two<T:Element+Copy>(a:&PyReadonlyArray2<'_,T>)->Array2<T>{
    let view=two(a);
    Array2::from_shape_fn(view.dim(),|index|view[index])
}

pub fn owned_one<T:Element+Copy>(a:&PyReadonlyArray1<'_,T>)->Array1<T>{
    let view=one(a);
    Array1::from_shape_fn(view.dim(),|index|view[index])
}

pub fn owned_three<T:Element+Copy>(a:&numpy::PyReadonlyArray3<'_,T>)->ndarray::Array3<T>{
    let s=a.shape();
    if aligned(a.data(),a.strides()) {
        let view=a.as_array();
        return ndarray::Array3::from_shape_fn(view.dim(),|index|view[index]);
    }
    ndarray::Array3::from_shape_fn((s[0],s[1],s[2]),|(i,j,k)|unsafe {
        let size=std::mem::size_of::<T>();
        a.data().cast::<u8>().offset(offset(i,s[0],a.strides()[0],size)+offset(j,s[1],a.strides()[1],size)+offset(k,s[2],a.strides()[2],size)).cast::<T>().read_unaligned()
    })
}
