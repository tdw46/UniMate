//! Mesh BVH layout and centroid midpoint split recovered from 0xf6920/0xf5f04.
use crate::types::BvhNode;
use numpy::PyReadonlyArray2;
use pyo3::{exceptions::PyValueError, panic::PanicException, prelude::*, types::PyBytes};
#[pyclass(module = "_bvt_solver")]
pub struct MeshBvh {
    vertices: Vec<[f32; 3]>,
    triangles: Vec<[i32; 3]>,
    permutation: Vec<u32>,
    centroids: Vec<[f32; 3]>,
    nodes: Vec<BvhNode>,
}
impl MeshBvh {
    pub(crate) fn owned_geometry(&self)->(Vec<[f32;3]>,Vec<[i32;3]>){(self.vertices.clone(),self.triangles.clone())}

    fn branch(&mut self, first: usize, end: usize) -> u32 {
        let mut minimum = [f32::INFINITY; 3];
        let mut maximum = [f32::NEG_INFINITY; 3];
        let mut cmin = minimum;
        let mut cmax = maximum;
        for &index in &self.permutation[first..end] {
            for &vertex in &self.triangles[index as usize] {
                let p = self.vertices[vertex as usize];
                for a in 0..3 {
                    // Native ordered comparisons retain the first signed zero and ignore NaNs.
                    if p[a] < minimum[a] { minimum[a] = p[a]; }
                    if p[a] > maximum[a] { maximum[a] = p[a]; }
                }
            }
            let c = self.centroids[index as usize];
            for a in 0..3 {
                if c[a] < cmin[a] { cmin[a] = c[a]; }
                if c[a] > cmax[a] { cmax[a] = c[a]; }
            }
        }
        let root = self.nodes.len() as u32;
        let count = end - first;
        self.nodes.push(BvhNode {
            minimum,
            maximum,
            left: 0,
            right: 0,
            first: first as u32,
            count: count as u32,
        });
        if count <= 4 {
            return root;
        }
        let extent = std::array::from_fn::<_, 3, _>(|a| cmax[a] - cmin[a]);
        // Match the native ordered GE comparisons, including unordered extents.
        // A running maximum is equivalent only for finite numbers.
        let axis = if extent[0] >= extent[1] && extent[0] >= extent[2] {
            0
        } else if extent[1] >= extent[2] {
            1
        } else {
            2
        };
        if extent[axis] <= 0.0 {
            return root;
        }
        let pivot = (cmin[axis] + cmax[axis]) * 0.5;
        let mut lo = first;
        let mut hi = end;
        while lo < hi {
            if self.centroids[self.permutation[lo] as usize][axis] < pivot {
                lo += 1
            } else {
                hi -= 1;
                self.permutation.swap(lo, hi)
            }
        }
        let split = if lo == first || lo == end {
            first + count / 2
        } else {
            lo
        };
        let left = self.branch(first, split);
        let right = self.branch(split, end);
        let node = &mut self.nodes[root as usize];
        node.left = left;
        node.right = right;
        node.count = 0;
        root
    }
}
#[pymethods]
impl MeshBvh {
    #[new]
    pub(crate) fn new(
        py: Python<'_>,
        verts: PyReadonlyArray2<'_, f32>,
        faces: PyReadonlyArray2<'_, i32>,
    ) -> PyResult<Self> {
        let v = crate::array_input::two(&verts);
        let f = crate::array_input::two(&faces);
        if v.ncols() != 3 {
            return Err(PyValueError::new_err(format!(
                "verts must have shape (N, 3), got {:?}",
                v.shape()
            )));
        }
        if f.ncols() != 3 {
            return Err(PyValueError::new_err(format!(
                "faces must have shape (M, 3), got {:?}",
                f.shape()
            )));
        }
        // Original validates triangle-major indices after unsigned 32-bit conversion.
        // Return its public exception safely rather than unwinding from an index operation.
        for row in f.rows() {
            for &i in row {
                let index = i as u32 as usize;
                if index >= v.nrows() {
                    return Err(PanicException::new_err(format!(
                        "index out of bounds: the len is {} but the index is {}", v.nrows(), index
                    )));
                }
            }
        }
        let vertices: Vec<_> = v.rows().into_iter().map(|r| [r[0], r[1], r[2]]).collect();
        let triangles: Vec<_> = f.rows().into_iter().map(|r| [r[0], r[1], r[2]]).collect();
        py.allow_threads(|| {
            let centroids = triangles
                .iter()
                .map(|f| {
                    std::array::from_fn(|a| {
                        ((vertices[f[0] as usize][a] + vertices[f[1] as usize][a])
                            + vertices[f[2] as usize][a])
                            / 3.0
                    })
                })
                .collect();
            let n = triangles.len();
            let mut result = Self {
                vertices,
                triangles,
                permutation: (0..n as u32).collect(),
                centroids,
                nodes: Vec::with_capacity(n * 2),
            };
            if n > 0 {
                result.branch(0, n);
            }
            Ok(result)
        })
    }
    fn _raycast(&self,origin:[f32;3],direction:[f32;3])->Option<(f32,u32)>{self.raycast(origin,direction)}
    #[getter]
    fn n_tris(&self) -> usize {
        self.triangles.len()
    }
    /// Research-only byte comparisons of all owned arrays; no foreign pointer ABI.
    fn _array_bytes<'py>(&self, py: Python<'py>) -> Vec<Bound<'py, PyBytes>> {
        vec![
            PyBytes::new(py, bytemuck::cast_slice(&self.vertices)),
            PyBytes::new(py, bytemuck::cast_slice(&self.triangles)),
            PyBytes::new(py, bytemuck::cast_slice(&self.permutation)),
            PyBytes::new(py, bytemuck::cast_slice(&self.centroids)),
            PyBytes::new(py, bytemuck::cast_slice(&self.nodes)),
        ]
    }
}

impl MeshBvh {
 pub(crate) fn raycast(&self,o:[f32;3],d:[f32;3])->Option<(f32,u32)>{
  if self.nodes.is_empty(){return None;}
  let mut stack=vec![0usize];let mut best=f32::INFINITY;let mut selected=u32::MAX;
  while let Some(i)=stack.pop(){let node=&self.nodes[i];let mut lo=0.0;let mut hi=best;let mut keep=true;
   for k in 0..3{let a=(1.0/d[k])*(node.minimum[k]-o[k]);let b=(1.0/d[k])*(node.maximum[k]-o[k]);let (a,b)=if a<b{(a,b)}else{(b,a)};
    if k==0{lo=if 0.0<a{a}else{0.0};hi=if b<hi{b}else{hi};}else{lo=if a<=lo{lo}else{a};hi=if b<hi{b}else{hi};}
    if !(lo<=hi){keep=false;break;}
   }
   if !keep{continue;}
   if node.count==0{stack.push(node.left as usize);stack.push(node.right as usize);continue;}
   for &ti in &self.permutation[node.first as usize..(node.first+node.count) as usize]{
    let ids=self.triangles[ti as usize];let a=self.vertices[ids[0] as usize];let b=self.vertices[ids[1] as usize];let c=self.vertices[ids[2] as usize];
    let e:[f32;3]=std::array::from_fn(|k|b[k]-a[k]);let f:[f32;3]=std::array::from_fn(|k|c[k]-a[k]);let p=[d[1]*f[2]-d[2]*f[1],d[2]*f[0]-d[0]*f[2],d[0]*f[1]-d[1]*f[0]];
    let determinant=(e[0]*p[0]+e[1]*p[1])+e[2]*p[2];if determinant.abs()<1e-12{continue;}let inv=1.0/determinant;
    // Native fccmp/b.gt rejects ordered out-of-range barycentrics;
    // NaN intermediates from finite overflow continue to the distance test.
    let t:[f32;3]=std::array::from_fn(|k|o[k]-a[k]);let u=inv*((t[0]*p[0]+p[1]*t[1])+p[2]*t[2]);if u< -1e-6 || u>1.000001{continue;}
    let q=[e[2]*t[1]-e[1]*t[2],e[0]*t[2]-t[0]*e[2],t[0]*e[1]-e[0]*t[1]];
    let v=inv*((d[0]*q[0]+d[1]*q[1])+d[2]*q[2]);if v< -1e-6 || u+v>1.000001{continue;}
    let distance=inv*((f[0]*q[0]+f[1]*q[1])+f[2]*q[2]);if distance>=0.0 && distance<best{best=distance;selected=ti;}
   }
  }
  if best.is_finite(){Some((best,selected))}else{None}
 }
}

// Triangle closest point, 0x10f7c4. Preserve the mixed dot ordering in the native code.
pub(crate) fn closest_triangle(p:[f64;3],a:[f64;3],b:[f64;3],c:[f64;3])->[f64;3]{
 let sub=|x:[f64;3],y:[f64;3]|std::array::from_fn::<_,3,_>(|k|x[k]-y[k]);
 let dot=|x:[f64;3],y:[f64;3]|(x[0]*y[0]+x[1]*y[1])+x[2]*y[2];
 let ab=sub(b,a);let ac=sub(c,a);let ap=sub(p,a);let d1=dot(ab,ap);let d2=(ac[1]*ap[1]+ac[0]*ap[0])+ac[2]*ap[2];
 if d1<=0.0 && d2<=0.0{return a;}
 let bp=sub(p,b);let d3=(ab[1]*bp[1]+ab[0]*bp[0])+ab[2]*bp[2];let d4=dot(ac,bp);
 if d3>=0.0 && d4<=d3{return b;}
 let vc=d4*d1-d3*d2;
 if d3<=0.0 && d1>=0.0 && vc<=0.0{let v=d1/(d1-d3);return std::array::from_fn(|k|a[k]+v*ab[k]);}
 let cp=sub(p,c);let d5=dot(ab,cp);let d6=(ac[1]*cp[1]+ac[0]*cp[0])+ac[2]*cp[2];
 if d6>=0.0 && d5<=d6{return c;}
 let vb=d5*d2-d6*d1;
 if d6<=0.0 && d2>=0.0 && vb<=0.0{let w=d2/(d2-d6);return std::array::from_fn(|k|a[k]+w*ac[k]);}
 let va=d6*d3-d5*d4;
 if va<=0.0 && d4-d3>=0.0 && d5-d6>=0.0{let w=(d4-d3)/((d4-d3)+(d5-d6));return std::array::from_fn(|k|b[k]+(c[k]-b[k])*w);}
 let inv=1.0/(vc+(va+vb));let v=vb*inv;let w=vc*inv;
 std::array::from_fn(|k|w*ac[k]+(a[k]+v*ab[k]))
}
impl MeshBvh{
 pub(crate) fn within_mesh(&self,p:[f32;3],radius:f32)->bool{
  if self.nodes.is_empty(){return false;}
  let limit=(radius as f64)*(radius as f64);let mut stack=vec![0usize];
  while let Some(i)=stack.pop(){let node=&self.nodes[i];let d=std::array::from_fn::<_,3,_>(|k|if p[k]<node.minimum[k]{node.minimum[k]-p[k]}else if p[k]>node.maximum[k]{p[k]-node.maximum[k]}else{0.0});
   if ((d[0]*d[0]+d[1]*d[1])+d[2]*d[2]) as f64>limit{continue;}
   if node.count==0{stack.push(node.left as usize);stack.push(node.right as usize);continue;}
   for &i in &self.permutation[node.first as usize..(node.first+node.count)as usize]{let t=self.triangles[i as usize];let q=closest_triangle(p.map(f64::from),self.vertices[t[0]as usize].map(f64::from),self.vertices[t[1]as usize].map(f64::from),self.vertices[t[2]as usize].map(f64::from));let d=std::array::from_fn::<_,3,_>(|k|q[k]-p[k]as f64);if (d[0]*d[0]+d[1]*d[1])+d[2]*d[2]<limit{return true;}}
  }false
 }
}
#[pyfunction]
pub fn triangle_closest_point(p:[f64;3],a:[f64;3],b:[f64;3],c:[f64;3])->PyResult<[f64;3]>{
 if p.iter().chain(&a).chain(&b).chain(&c).any(|x|!x.is_finite()){return Err(PyValueError::new_err("nonfinite triangle query"));}
 Ok(closest_triangle(p,a,b,c))
}
