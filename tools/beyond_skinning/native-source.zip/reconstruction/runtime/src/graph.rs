//! Recovered CSR diagonal inverse (native graph.rs:538-542 / sub_60404).
//! Neighbor construction and edge-culling integration are still separate gates.
use numpy::{PyArray1,PyReadonlyArray1};
use pyo3::{prelude::*,exceptions::PyValueError};
#[pyfunction]
pub fn graph_diagonal<'py>(py:Python<'py>,rows:PyReadonlyArray1<'py,u32>,weights:PyReadonlyArray1<'py,f32>)->PyResult<Bound<'py,PyArray1<f32>>>{
 let rows=rows.as_array();let weights=weights.as_array();
 if rows.is_empty()||rows[0]!=0||rows[rows.len()-1] as usize!=weights.len()||rows.iter().zip(rows.iter().skip(1)).any(|(&a,&b)|a>b){return Err(PyValueError::new_err("Invalid CSR rows/weights"));}
 let mut out=Vec::with_capacity(rows.len()-1);
 for i in 0..rows.len()-1{let mut sum=0.0f32;for j in rows[i] as usize..rows[i+1] as usize{sum+=weights[j];}out.push(if sum>1e-12f32{1.0/sum}else{0.0});}
 Ok(PyArray1::from_vec(py,out))
}

use numpy::PyReadonlyArray2;
use pyo3::types::PyDict;
use std::collections::BTreeMap;

/// Sparse storage of the recovered dense counting-sort hash. Iteration remains
/// z/y/x then source index, including empty cell ranges, without huge empty grids.
struct SpatialHash {
    origin:[f32;3], dims:[i32;3], inverse:f32,
    cells:BTreeMap<(i32,i32,i32),Vec<usize>>, max_radius:f32,
}
impl SpatialHash {
    fn new(points:&[[f32;3]],indices:&[usize],cell:f32,max_radius:f32)->Self {
        let mut lo=[f32::INFINITY;3];let mut hi=[f32::NEG_INFINITY;3];
        for &i in indices {for d in 0..3 {if points[i][d]<lo[d]{lo[d]=points[i][d];}if points[i][d]>hi[d]{hi[d]=points[i][d];}}}
        if indices.is_empty(){lo=[0.;3];hi=[0.;3];}
        let inverse=1.0/cell;
        let dims=std::array::from_fn(|d|((inverse*(hi[d]-lo[d]).max(0.)) as i32).saturating_add(1).max(1));
        let mut out=Self{origin:lo,dims,inverse,cells:BTreeMap::new(),max_radius};
        for &i in indices {let xyz=std::array::from_fn::<_,3,_>(|d|out.coordinate(points[i][d]-lo[d],d));out.cells.entry((xyz[2],xyz[1],xyz[0])).or_default().push(i);}
        out
    }
    fn coordinate(&self,value:f32,d:usize)->i32 {((self.inverse*value) as i32).clamp(0,self.dims[d]-1)}
    fn visit(&self,point:[f32;3],radius:f32,edge_cull:f32,mut visit:impl FnMut(usize)) {
        let sum=radius+self.max_radius;
        let range=if edge_cull<=0. {sum}else{edge_cull*sum};
        let lo=std::array::from_fn::<_,3,_>(|d|self.coordinate((point[d]-self.origin[d])-range,d));
        let hi=std::array::from_fn::<_,3,_>(|d|self.coordinate(range+(point[d]-self.origin[d]),d));
        // Preserve native z/y/x and source-index order. Narrow row ranges
        // avoid scanning every occupied x/y cell in the entire z slab.
        let row_count = (hi[2] as i64 - lo[2] as i64 + 1)
            .saturating_mul(hi[1] as i64 - lo[1] as i64 + 1);
        if row_count <= self.cells.len() as i64 {
            for z in lo[2]..=hi[2] {
                for y in lo[1]..=hi[1] {
                    for (_, ids) in self.cells.range((z,y,lo[0])..=(z,y,hi[0])) {
                        for &id in ids { visit(id); }
                    }
                }
            }
        } else {
            for (&(_,y,x),ids) in self.cells.range((lo[2],i32::MIN,i32::MIN)..=(hi[2],i32::MAX,i32::MAX)) {
                if y>=lo[1] && y<=hi[1] && x>=lo[0] && x<=hi[0] {
                    for &id in ids { visit(id); }
                }
            }
        }
    }
}
// Immutable CSR-like cell storage for graph queries. Hash lookup is used only
// to find a row; traversal remains z/y/x and source index, never hash iteration.
struct GraphHash {
 origin:[f32;3],dims:[i32;3],inverse:f32,max_radius:f32,
 keys:Vec<(i32,i32,i32)>,starts:Vec<usize>,ids:Vec<usize>,
 rows:rustc_hash::FxHashMap<(i32,i32),(usize,usize)>,
}
impl GraphHash {
 fn new(points:&[[f32;3]],mut ids:Vec<usize>,cell:f32,max_radius:f32)->Self {
  let mut lo=[f32::INFINITY;3];let mut hi=[f32::NEG_INFINITY;3];
  for &i in &ids{for d in 0..3{if points[i][d]<lo[d]{lo[d]=points[i][d];}if points[i][d]>hi[d]{hi[d]=points[i][d];}}}
  if ids.is_empty(){lo=[0.;3];hi=[0.;3];}
  let inverse=1.0/cell;
  let dims=std::array::from_fn(|d|((inverse*(hi[d]-lo[d]).max(0.)) as i32).saturating_add(1).max(1));
  let key=|i:usize|{let xyz=std::array::from_fn::<_,3,_>(|d|((inverse*(points[i][d]-lo[d])) as i32).clamp(0,dims[d]-1));(xyz[2],xyz[1],xyz[0])};
  // Consume the existing level index vector in place. Its source-index tie
  // order is explicit, matching BTree cell rows without temporary cell Vecs
  // or another whole index array while freezing the query structure.
  let mut packed=false;
  #[cfg(target_pointer_width="64")]
  {
   // Ordinary grids fit a u32 flat cell address. Sort cell/index pairs in the
   // already-owned usize buffer, then restore source IDs. No key side-array.
   // Wider grids retain full coordinate tuples, never truncating addresses.
   if points.len()<=u32::MAX as usize && dims.iter().try_fold(1u64,|n,&d|n.checked_mul(d as u64)).is_some_and(|n|n<=u32::MAX as u64){
    for id in &mut ids{let (z,y,x)=key(*id);let cell=x as usize+(y as usize+z as usize*dims[1] as usize)*dims[0] as usize;*id=(cell<<32)|*id;}
    ids.sort_unstable();
    for id in &mut ids{*id&=u32::MAX as usize;}
    packed=true;
   }
  }
  if !packed{ids.sort_unstable_by_key(|&i|(key(i),i));}
  let mut out=Self{origin:lo,dims,inverse,max_radius,keys:Vec::new(),starts:Vec::new(),ids,rows:rustc_hash::FxHashMap::default()};
  for (offset,&id) in out.ids.iter().enumerate(){let k=key(id);
   if out.keys.last()!=Some(&k){
    let index=out.keys.len();out.rows.entry((k.0,k.1)).and_modify(|range|range.1=index+1).or_insert((index,index+1));
    out.keys.push(k);out.starts.push(offset);
   }
  }
  out.starts.push(out.ids.len());out
 }
 fn coordinate(&self,value:f32,d:usize)->i32{((self.inverse*value) as i32).clamp(0,self.dims[d]-1)}
 fn visit(&self,point:[f32;3],radius:f32,edge_cull:f32,mut visit:impl FnMut(usize)) {
  let sum=radius+self.max_radius;let range=if edge_cull<=0. {sum}else{edge_cull*sum};
  let lo=std::array::from_fn::<_,3,_>(|d|self.coordinate((point[d]-self.origin[d])-range,d));
  let hi=std::array::from_fn::<_,3,_>(|d|self.coordinate(range+(point[d]-self.origin[d]),d));
  let row_count=(hi[2] as i64-lo[2] as i64+1).saturating_mul(hi[1] as i64-lo[1] as i64+1);
  if row_count<=self.keys.len() as i64 {
   for z in lo[2]..=hi[2]{for y in lo[1]..=hi[1]{
    if let Some(&(begin,end))=self.rows.get(&(z,y)) {
     let keys=&self.keys[begin..end];let first=begin+keys.partition_point(|key|key.2<lo[0]);let last=begin+keys.partition_point(|key|key.2<=hi[0]);
     for &id in &self.ids[self.starts[first]..self.starts[last]]{visit(id);}
    }
   }}
  }else{
   let first=self.keys.partition_point(|key|key.0<lo[2]);let last=self.keys.partition_point(|key|key.0<=hi[2]);
   for i in first..last{let (_,y,x)=self.keys[i];if y>=lo[1] && y<=hi[1] && x>=lo[0] && x<=hi[0]{for &id in &self.ids[self.starts[i]..self.starts[i+1]]{visit(id);}}}
  }
 }
}
fn edge_weight(a:[f32;3],b:[f32;3],ra:f32,rb:f32,level_diff:bool,level_multiplier:f32,power:f32,cull_squared:f32)->Option<f32>{
    let dx=a[0]-b[0];let dy=a[1]-b[1];let dz=a[2]-b[2];
    let d2=(dx*dx+dy*dy)+dz*dz;let sum=rb+ra;let sum2=sum*sum;
    // Ordered greater-than preserves native unordered/NaN fall-through.
    if d2>sum2 || d2>sum2*cull_squared{return None;}
    let ratio=(d2.sqrt()/sum).clamp(0.,1.);
    let mut weight=(ratio * -4.0).exp();
    if level_diff && level_multiplier!=1. {weight*=level_multiplier;}
    if power!=0. {
        let base=(sum*0.5).max(f32::from_bits(0x322bcc77));let exponent=-power;
        let factor=if exponent.fract()==0. && exponent.abs()<=8. {
            let count=exponent as i32;let mut v=1.0f32;
            for _ in 0..count.unsigned_abs(){v=base*v;}
            if count<0{1.0/v}else{v}
        }else{base.powf(exponent)};
        weight*=factor;
    }
    Some(weight)
}

/// Independent graph constructor for validated finite point clouds. Research
/// entry point, not an original public API or a completed binding pipeline.
#[pyfunction]
#[pyo3(signature=(positions,levels,radii,level_multiplier=10.0,power=-3.0,edge_cull=0.85))]
pub fn build_graph<'py>(py:Python<'py>,positions:PyReadonlyArray2<'py,f32>,levels:PyReadonlyArray1<'py,u8>,radii:PyReadonlyArray1<'py,f32>,level_multiplier:f32,power:f32,edge_cull:f32)->PyResult<Bound<'py,PyDict>>{
    let p=positions.as_array();let levels=levels.as_array();let r=radii.as_array();let n=r.len();
    if p.shape()!=[n,3]||levels.len()!=n||p.iter().any(|x|!x.is_finite())||r.iter().any(|x|!x.is_finite()||*x<=0.)||![level_multiplier,power,edge_cull].iter().all(|x|x.is_finite()) {return Err(PyValueError::new_err("Graph requires finite positions, positive radii and matching levels"));}
    let points:Vec<[f32;3]>=p.outer_iter().map(|x|[x[0],x[1],x[2]]).collect();
    let levels=levels.to_vec();let r=r.to_vec();
    let (rows,columns,weights,diagonal)=py.allow_threads(|| -> PyResult<_> {
    let max_radius=r.iter().copied().fold(0.,f32::max);let min_radius=r.iter().copied().fold(f32::INFINITY,f32::min);
    let mut hashes=Vec::new();
    if max_radius>min_radius.max(1e-9)*1.5 {
        let mut by_level:Vec<Vec<usize>>=(0..256).map(|_|Vec::new()).collect();
        for (i,&level) in levels.iter().enumerate(){by_level[level as usize].push(i);}
        for ids in by_level {if ids.is_empty(){continue;}
            let max=ids.iter().map(|&i|r[i]).fold(0.,f32::max);
            hashes.push(GraphHash::new(&points,ids,(max+max).max(1e-6),max));}
    } else {
        let average=(r.iter().map(|&x|x as f64).sum::<f64>()/(n.max(1) as f64)) as f32;
        let cell=(average*4.).max(min_radius+min_radius).min(max_radius+max_radius).max(1e-6);
        hashes.push(GraphHash::new(&points,(0..n).collect::<Vec<_>>(),cell,max_radius));
    }
    let cull_squared=if edge_cull<=0.{f32::INFINITY}else{edge_cull*edge_cull};
    use rayon::prelude::*;
    // Source arrays are copied before releasing Python. Parallel tasks own
    // disjoint consecutive row ranges; row-local evaluation order is unchanged.
    // Bounded waves avoid retaining a second whole graph while concatenating.
    let mut rows=vec![0u32];let mut columns=Vec::new();let mut weights=Vec::new();let mut diagonal=Vec::with_capacity(n);
    let block=8192usize;let wave=block*rayon::current_num_threads().clamp(1,16);
    for begin in (0..n).step_by(wave) {
        let end=begin.saturating_add(wave).min(n);
        let starts:Vec<usize>=(begin..end).step_by(block).collect();
        let parts:Vec<_>=starts.into_par_iter().map(|start|{
            let stop=start.saturating_add(block).min(end);
            let mut lengths=Vec::with_capacity(stop-start);let mut cols=Vec::new();let mut vals=Vec::new();let mut diag=Vec::with_capacity(stop-start);
            for i in start..stop {
                let first=vals.len();
                for hash in &hashes {hash.visit(points[i],r[i],edge_cull,|j|{
                    if i==j{return;}
                    if let Some(w)=edge_weight(points[i],points[j],r[i],r[j],levels[i]!=levels[j],level_multiplier,power,cull_squared){cols.push(j as u32);vals.push(w);}
                });}
                let sum=vals[first..].iter().fold(0.0f32,|a,&b|a+b);
                diag.push(if sum>1e-12{1.0/sum}else{0.});lengths.push(vals.len()-first);
            }
            (lengths,cols,vals,diag)
        }).collect();
        for (lengths,mut cols,mut vals,mut diag) in parts {
            for len in lengths {let next=(rows.last().copied().unwrap() as usize).checked_add(len).and_then(|v|u32::try_from(v).ok()).ok_or_else(||PyValueError::new_err("Graph exceeds u32 CSR capacity"))?;rows.push(next);}
            columns.append(&mut cols);weights.append(&mut vals);diagonal.append(&mut diag);
        }
    }
    Ok((rows,columns,weights,diagonal))
    })?;
    let out=PyDict::new(py);out.set_item("rows",PyArray1::from_vec(py,rows))?;out.set_item("columns",PyArray1::from_vec(py,columns))?;out.set_item("weights",PyArray1::from_vec(py,weights))?;out.set_item("diagonal",PyArray1::from_vec(py,diagonal))?;Ok(out)
}

/// Materialize the recovered counting-sort sampling grid for verification.
/// The production graph uses sparse cells instead of allocating empty buckets.
#[pyfunction]
#[pyo3(signature=(positions,radii,allow_sparse=false))]
pub fn build_sample_grid<'py>(py:Python<'py>,positions:PyReadonlyArray2<'py,f32>,radii:PyReadonlyArray1<'py,f32>,allow_sparse:bool)->PyResult<Bound<'py,PyDict>>{
    let p=positions.as_array();let r=radii.as_array();let n=r.len();
    if n==0||p.shape()!=[n,3]||p.iter().any(|x|!x.is_finite())||r.iter().any(|x|!x.is_finite()||*x<=0.) {return Err(PyValueError::new_err("Sampling grid requires a nonempty finite point cloud with positive radii"));}
    let min=r.iter().copied().fold(f32::INFINITY,f32::min);let max=r.iter().copied().fold(0.,f32::max);
    let avg=(r.iter().map(|&x|x as f64).sum::<f64>()/n as f64) as f32;
    let cell=(avg*4.).max(min+min).min(max+max).max(1e-6);
    let points:Vec<_>=p.outer_iter().map(|x|[x[0],x[1],x[2]]).collect();
    let hash=SpatialHash::new(&points,&(0..n).collect::<Vec<_>>(),cell,max);
    let count=hash.dims.iter().try_fold(1usize,|a,&b|a.checked_mul(b as usize));
    if allow_sparse && count.is_none_or(|n|n>16_000_000) {
        let mut rows=Vec::with_capacity(hash.cells.len()+1);
        let mut columns=Vec::with_capacity(n);
        let mut coordinates=Vec::with_capacity(hash.cells.len()*3);
        rows.push(0u32);
        for (&(z,y,x),ids) in &hash.cells {
            coordinates.extend([z as u32,y as u32,x as u32]);
            for &id in ids {
                columns.push(u32::try_from(id).map_err(|_|PyValueError::new_err("Sampling source exceeds u32 capacity"))?);
            }
            rows.push(u32::try_from(columns.len()).map_err(|_|PyValueError::new_err("Sampling grid exceeds u32 capacity"))?);
        }
        let coordinates=ndarray::Array2::from_shape_vec((hash.cells.len(),3),coordinates).unwrap();
        let out=PyDict::new(py);
        out.set_item("cell_coordinates",numpy::PyArray2::from_owned_array(py,coordinates))?;
        out.set_item("rows",PyArray1::from_vec(py,rows))?;
        out.set_item("columns",PyArray1::from_vec(py,columns))?;
        out.set_item("cell",cell)?;out.set_item("origin",hash.origin)?;out.set_item("dimensions",hash.dims)?;
        return Ok(out);
    }
    let count=count.ok_or_else(||PyValueError::new_err("Sampling grid size overflow"))?;
    if count>16_000_000{return Err(PyValueError::new_err("Research sampling grid exceeds bounded allocation"));}
    let mut counts=vec![0u32;count];let mut columns=Vec::with_capacity(n);
    for (&(z,y,x),ids) in &hash.cells {let flat=(x as usize)+(y as usize+z as usize*hash.dims[1] as usize)*hash.dims[0] as usize;counts[flat]=ids.len() as u32;columns.extend(ids.iter().map(|&i|i as u32));}
    let mut rows=Vec::with_capacity(count+1);rows.push(0u32);for len in counts{rows.push(rows.last().unwrap()+len);}
    let out=PyDict::new(py);out.set_item("rows",PyArray1::from_vec(py,rows))?;out.set_item("columns",PyArray1::from_vec(py,columns))?;out.set_item("cell",cell)?;out.set_item("origin",hash.origin)?;out.set_item("dimensions",hash.dims)?;Ok(out)
}

use pyo3::types::PyList;
/// Recovered dense occupancy tiling. Native sparse-hash fallback is an open
/// gate; reject that route rather than silently substitute different behavior.
#[pyfunction]
pub fn build_occupancy<'py>(py:Python<'py>,positions:PyReadonlyArray2<'py,f32>,levels:PyReadonlyArray1<'py,u8>,radii:PyReadonlyArray1<'py,f32>)->PyResult<Bound<'py,PyList>>{
    let p=positions.as_array();let l=levels.as_array();let r=radii.as_array();let n=r.len();
    if p.shape()!=[n,3]||l.len()!=n||p.iter().any(|x|!x.is_finite())||r.iter().any(|x|!x.is_finite()||*x<=0.){return Err(PyValueError::new_err("Occupancy requires finite matching arrays and positive radii"));}
    let mut order=Vec::new();for &level in l{if !order.contains(&level){order.push(level);}}
    let out=PyList::empty(py);
    for level in order{
        let ids:Vec<_>=(0..n).filter(|&i|l[i]==level).collect();let first=ids[0];
        let cell=(r[first]+r[first])/1.7320508f32;let inverse=1.0/cell;
        let center=[p[[first,0]],p[[first,1]],p[[first,2]]];
        let origin=center.map(|x|x-cell*0.5);
        let coords:Vec<[i32;3]>=ids.iter().map(|&i|std::array::from_fn(|d|((p[[i,d]]-center[d])*inverse).round() as i32)).collect();
        let mut lo=[i32::MAX;3];let mut hi=[i32::MIN;3];for xyz in &coords {for d in 0..3{lo[d]=lo[d].min(xyz[d]);hi[d]=hi[d].max(xyz[d]);}}
        let row=PyDict::new(py);
        for (name,pad) in [("solid",0i64),("dilated",1i64)]{
            let minimum=lo.map(|x|x as i64-pad);let dims=std::array::from_fn::<_,3,_>(|d|hi[d] as i64-lo[d] as i64+1+2*pad);
            let count=dims.iter().try_fold(1usize,|a,&b|a.checked_mul(b as usize)).ok_or_else(||PyValueError::new_err("Occupancy size overflow"))?;
            if count>16_000_000{return Err(PyValueError::new_err("Sparse or oversized occupancy is not reconstructed"));}
            let mut bits=vec![0u64;(count+63)/64];
            for xyz in &coords{for dz in -pad..=pad{for dy in -pad..=pad{for dx in -pad..=pad{
                let x=xyz[0] as i64+dx-minimum[0];let y=xyz[1] as i64+dy-minimum[1];let z=xyz[2] as i64+dz-minimum[2];
                let flat=(x+(y+z*dims[1])*dims[0]) as usize;bits[flat/64]|=1u64<<(flat%64);
            }}}}
            row.set_item(format!("{name}_bits"),PyArray1::from_vec(py,bits))?;row.set_item(format!("{name}_dimensions"),dims)?;row.set_item(format!("{name}_minimum"),minimum)?;
        }
        row.set_item("origin",origin)?;row.set_item("inverse",inverse)?;row.set_item("cell",cell)?;out.append(row)?;
    }
    Ok(out)
}
