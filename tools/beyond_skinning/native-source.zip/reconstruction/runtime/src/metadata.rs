//! Compatibility metadata from the frozen research target, not a product release ID.
use pyo3::prelude::*;
use pyo3::types::PyDict;
#[pyfunction]
pub fn version()->&'static str { "0.10.110" }
#[pyfunction]
pub fn tuning_values(py:Python<'_>)->Bound<'_,PyDict> { PyDict::new(py) }
