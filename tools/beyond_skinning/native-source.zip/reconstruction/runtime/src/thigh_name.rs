//! Recovered 0xc0344: lowercase string, then the original whole-string regex.
use pyo3::prelude::*;
use std::sync::OnceLock;
#[pyfunction]
pub fn is_thigh_name(name:&str)->bool {
 static PATTERN:OnceLock<regex::Regex>=OnceLock::new();
 PATTERN.get_or_init(||regex::Regex::new(r"\A.*(thigh|upleg|upper[._ -]?leg|up[._ -]?leg|femur).*\z").unwrap()).is_match(&name.to_lowercase())
}
