//! Internal row ownership transfer, no Python list/scalar staging.
use pyo3::prelude::*;
pub fn owned_rows<'py>(py:Python<'py>,rows:Vec<Vec<f32>>,width:usize)->PyResult<Bound<'py,numpy::PyArray2<f32>>>{
 let height=rows.len();
 let flat:Vec<f32>=rows.into_iter().flatten().collect();
 let array=ndarray::Array2::from_shape_vec((height,width),flat).map_err(|e|pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
 Ok(numpy::PyArray2::from_owned_array(py,array))
}
