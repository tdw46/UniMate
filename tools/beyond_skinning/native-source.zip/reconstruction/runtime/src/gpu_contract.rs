//! Public device diagnostics and allocation admission; no solver allocation.
use pyo3::prelude::*;
const REFUSAL:&str="Auto Skinning stopped before it started: at this voxel resolution the solve needs more GPU memory than your card can hand out in one block.\n\nYou almost certainly do not need it this high. The defaults cover nearly every model. A finer voxel grid only helps when weights bleed across a small gap in the mesh, between the thighs for instance.\n\nLower Base Resolution or Depth and run again. Nothing has been changed on your mesh or your rig.";
#[pyfunction]
pub fn gpu_limits(py:Python<'_>)->Option<(String,String,u64,u32)>{
 #[cfg(feature="gpu")]
 {py.allow_threads(crate::gpu::limits)}
 #[cfg(not(feature="gpu"))]
 {let _=py;None}
}
fn refused(points:usize,bones:usize,buffer:u64,storage:u32)->bool{
 // The original release path uses wrapping machine-width field arithmetic.
 let padded=bones.wrapping_add(3)&!3;
 let bytes=points.wrapping_mul(padded).wrapping_mul(2);
 let allowed=(buffer.min(storage as u64) as f64*0.75) as u64;
 bytes as u64>allowed
}
#[pyfunction]
pub fn gpu_budget_check(py:Python<'_>,n_pts:usize,n_bones:usize)->Option<String>{
 if n_pts==0 || n_bones==0{return None;}
 let (_,_,buffer,storage)=gpu_limits(py)?;
 if refused(n_pts,n_bones,buffer,storage){
  let (_,base,depth,_)=crate::bind_env::bind_env_snapshot();
  let defaults=if base!=0 && depth!=0{format!("The defaults (Base Resolution {base}, Depth {depth})")}else{"The defaults".to_owned()};
  Some(REFUSAL.replace("The defaults",&defaults))
 }else{None}
}
#[cfg(test)]
mod tests{
 use super::*;
 #[test] fn admission_boundaries(){
  for (buffer,storage) in [(0,0),(1,1),(8,8),(100,100),(u64::MAX,u32::MAX),(1024,u32::MAX),(u64::MAX,1024)]{
   let cap=(buffer.min(storage as u64) as f64*0.75) as u64;
   for bones in [1usize,2,3,4,5,192,usize::MAX-3,usize::MAX-2,usize::MAX-1,usize::MAX]{
    let stride=bones.wrapping_add(3)&!3;
    for points in [0usize,1,cap as usize/8,cap as usize/8+1,usize::MAX]{
     assert_eq!(refused(points,bones,buffer,storage),(points as u128*stride as u128).wrapping_mul(2) as u64>cap);
    }
   }
  }
 }
}
