//! Recovered integer-key hash from the same REA boundary as weight_hash_order.py.
//! Internal acceleration only: no RNG, allocation, table or public bind policy.
use pyo3::prelude::*;
#[pyfunction]
pub fn weight_hash_u32(b:u32,k0:u64,k1:u64)->u64 {
 let b=b as u64;
 let mut a=k1^0x646f72616e646f6d;let mut c=k1^0x7065646279746573^b;
 let mut d=a.wrapping_add(k0^0x736f6d6570736575);let mut e=d^a.rotate_left(13);
 a=c.wrapping_add(k0^0x6c7967656e657261);let mut f=e.wrapping_add(a);
 a^=c.rotate_left(16);e=f^e.rotate_left(17);d=a.wrapping_add(d.rotate_left(32));c=d^a.rotate_left(21);
 d=(d^(b|(4<<56))).wrapping_add(e);e=d^e.rotate_left(13);
 a=(f.rotate_left(32)^255).wrapping_add(c);f=e.wrapping_add(a);a^=c.rotate_left(16);e=f^e.rotate_left(17);
 d=a.wrapping_add(d.rotate_left(32));c=e.wrapping_add(d);d^=a.rotate_left(21);e=c^e.rotate_left(13);
 a=d.wrapping_add(f.rotate_left(32));f=e.wrapping_add(a);a^=d.rotate_left(16);e=f^e.rotate_left(17);
 d=a.wrapping_add(c.rotate_left(32));c=d^a.rotate_left(21);e=e.wrapping_add(d)^e.rotate_left(13);
 d=c.wrapping_add(f.rotate_left(32));a=e.wrapping_add(d);d^=c.rotate_left(16);
 e.rotate_left(17)^d.rotate_left(21)^a.rotate_left(32)^a
}
