//! Mesh-derived mid-segment profiles, 0xc76c0 / 0x593e8 / 0xf6434.
//! The full name/rig-driven custom-shape builder remains unrecovered.
use pyo3::{prelude::*,exceptions::PyValueError};
use numpy::{PyReadonlyArray2,PyUntypedArrayMethods,PyArray2,PyArrayMethods,IntoPyArray};
#[pyfunction]
#[pyo3(signature=(heads,tails,verts,faces,voxel_size,min_radius_voxels=0.75,n_dirs=16,hit_floor_world=1e-4))]
pub fn auto_bone_mid_profile<'py>(py:Python<'py>,heads:PyReadonlyArray2<'py,f32>,tails:PyReadonlyArray2<'py,f32>,verts:PyReadonlyArray2<'py,f32>,faces:PyReadonlyArray2<'py,i32>,voxel_size:f64,min_radius_voxels:f64,n_dirs:usize,hit_floor_world:f64)->PyResult<(Bound<'py,PyArray2<f32>>,Bound<'py,PyArray2<f32>>,Bound<'py,PyArray2<f32>>)>{
 crate::cancel::check();
 // Original copies xyz in argument order, accepting unused extra columns and
 // empty arrays; short nonempty rows fail before mesh construction.
 for shape in [heads.shape(),tails.shape(),verts.shape(),faces.shape()] {
  if shape[0]>0 && shape[1]<3{return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
 }
 let h=crate::array_input::owned_two(&heads);let t=crate::array_input::owned_two(&tails);
 let v=crate::array_input::two(&verts);let f=crate::array_input::two(&faces);
 let vv=ndarray::Array2::from_shape_fn((v.nrows(),3),|(i,j)|v[[i,j]]).into_pyarray(py);
 let ff=ndarray::Array2::from_shape_fn((f.nrows(),3),|(i,j)|f[[i,j]]).into_pyarray(py);
 let bvh=crate::bvh::MeshBvh::new(py,vv.readonly(),ff.readonly())?;let n=h.nrows().min(t.nrows());
 let trig:Vec<_>=(0..n_dirs).map(|j|((2.0*std::f64::consts::PI/n_dirs as f64)*j as f64).sin_cos()).collect();
 let floor=(voxel_size*min_radius_voxels) as f32;let mut profiles=Vec::new();let mut us=Vec::new();let mut vs=Vec::new();
 for i in 0..n{let head=std::array::from_fn::<_,3,_>(|k|h[[i,k]] as f64);let delta=std::array::from_fn::<_,3,_>(|k|t[[i,k]] as f64-head[k]);let length=((delta[0]*delta[0]+delta[1]*delta[1])+delta[2]*delta[2]).sqrt();let mut profile=vec![floor;n_dirs];
  if length<1e-8{profiles.push(profile);us.push([0.0;3]);vs.push([0.0;3]);continue;}
  let d=delta.map(|v|v/length);let helper=if d[0].abs()<0.9{[1.0,0.0]}else{[0.0,1.0]};
  let mut u=[d[1]*0.0-d[2]*helper[1],helper[0]*d[2]-d[0]*0.0,d[0]*helper[1]-d[1]*helper[0]];let length=(u[2]*u[2]+(u[0]*u[0]+u[1]*u[1])).sqrt();u=u.map(|x|x/length);
  let v=[d[1]*u[2]-d[2]*u[1],d[2]*u[0]-d[0]*u[2],u[1]*d[0]-d[1]*u[0]];
  let origin=std::array::from_fn(|k|(head[k]+delta[k]*0.5) as f32);
  for (j,&(s,c)) in trig.iter().enumerate(){let direction=std::array::from_fn(|k|(u[k]*c+v[k]*s) as f32);if let Some((distance,_))=bvh.raycast(origin,direction){if (distance as f64)>=hit_floor_world{profile[j]=distance.max(floor);}}}
  profiles.push(profile);us.push(u.map(|x|x as f32));vs.push(v.map(|x|x as f32));
 }
 if h.nrows()!=n{return Err(pyo3::exceptions::PyRuntimeError::new_err("ShapeError/OutOfBounds: out of bounds indexing"));}
 let profiles=ndarray::Array2::from_shape_vec((n,n_dirs),profiles.into_iter().flatten().collect()).expect("profile shape");
 let us=ndarray::Array2::from_shape_vec((n,3),us.into_iter().flatten().collect()).expect("basis shape");
 let vs=ndarray::Array2::from_shape_vec((n,3),vs.into_iter().flatten().collect()).expect("basis shape");
 Ok((profiles.into_pyarray(py),us.into_pyarray(py),vs.into_pyarray(py)))
}

// The native macOS build calls the paired libSystem routine, whose last-bit
// results differ from independent sinf/cosf calls on this platform.
#[cfg(target_os="macos")]
pub(crate) fn profile_sin_cos(x:f32)->(f32,f32){
 #[repr(C)] struct Pair{sin:f32,cos:f32}
 unsafe extern "C"{fn __sincosf_stret(x:f32)->Pair;}
 let p=unsafe{__sincosf_stret(x)};(p.sin,p.cos)
}
#[cfg(not(target_os="macos"))]
pub(crate) fn profile_sin_cos(x:f32)->(f32,f32){x.sin_cos()}

// Eyelid ring geometry from the automatic builder 0x132b84. Semantic group
// membership is explicit until the full rig-family classifier is recovered.
#[pyfunction]
#[pyo3(signature=(heads,tails,samples=100,sigma=2.0,axis_hint=None))]
pub fn eyelid_ring_profile<'py>(py:Python<'py>,heads:Vec<[f32;3]>,tails:Vec<[f32;3]>,samples:usize,sigma:f64,axis_hint:Option<[f32;3]>)->PyResult<Bound<'py,pyo3::types::PyDict>>{
 use pyo3::types::PyDict;
 let n=tails.len();if n<4 || n>1000 || heads.len()!=n || !(8..=4096).contains(&samples) || !sigma.is_finite() || !(0.0..=100.0).contains(&sigma) || heads.iter().chain(&tails).flatten().any(|x|!x.is_finite()){return Err(PyValueError::new_err("unsupported eyelid profile inputs"));}
 let dot=|a:[f32;3],b:[f32;3]|(a[0]*b[0]+a[1]*b[1])+a[2]*b[2];let sub=|a:[f32;3],b:[f32;3]|std::array::from_fn::<_,3,_>(|k|a[k]-b[k]);
 let norm=|a:[f32;3]|dot(a,a).sqrt();let mut center=[0.0f32;3];for p in &tails{for k in 0..3{center[k]+=p[k]/n as f32;}}
 let mut a=[1.0,0.0,0.0];let mut far=0.0f32;
 for p in &tails{for q in &tails{let d=sub(*p,*q);let len=norm(d);if len>far{far=len;let d=sub(*q,*p);let len=norm(d);a=if len<=1e-12{[1.0,0.0,0.0]}else{d.map(|x|x/len)};}}}
 if let Some(hint)=axis_hint { a=hint; }
 let proj=(a[0]*0.0+a[1])+a[2]*0.0;let zero=proj*0.0;a=[a[0]-zero,a[1]-proj,a[2]-zero];let len=(a[2]*a[2]+(a[0]*a[0]+a[1]*a[1])).sqrt();a=if len<=1e-12{[1.0,0.0,0.0]}else{a.map(|x|x/len)};
 let mut b=[a[2]-a[1]*0.0,a[0]*0.0-a[2]*0.0,a[1]*0.0-a[0]];let len=(b[2]*b[2]+(b[0]*b[0]+b[1]*b[1])).sqrt();b=if len<=1e-12{[1.0,0.0,0.0]}else{b.map(|x|x/len)};
 let mut hc=[0.0;3];for p in &heads{for k in 0..3{hc[k]+=p[k]/n as f32;}}
 let maximum=heads.iter().map(|p|norm(sub(*p,hc))).fold(0.0f32,f32::max);let mut radius=-0.0f32;for p in &tails{radius+=norm(sub(*p,hc));}radius/=n as f32;
 let sphere=radius>0.0 && maximum<=radius*0.05;let sort_center=center;if sphere{center=hc;}
 let mut ordered:Vec<_>=tails.iter().map(|&p|{let d=sub(p,sort_center);(dot(b,d).atan2(dot(a,d)),p)}).collect();ordered.sort_by(|x,y|x.0.partial_cmp(&y.0).unwrap());
 let mut lengths=vec![0.0f32;n+1];for i in 0..n{lengths[i+1]=lengths[i]+norm(sub(ordered[i].1,ordered[(i+1)%n].1));}
 let total=lengths[n];if total<=1e-9{return Err(PyValueError::new_err("degenerate eyelid ring"));}
 let mut points=Vec::with_capacity(samples);let mut edge=0;
 for i in 0..samples{let t=(total*i as f32)/samples as f32;while lengths[edge+1]<t{edge+=1;}let u=((t-lengths[edge])/(lengths[edge+1]-lengths[edge]).max(1e-9)).clamp(0.0,1.0);let p=ordered[edge].1;let q=ordered[(edge+1)%n].1;points.push(std::array::from_fn::<_,3,_>(|k|p[k]+(q[k]-p[k])*u));}
 if sigma>7.006492321624085e-46{let sigma=sigma as f32;let range=(sigma*3.0)as i32;let weights:Vec<f32>=(-range..=range).map(|i|{let x=i as f32/sigma;(x*x*-0.5).exp()}).collect();let sum=weights.iter().fold(0.0,|s,x|s+x);let original=points.clone();for i in 0..samples{let mut p=[0.0;3];for (j,&w) in weights.iter().enumerate(){let index=(i as i32+j as i32-range).rem_euclid(samples as i32)as usize;for k in 0..3{p[k]+=original[index][k]*w;}}points[i]=p.map(|x|x/sum);}}
 let mut polar=Vec::new();for p in &points{let d=sub(*p,center);let mut x=(a[1]*d[1]+a[0]*d[0])+a[2]*d[2];let mut y=dot(b,d);let mut z=(d[0]*0.0+d[1])+d[2]*0.0;
  if sphere{let radial=x.hypot(y);let (xx,yy)=if radial<=1e-9{(if z<=0.0{0.0}else{radius*std::f32::consts::PI},0.0)}else{let arc=radius*radial.atan2(-z);((x/radial)*arc,(y/radial)*arc)};z=(z*z+(x*x+y*y)).sqrt()-radius;x=xx;y=yy;}
  polar.push((y.atan2(x),x.hypot(y),z));
 }
 polar.sort_by(|x,y|x.0.partial_cmp(&y.0).unwrap());let mut ls=Vec::new();let mut circumference=0.0f32;
 for i in 0..samples{ls.push(circumference);let (angle,r,_)=polar[i];let (next,rn,_)=polar[(i+1)%samples];let (s,c)=profile_sin_cos(angle);let (sn,cn)=profile_sin_cos(next);circumference+=(rn*cn-r*c).hypot(rn*sn-r*s);}
 let out=PyDict::new(py);out.set_item("center",center)?;out.set_item("axis",a)?;out.set_item("lateral",b)?;out.set_item("sphere",if sphere{Some(radius)}else{None})?;out.set_item("angles",polar.iter().map(|p|p.0).collect::<Vec<_>>())?;out.set_item("radii",polar.iter().map(|p|p.1).collect::<Vec<_>>())?;out.set_item("heights",polar.iter().map(|p|p.2).collect::<Vec<_>>())?;out.set_item("lengths",ls)?;out.set_item("circumference",circumference)?;Ok(out)
}

/// No-corner eyelid groups. Role membership and eye-head caps are supplied,
/// rather than guessed from bone names. Includes circular minimum-width redistribution.
#[pyfunction]
#[pyo3(signature=(heads,tails,upper,eye_heads=Vec::new(),samples=100,sigma=2.0,opposite_tails=None,axis_hint=None))]
pub fn eyelid_group_shapes<'py>(py:Python<'py>,heads:Vec<[f32;3]>,tails:Vec<[f32;3]>,upper:Vec<bool>,eye_heads:Vec<[f32;3]>,samples:usize,sigma:f64,opposite_tails:Option<Vec<[f32;3]>>,axis_hint:Option<[f32;3]>)->PyResult<Vec<Bound<'py,pyo3::types::PyDict>>>{
 use pyo3::types::PyDict;
 let n=tails.len();if upper.len()!=n || eye_heads.iter().flatten().any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid eyelid roles"));}
 let ring=eyelid_ring_profile(py,heads,tails.clone(),samples,sigma,axis_hint)?;
 let center:[f32;3]=ring.get_item("center")?.unwrap().extract()?;let a:[f32;3]=ring.get_item("axis")?.unwrap().extract()?;let b:[f32;3]=ring.get_item("lateral")?.unwrap().extract()?;
 let angles:Vec<f32>=ring.get_item("angles")?.unwrap().extract()?;let radii:Vec<f32>=ring.get_item("radii")?.unwrap().extract()?;let lengths:Vec<f32>=ring.get_item("lengths")?.unwrap().extract()?;let total:f32=ring.get_item("circumference")?.unwrap().extract()?;let sphere:Option<f32>=ring.get_item("sphere")?.unwrap().extract()?;
 let dot=|a:[f32;3],b:[f32;3]|(a[0]*b[0]+a[1]*b[1])+a[2]*b[2];
 let mut mean=[0.0f32;3];for p in &tails{for k in 0..3{mean[k]+=p[k]/n as f32;}}
 let plane=if let Some(other)=opposite_tails{if other.is_empty() || other.iter().flatten().any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid opposite eyelid group"));}let mut other_mean=[0.0f32;3];for p in &other{for k in 0..3{other_mean[k]+=p[k]/other.len() as f32;}}let d=std::array::from_fn::<_,3,_>(|k|mean[k]-other_mean[k]);let len=dot(d,d).sqrt();let direction=if len<=1e-12{[1.0,0.0,0.0]}else{d.map(|x|x/len)};Some([(mean[0]+other_mean[0])*0.5,(mean[1]+other_mean[1])*0.5,(mean[2]+other_mean[2])*0.5,direction[0],direction[1],direction[2]])}else{None};
 let mut min=f32::MAX;let mut max=-f32::MAX;let mut arcs=Vec::new();let mut ys=Vec::new();
 for (i,p) in tails.iter().enumerate(){let d=std::array::from_fn::<_,3,_>(|k|p[k]-center[k]);let mut x=dot(a,d);let mut y=dot(b,d);let width_x=dot(a,std::array::from_fn(|k|p[k]-mean[k]));min=min.min(width_x);max=max.max(width_x);
  if let Some(radius)=sphere{let r=x.hypot(y);let z=(d[0]*0.0+d[1])+d[2]*0.0;if r<=1e-9{x=if z<=0.0{0.0}else{radius*std::f32::consts::PI};y=0.0;}else{let arc=radius*r.atan2(-z);x=(x/r)*arc;y=(y/r)*arc;}}
  ys.push(y);let mut best=f32::MAX;let mut chosen=0;let mut u=0.0;
  let point=|j:usize|{let(s,c)=profile_sin_cos(angles[j]);[radii[j]*c,radii[j]*s]};
  for j in 0..samples{let p=point(j);let q=point((j+1)%samples);let dx=q[0]-p[0];let dy=q[1]-p[1];let len=dx*dx+dy*dy;let t=if len>0.0{(((x-p[0])*dx+(y-p[1])*dy)/len).clamp(0.0,1.0)}else{0.0};let xx=p[0]+dx*t-x;let yy=p[1]+dy*t-y;let dist=xx*xx+yy*yy;if dist<best{best=dist;chosen=j;u=t;}}
  let next=(chosen+1)%samples;let end=if next==0{total}else{lengths[next]};arcs.push((i,lengths[chosen]+u*(end-lengths[chosen])));
 }
 arcs.sort_by(|x,y|x.1.partial_cmp(&y.1).unwrap());let wrap=|x:f32|{let r=x%total;if r<0.0{r+total.abs()}else{r}};
 let mut boundaries:Vec<_>=(0..n).map(|i|wrap(arcs[i].1+wrap(arcs[(i+1)%n].1-arcs[i].1)*0.5)).collect();
 let minimum=total*0.03;let mut minima_sum=-0.0f32;for _ in 0..n{minima_sum+=minimum;}
 if minima_sum<total{
  let mut widths:Vec<_>=(0..n).map(|i|wrap(arcs[i].1-arcs[(i+n-1)%n].1)*0.5+wrap(arcs[(i+1)%n].1-arcs[i].1)*0.5).collect();
  for _ in 0..8{let mut deficit=0.0f32;let mut surplus=-0.0f32;for &w in &widths{deficit+=(minimum-w).max(0.0);surplus+=(w-minimum).max(0.0);}if deficit<=1e-9 || surplus<=1e-9{break;}let ratio=(deficit/surplus).min(1.0);for w in &mut widths{*w=if *w<minimum{minimum}else{*w-(*w-minimum)*ratio};}}
  let mut rebuilt=vec![boundaries[0];n];for i in 1..n{rebuilt[i]=rebuilt[i-1]+widths[i];}
  let mut shift=0.0f32;for i in 0..n{let d=wrap(boundaries[i]-rebuilt[i]);shift+=if d>total*0.5{d-total}else{d};}shift/=n as f32;
  boundaries=rebuilt.into_iter().map(|x|wrap(shift+x)).collect();
 }
 let width=(max-min).max(1e-6);let thickness=width*0.2;let mut top_depth=width*0.22;
 if !eye_heads.is_empty(){let mut sum=-0.0f32;let mut count=0;for(i,p)in tails.iter().enumerate(){if upper[i]{let mut near=f32::MAX;for e in &eye_heads{let d=std::array::from_fn::<_,3,_>(|k|p[k]-e[k]);near=near.min((d[2]*d[2]+(d[1]*d[1]+d[0]*d[0])).sqrt());}sum+=near;count+=1;}}if count>0{top_depth=top_depth.min((sum/count as f32)*0.45);}}
 // Native computes the taper extents with independent sinf on polar samples.
 let mut positive=0.0f32;let mut negative=0.0f32;for i in 0..samples{let y=radii[i]*angles[i].sin();positive=positive.max(y);negative=negative.max(-y);}
 let mut result:Vec<Option<Bound<'py,PyDict>>>=(0..n).map(|_|None).collect();
 for i in 0..n{let(index,mut arc)=arcs[i];let left=boundaries[(i+n-1)%n];let right=boundaries[i];let span=wrap(right-left);if wrap(arc-left)>span{arc=wrap(left+span*0.5);}
  let out=PyDict::new(py);out.set_item("kind","profile")?;for key in ["center","axis","lateral","angles","radii","heights","lengths"]{out.set_item(key,ring.get_item(key)?.unwrap())?;}
  if let Some(r)=sphere{out.set_item("sphere",[r])?;}if let Some(pl)=plane{out.set_item("plane",pl)?;}out.set_item("fallback_center",tails[index])?;
  out.set_item("params",[total,arc,wrap(arc-left)*1.05,wrap(right-arc)*1.05,if ys[index]<0.0{-1.0}else{1.0},0.0,thickness,if upper[index]{top_depth}else{width*0.22*0.5},positive,negative,1.0,1.0,width*0.3,0.0])?;result[index]=Some(out);
 }
 Ok(result.into_iter().map(Option::unwrap).collect())
}

/// Base axial radius sampling (0x58bd4/0x59b98), before core-chain policy,
/// endpoint caps, ratio limiting and optional bucket-shape fitting.
#[pyfunction]
#[pyo3(signature=(heads,tails,verts,faces,voxel_size,bounded=true))]
pub fn bone_base_radii(py:Python<'_>,heads:Vec<[f32;3]>,tails:Vec<[f32;3]>,verts:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,voxel_size:f64,bounded:bool)->PyResult<(Vec<[f32;2]>,Vec<f32>)>{
 if heads.len()!=tails.len()||(bounded&&heads.len().saturating_mul(112)>20_000_000)||!voxel_size.is_finite()||voxel_size<=0.0||heads.iter().chain(&tails).flatten().any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid base radius skeleton"));}
 let bvh=crate::bvh::MeshBvh::new(py,verts,faces)?;
 const TRIG:[[f64;2];16]=[[1.0,0.0],[0.9238795325112867,0.3826834323650898],[0.7071067811865476,0.7071067811865475],[0.38268343236508984,0.9238795325112867],[6.123233995736766e-17,1.0],[-0.3826834323650897,0.9238795325112867],[-0.7071067811865475,0.7071067811865476],[-0.9238795325112867,0.3826834323650899],[-1.0,1.2246467991473532e-16],[-0.9238795325112868,-0.38268343236508967],[-0.7071067811865477,-0.7071067811865475],[-0.38268343236509034,-0.9238795325112865],[-1.8369701987210297e-16,-1.0],[0.38268343236509,-0.9238795325112866],[0.7071067811865474,-0.7071067811865477],[0.9238795325112865,-0.3826834323650904]];
 py.allow_threads(move || {
 let floor=voxel_size*0.75;let mut ends=Vec::new();let mut mids=Vec::new();
 for (head,tail) in heads.iter().zip(&tails){let h=head.map(f64::from);let delta=std::array::from_fn::<_,3,_>(|k|tail[k] as f64-h[k]);let length=(delta[0]*delta[0]+delta[1]*delta[1]+delta[2]*delta[2]).sqrt();
  if length<1e-8{ends.push([floor as f32;2]);mids.push(floor as f32);continue;}
  let d=delta.map(|x|x/length);let helper=if d[0].abs()<0.9{[1.0,0.0]}else{[0.0,1.0]};
  let mut u=[d[1]*0.0-d[2]*helper[1],d[2]*helper[0]-d[0]*0.0,d[0]*helper[1]-d[1]*helper[0]];let len=(u[2]*u[2]+(u[0]*u[0]+u[1]*u[1])).sqrt();u=u.map(|x|x/len);let v=[d[1]*u[2]-d[2]*u[1],d[2]*u[0]-d[0]*u[2],d[0]*u[1]-d[1]*u[0]];
  let directions=TRIG.map(|[c,s]|std::array::from_fn::<_,3,_>(|k|(u[k]*c+v[k]*s) as f32));
  let mut pair=[floor as f32;2];for (i,position) in [0.25f64,0.75].into_iter().enumerate(){let origins=[-0.1,-0.0,0.1].map(|offset|std::array::from_fn(|k|(h[k]+delta[k]*(position+offset)) as f32));let mut smallest=f64::INFINITY;
   for direction in directions{let mut hits=Vec::new();for p in origins{if let Some((distance,_))=bvh.raycast(p,direction){let distance=distance as f64;if distance>=1e-4&&distance<=length+length{hits.push(distance);}}}if !hits.is_empty(){hits.sort_by(f64::total_cmp);smallest=smallest.min(hits[hits.len()/2]);}}
   pair[i]=if smallest.is_finite(){smallest.max(floor) as f32}else{floor as f32};
  }
  let middle=std::array::from_fn(|k|(h[k]+delta[k]*0.5) as f32);let mut largest=f64::NEG_INFINITY;
  for direction in directions{if let Some((distance,_))=bvh.raycast(middle,direction){let distance=distance as f64;if distance>=1e-4{largest=largest.max(distance);}}}
  ends.push(pair);mids.push(if largest.is_finite(){largest.max(floor).min(length) as f32}else{floor as f32});
 }
 Ok((ends,mids))
 })
}

// A bounded, owned nearest-distance index. Distances use the same f64
// subtraction and (dx*dx + dy*dy) + dz*dz order as the former exhaustive scan.
// Bounding boxes prune only when their lower bound cannot improve the minimum.
struct RadiusNode { lo:[f64;3], hi:[f64;3], start:usize, end:usize, children:Option<(usize,usize)> }
struct RadiusIndex { points:Vec<[f32;3]>, nodes:Vec<RadiusNode>, bounded:bool }
impl RadiusIndex {
 fn new(points:Vec<[f32;3]>,bounded:bool)->Self {
  let mut tree=Self{points,nodes:Vec::new(),bounded};let n=tree.points.len();tree.build(0,n);tree
 }
 fn build(&mut self,start:usize,end:usize)->usize {
  let mut lo=[f64::INFINITY;3];let mut hi=[f64::NEG_INFINITY;3];
  for p in &self.points[start..end] {for k in 0..3 {lo[k]=lo[k].min(p[k] as f64);hi[k]=hi[k].max(p[k] as f64);}}
  let id=self.nodes.len();self.nodes.push(RadiusNode{lo,hi,start,end,children:None});
  if end-start>16 {
   let axis=(0..3).max_by(|&a,&b|(hi[a]-lo[a]).total_cmp(&(hi[b]-lo[b]))).unwrap();let middle=(start+end)/2;
   self.points[start..end].select_nth_unstable_by(middle-start,|a,b|a[axis].total_cmp(&b[axis]));
   let left=self.build(start,middle);let right=self.build(middle,end);self.nodes[id].children=Some((left,right));
  }id
 }
 fn lower(&self,id:usize,p:[f64;3])->f64 {
  let n=&self.nodes[id];let d: [f64;3]=std::array::from_fn(|k|if p[k]<n.lo[k]{n.lo[k]-p[k]}else if p[k]>n.hi[k]{p[k]-n.hi[k]}else{0.0});
  d[0]*d[0]+d[1]*d[1]+d[2]*d[2]
 }
 fn visit(&self,id:usize,p:[f64;3],best:&mut f64,work:&mut usize)->PyResult<()> {
  if self.bounded{*work+=1;if *work>20_000_000{return Err(PyValueError::new_err("radius sampling exceeds visited-work budget"));}}
  if self.lower(id,p)>=*best{return Ok(());}
  let n=&self.nodes[id];
  if let Some((a,b))=n.children {
   let (first,second)=if self.lower(a,p)<=self.lower(b,p){(a,b)}else{(b,a)};
   self.visit(first,p,best,work)?;self.visit(second,p,best,work)?;
  }else{
   for q in &self.points[n.start..n.end]{
    if self.bounded{*work+=1;if *work>20_000_000{return Err(PyValueError::new_err("radius sampling exceeds visited-work budget"));}}
    let dx=q[0] as f64-p[0];let dy=q[1] as f64-p[1];let dz=q[2] as f64-p[2];*best=best.min(dx*dx+dy*dy+dz*dz);
   }
  }Ok(())
 }
 fn nearest_squared(&self,p:[f64;3],work:&mut usize)->PyResult<f64>{let mut best=f64::INFINITY;self.visit(0,p,&mut best,work)?;Ok(best)}
}

/// Radius coverage expansion, 0x197fe0. Independent bounded nearest-distance
/// index replaces the original grid traversal, retaining f64 arithmetic.
#[pyfunction]
#[pyo3(signature=(points,heads,tails,radii,mids,cell,char_size=1.8,samples=10,coverage=8,bounded=true))]
pub fn fit_cloud_radii(py:Python<'_>,points:Vec<[f32;3]>,heads:Vec<[f32;3]>,tails:Vec<[f32;3]>,radii:Vec<[f32;2]>,mids:Vec<f32>,cell:f64,char_size:f64,samples:usize,coverage:usize,bounded:bool)->PyResult<(Vec<[f32;2]>,Vec<f32>)>{
 let n=heads.len();if points.is_empty()||n!=tails.len()||n!=radii.len()||n!=mids.len()||samples==0||samples>256||cell<=0.0||!cell.is_finite()||!char_size.is_finite()||(bounded&&(n.saturating_mul(samples)>20_000_000||n.saturating_add(points.len()).saturating_mul(96)>128*1024*1024||points.len().saturating_mul((usize::BITS-points.len().leading_zeros()) as usize)>20_000_000))||points.iter().chain(&heads).chain(&tails).flatten().chain(radii.iter().flatten()).chain(&mids).any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid bounded radius coverage inputs"));}
 py.allow_threads(move || {
 let tree=RadiusIndex::new(points,bounded);let mut work=0usize;
 let mut out=radii;let mut mid=mids;let index=coverage.min(samples).saturating_sub(1);let max_cells=((char_size*0.45/cell) as i64).max(1)+1;
 for i in 0..n{let h=heads[i].map(f64::from);let t=tails[i].map(f64::from);let d=std::array::from_fn::<_,3,_>(|k|t[k]-h[k]);if (d[0]*d[0]+d[1]*d[1]+d[2]*d[2]).sqrt()<1e-9{continue;}
  let r=out[i].map(f64::from);let m=mid[i] as f64;let mut gaps=Vec::new();
  for j in 0..samples{let s=(j as f64+0.5)/samples as f64;let p=std::array::from_fn::<_,3,_>(|k|h[k]+d[k]*s);let distance=tree.nearest_squared(p,&mut work)?;
   let (left,right,u)=if s>0.5{(m,r[1],s-0.5)}else{(r[0],m,s)};gaps.push(distance.sqrt()-(left+(u+u)*(right-left)));
  }
  gaps.sort_by(f64::total_cmp);let gap=gaps[index];if gap>0.0{let cells=((gap/cell-1e-9).ceil() as i64).min(max_cells);let delta=cell*cells as f64;out[i]=r.map(|x|(x+delta) as f32);mid[i]=(m+delta) as f32;}
 }Ok((out,mid))
 })
}
