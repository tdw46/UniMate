//! Selected-bone re-skinning reconstructed from join::scoped_reskin.
//! CSR duplicate group entries use the last value without changing group order.
use numpy::{ndarray::Array2,IntoPyArray,PyArray1,PyArray2,PyReadonlyArray1,PyReadonlyArray2,PyArrayMethods,PyUntypedArrayMethods};
use pyo3::{prelude::*,exceptions::PyValueError};
use std::collections::HashSet;
// Raw byte reads avoid invalid Rust bool references for noncanonical NumPy storage.
fn bool_bytes(a:&PyReadonlyArray1<'_,bool>)->Vec<u8>{
 (0..a.len()).map(|i|unsafe{a.data().cast::<u8>().offset(i as isize*a.strides()[0]).read()}).collect()
}
#[pyfunction]
#[pyo3(signature=(weights,bones,targets,prior_offsets,prior_groups,prior_weights,keep_groups,keep_bones,fill_source=None,rig_groups=None,replace=false))]
pub fn scoped_reskin<'py>(py:Python<'py>,weights:PyReadonlyArray2<'py,f32>,bones:PyReadonlyArray2<'py,i32>,targets:Option<PyReadonlyArray1<'py,bool>>,prior_offsets:PyReadonlyArray1<'py,i64>,prior_groups:PyReadonlyArray1<'py,i32>,prior_weights:PyReadonlyArray1<'py,f32>,keep_groups:PyReadonlyArray1<'py,i32>,keep_bones:PyReadonlyArray1<'py,bool>,fill_source:Option<PyReadonlyArray1<'py,i64>>,rig_groups:Option<PyReadonlyArray1<'py,i32>>,replace:bool)->PyResult<(Bound<'py,PyArray1<bool>>,Bound<'py,PyArray2<f32>>,Bound<'py,PyArray1<f32>>)> {
 let w=crate::array_input::two(&weights);let b=crate::array_input::two(&bones);let (n,k)=w.dim();
 if b.dim()!=w.dim(){return Err(PyValueError::new_err("weights and bones must share their shape"));}
 let off=crate::array_input::one(&prior_offsets);let groups=crate::array_input::one(&prior_groups);let old=crate::array_input::one(&prior_weights);let kb=bool_bytes(&keep_bones);
 if off.len()!=n+1 || groups.len()!=old.len() || off.iter().any(|&x|x<0 || x as usize>groups.len()) {return Err(PyValueError::new_err("prior_offsets must be (V + 1,) into prior_groups / prior_weights"));}
 let target=targets.as_ref().map(bool_bytes);if target.as_ref().is_some_and(|x|x.len()!=n){return Err(PyValueError::new_err("targets must be (V,)"));}
 let fill=fill_source.as_ref().map(crate::array_input::one);if fill.as_ref().is_some_and(|x|x.len()!=n || x.iter().any(|&v|v>=n as i64)){return Err(PyValueError::new_err("fill_source must be (V,), indices into the mesh"));}
 if b.iter().any(|&x|x>=0&&x as usize>=kb.len()){return Err(PyValueError::new_err("a bone index is past keep_bones"));}
 let picked:HashSet<i32>=crate::array_input::one(&keep_groups).iter().copied().filter(|x|*x>=0).collect();
 let rig:HashSet<i32>=rig_groups.as_ref().map(|x|crate::array_input::one(x).iter().copied().collect()).unwrap_or_else(||groups.iter().copied().collect());
 let belongs=|g:i32|g>=0&&(rig.contains(&g)||picked.contains(&g));
 let row=|v:usize|->PyResult<Vec<(i32,f32)>>{if off[v+1]<off[v]{return Err(pyo3::panic::PanicException::new_err("capacity overflow"));}let mut r:Vec<(i32,f32)>=Vec::new();for j in off[v] as usize..off[v+1] as usize{if let Some(p)=r.iter_mut().find(|p|p.0==groups[j]){p.1=old[j]}else{r.push((groups[j],old[j]))}}Ok(r)};
 let mut mask=vec![false;n];let mut out=Array2::<f32>::zeros((n,k));let mut prior:Vec<f32>=old.iter().copied().collect();
 if k==0{return Ok((PyArray1::from_vec(py,Vec::new()),out.into_pyarray(py),PyArray1::from_vec(py,prior)));}
 let mut order:Vec<usize>=(0..n).filter(|&v|fill.as_ref().is_none_or(|x|x[v]==v as i64)).collect();
 if let Some(f)=fill.as_ref(){order.extend((0..n).filter(|&v|f[v]!=v as i64));}
 for v in order {
  if target.as_ref().is_some_and(|t|t[v]&1==0){continue;}
  let valid=|j:usize|b[[v,j]]>=0&&!(w[[v,j]]<=0.0);
  let selected=|j:usize|valid(j)&&kb[b[[v,j]] as usize]==1;
  let sum=(0..k).filter(|&j|selected(j)).fold(0.0f64,|s,j|s+w[[v,j]] as f64);
  if !replace && sum<0.000001{continue;}
  let r=row(v)?;let picked_sum=r.iter().filter(|(g,_)|*g>=0&&picked.contains(g)).fold(0.0f64,|s,(_,w)|s+*w as f64);
  let factor;
  if replace {
   if sum<=0.0001 && picked_sum<=0.0001{continue;}
   let others=r.iter().filter(|(g,_)|belongs(*g)&&!picked.contains(g)).fold(0.0f64,|s,(_,w)|s+*w as f64);
   for j in 0..k{if valid(j)&&(others<=0.0001||kb[b[[v,j]] as usize]&1!=0){out[[v,j]]=w[[v,j]];}}
   factor=if !(others<=0.0001){(1.0-sum).max(0.0)/others}else{0.0};
  }else{
   if sum<0.000001{continue;}
   if let Some(f)=fill.as_ref(){let source=f[v];if source!=v as i64&&source != -2{
    if source<0{continue;}
    let s=source as usize;
    let source_amount=if mask[s]{out.row(s).iter().fold(0.0f64,|a,&x|a+x as f64)}else{row(s)?.iter().filter(|(g,_)|*g>=0&&picked.contains(g)).fold(0.0f64,|a,(_,x)|a+*x as f64)};
    if !(source_amount>0.0001){continue;}
   }}
   let total=r.iter().filter(|(g,_)|belongs(*g)).fold(0.0f64,|s,(_,w)|s+*w as f64);
   let fraction;if total>0.0001{if picked_sum<total*0.000001{continue;}fraction=picked_sum/total;factor=1.0/total;}else{fraction=1.0;factor=0.0;}
   for j in 0..k{if selected(j){out[[v,j]]=(fraction*(w[[v,j]] as f64/sum)) as f32;}}
  }
  mask[v]=true;
  for j in off[v] as usize..off[v+1] as usize{let g=groups[j];if belongs(g)&&!picked.contains(&g){let x=r.iter().find(|(a,_)|*a==g).map_or(0.0,|(_,x)|*x as f64);prior[j]=(factor*x) as f32;}}
 }
 Ok((PyArray1::from_vec(py,mask),out.into_pyarray(py),PyArray1::from_vec(py,prior)))
}
