//! Name-table selection only; full torso validation and rig_map are separate gates.
use pyo3::{prelude::*,exceptions::PyValueError};
use regex::Regex;
use std::sync::OnceLock;
use crate::rig_family_table::FAMILIES;
fn patterns()-> &'static Vec<(Vec<Regex>,Vec<Regex>)>{
 static P:OnceLock<Vec<(Vec<Regex>,Vec<Regex>)>>=OnceLock::new();
 P.get_or_init(||FAMILIES.iter().map(|f|(f.required.iter().map(|p|Regex::new(&format!("^(?:{p})$")).unwrap()).collect(),f.exclude.iter().map(|p|Regex::new(&format!("^(?:{p})$")).unwrap()).collect())).collect())
}
#[pyfunction]
pub fn rig_family_keys()->Vec<&'static str>{FAMILIES.iter().map(|f|f.key).collect()}
#[pyfunction]
pub fn select_rig_family(names:Vec<String>)->PyResult<Option<(&'static str,&'static str)>>{
 if names.len()>16384 || names.iter().any(|s|s.len()>4096){return Err(PyValueError::new_err("research skeleton bound exceeded"))}
 let names:Vec<_>=names.iter().map(|s|s.split_once(':').map_or(s.as_str(),|(_,tail)|tail).trim().to_lowercase()).collect();
 for (i,(required,excluded)) in patterns().iter().enumerate(){
  if required.iter().all(|p|names.iter().any(|s|p.is_match(s))) && !excluded.iter().any(|p|names.iter().any(|s|p.is_match(s))){return Ok(Some((FAMILIES[i].key,FAMILIES[i].label)))}
 } Ok(None)
}
