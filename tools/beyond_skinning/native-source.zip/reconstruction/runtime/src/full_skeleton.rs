//! Independent local/world skeleton preparation and hierarchy-tail repair.
use numpy::{
    IntoPyArray, PyArrayMethods, PyReadonlyArray1, PyReadonlyArray2, PyUntypedArrayMethods,
};
use pyo3::{exceptions::PyValueError, prelude::*};
type V = [f32; 3];
fn sub(a: V, b: V) -> V {
    std::array::from_fn(|k| a[k] - b[k])
}
fn dot(a: V, b: V) -> f32 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}
fn norm(a: V) -> f32 {
    dot(a, a).sqrt()
}
fn normalized(a: V) -> Option<V> {
    let len = norm(a);
    if dot(a, a) <= 0.0 || !len.is_finite() {
        None
    } else {
        let inv = 1.0 / len;
        Some(a.map(|x| x * inv))
    }
}
fn children(p: &[i64]) -> Vec<Vec<usize>> {
    let n = p.len();
    let mut c = vec![vec![]; n];
    for (i, &j) in p.iter().enumerate() {
        if j >= 0 && (j as usize) < n && j as usize != i {
            c[j as usize].push(i);
        }
    }
    c
}
fn sizes(c: &[Vec<usize>]) -> Vec<usize> {
    fn visit(i: usize, c: &[Vec<usize>], memo: &mut [usize], depth: usize) -> usize {
        if depth > c.len() || memo[i] != 0 {
            return memo[i].max(1);
        }
        let mut s = 1usize;
        for &j in &c[i] {
            s = s.wrapping_add(visit(j, c, memo, depth + 1));
        }
        memo[i] = s;
        s
    }
    let mut memo = vec![0; c.len()];
    (0..c.len()).map(|i| visit(i, c, &mut memo, 0)).collect()
}
fn distal(h: &[V], c: &[Vec<usize>], eps: f32) -> Vec<bool> {
    let n = h.len();
    let mut out = vec![false; n];
    for _ in 0..n {
        let mut changed = false;
        for i in 0..n {
            if !out[i]
                && c[i]
                    .iter()
                    .any(|&j| out[j] || !(norm(sub(h[j], h[i])) <= eps))
            {
                out[i] = true;
                changed = true;
            }
        }
        if !changed {
            break;
        }
    }
    out
}
fn ancestor(i: usize, j: usize, p: &[i64]) -> bool {
    let mut x = p[i];
    for _ in 0..p.len() {
        if x < 0 || x as usize >= p.len() {
            break;
        }
        if x as usize == j {
            return true;
        }
        x = p[x as usize];
    }
    false
}
fn along(point: V, start: V, end: V) -> Option<f32> {
    let d = sub(end, start);
    let s = dot(d, d);
    if s <= 0.0 {
        return None;
    }
    let t = dot(sub(point, start), d) / s;
    if !(t >= 0.1 && t <= 0.9) {
        return None;
    }
    let near = std::array::from_fn(|k| start[k] + d[k] * t);
    if norm(sub(point, near)) <= s.sqrt() * 0.1 {
        Some(t)
    } else {
        None
    }
}
fn preceding(i: usize, h: &[V], p: &[i64], eps: f32, blocked: &[bool]) -> f32 {
    let n = h.len();
    let mut at = i;
    let mut prev = i;
    let mut count = 0;
    let mut length = 0.0f32;
    for _ in 0..n {
        let parent = p[at];
        if parent < 0 || parent as usize >= n || count > 2 {
            break;
        }
        at = parent as usize;
        if blocked[at] {
            break;
        }
        let d = norm(sub(h[prev], h[at]));
        if d > eps {
            length = length.max(d);
            count += 1;
            prev = at;
        }
    }
    length
}
fn direction(i: usize, h: &[V], p: &[i64], eps: f32) -> (V, bool) {
    let mut at = i;
    for _ in 0..h.len() {
        let parent = p[at];
        if parent < 0 || parent as usize >= h.len() {
            break;
        }
        at = parent as usize;
        let d = sub(h[i], h[at]);
        if !(norm(d) <= eps) {
            if let Some(v) = normalized(d) {
                return (v, true);
            }
        }
    }
    ([0.0, 0.0, 1.0], false)
}
fn repair(h: &[V], p: &[i64], diag: f32) -> (Vec<V>, Vec<bool>) {
    let n = h.len();
    let eps = diag * 0.0001;
    let raw = children(p);
    let size = sizes(&raw);
    let live = distal(h, &raw, eps);
    let mut suppressed = vec![false; n];
    for i in 0..n {
        for j in 0..n {
            if i == j || !(norm(sub(h[i], h[j])) <= eps) {
                continue;
            }
            if size[i] < size[j] || (j < i && size[j] == size[i]) {
                let a = p[i];
                let b = p[j];
                if a >= 0
                    && b >= 0
                    && (a as usize) < n
                    && (b as usize) < n
                    && norm(sub(h[a as usize], h[b as usize])) > eps
                    && !ancestor(i, j, p)
                    && !ancestor(j, i, p)
                {
                    suppressed[i] = true;
                    break;
                }
            }
        }
    }
    for _ in 0..n {
        let mut changed = false;
        for i in 0..n {
            let parent = p[i];
            if suppressed[i]
                || parent < 0
                || parent as usize >= n
                || !(norm(sub(h[i], h[parent as usize])) <= eps)
            {
                continue;
            }
            let parent = parent as usize;
            let none = !raw[i].is_empty() && raw[i].iter().all(|&j| suppressed[j]);
            let sibling = raw[parent].iter().any(|&j| {
                j != i && !suppressed[j] && (live[j] || !(norm(sub(h[j], h[parent])) <= eps))
            });
            if none || (!live[i] && (suppressed[parent] || sibling)) {
                suppressed[i] = true;
                changed = true;
            }
        }
        if !changed {
            break;
        }
    }
    let c: Vec<Vec<usize>> = raw
        .iter()
        .map(|v| v.iter().copied().filter(|&j| !suppressed[j]).collect())
        .collect();
    let distinct: Vec<Vec<usize>> = c
        .iter()
        .enumerate()
        .map(|(i, v)| {
            v.iter()
                .copied()
                .filter(|&j| norm(sub(h[j], h[i])) > eps)
                .collect()
        })
        .collect();
    let mut roll = vec![vec![]; n];
    for i in 0..n {
        for &j in &distinct[i] {
            if c[j].is_empty()
                && distinct[i]
                    .iter()
                    .any(|&k| k != j && along(h[j], h[i], h[k]).is_some())
            {
                roll[i].push(j);
            }
        }
    }
    let candidates: Vec<Vec<usize>> = distinct
        .iter()
        .enumerate()
        .map(|(i, v)| v.iter().copied().filter(|j| !roll[i].contains(j)).collect())
        .collect();
    let mut ambiguous = vec![false; n];
    for i in 0..n {
        let mut at = i;
        let mut found = false;
        for _ in 0..n {
            let par = p[at];
            if par < 0 || par as usize >= n {
                break;
            }
            at = par as usize;
            if norm(sub(h[at], h[i])) > eps {
                found = true;
                break;
            }
        }
        ambiguous[i] = !found && candidates[i].len() == 1 && distinct[candidates[i][0]].len() > 1;
    }
    let blocked: Vec<bool> = (0..n).map(|i| suppressed[i] || ambiguous[i]).collect();
    let live = distal(h, &c, eps);
    let size = sizes(&c);
    let root = (0..n).find(|&i| p[i] < 0).unwrap_or(0);
    let mut errors = [0.0f32; 2];
    for axis in 0..2 {
        for i in 0..n {
            let mut target = h[i];
            target[axis] = h[root][axis] * 2.0 - target[axis];
            let nearest = h
                .iter()
                .map(|&v| norm(sub(v, target)))
                .fold(f32::INFINITY, f32::min);
            errors[axis] += nearest;
        }
    }
    let axis = usize::from(errors[1] < errors[0]);
    let center = h[root][axis];
    let mut tails = vec![[0.0; 3]; n];
    let mut ends = vec![false; n];
    for i in 0..n {
        if suppressed[i] || ambiguous[i] || (distinct[i].is_empty() && !c[i].is_empty()) {
            tails[i] = h[i];
            continue;
        }
        let (dir, has_parent) = direction(i, h, p, eps);
        let mut cand = candidates[i].clone();
        if cand.len() >= 2 && (h[i][axis] - center).abs() <= diag * 0.02 {
            let mid: Vec<_> = cand
                .iter()
                .copied()
                .filter(|&j| (h[j][axis] - center).abs() <= diag * 0.02)
                .collect();
            if !mid.is_empty() {
                cand = mid;
            }
        }
        let extrapolate = if cand.is_empty() {
            true
        } else if cand.len() == 1 {
            let j = cand[0];
            distinct[j].is_empty()
                && live[j]
                && norm(sub(h[j], h[i])) < preceding(i, h, p, eps, &blocked) * 0.5
        } else {
            false
        };
        if extrapolate {
            ends[i] = true;
            let mut l = preceding(i, h, p, eps, &blocked);
            if l <= 0.0 {
                l = diag * 0.1;
            }
            tails[i] = std::array::from_fn(|k| dir[k] * l + h[i][k]);
        } else if cand.len() == 1 {
            tails[i] = h[cand[0]];
        } else if has_parent {
            let scores: Vec<f32> = cand
                .iter()
                .map(|&j| {
                    normalized(sub(h[j], h[i]))
                        .map_or(-1.0, |d| d[2] * dir[2] + (d[0] * dir[0] + d[1] * dir[1]))
                })
                .collect();
            let max = scores.iter().copied().fold(f32::NEG_INFINITY, f32::max);
            let mut sum = [0.0f32; 3];
            let mut count = 0;
            for (k, &j) in cand.iter().enumerate() {
                if !(scores[k] < max - 0.15) {
                    for a in 0..3 {
                        sum[a] += h[j][a];
                    }
                    count += 1;
                }
            }
            let inv = 1.0 / (count as f32);
            tails[i] = sum.map(|x| x * inv);
        } else {
            let mut best = cand[0];
            for &j in &cand[1..] {
                if size[best] <= size[j] {
                    best = j;
                }
            }
            tails[i] = h[best];
        }
    }
    // Reattach intermediate siblings along the selected parent direction.
    for i in 0..n {
        let start = h[i];
        let end = tails[i];
        let mut joints: Vec<_> = roll[i]
            .iter()
            .filter_map(|&j| along(h[j], start, end).map(|t| (t, j)))
            .collect();
        joints.sort_by(|a, b| a.0.total_cmp(&b.0));
        for &(_, j) in &joints {
            let next = joints
                .iter()
                .find(|&&(_, k)| {
                    norm(sub(h[k], h[j])) > eps && dot(sub(end, start), sub(h[k], h[j])) > 0.0
                })
                .map_or(end, |&(_, k)| h[k]);
            tails[j] = next;
            ends[j] = false;
        }
    }
    (tails, ends)
}
#[pyfunction]
#[pyo3(signature=(heads_local,tails_local,lengths,parent_idx,deform,matrix_world=None,force=None))]
pub fn full_skeleton<'py>(
    py: Python<'py>,
    heads_local: PyReadonlyArray2<'py, f32>,
    tails_local: PyReadonlyArray2<'py, f32>,
    lengths: PyReadonlyArray1<'py, f32>,
    parent_idx: PyReadonlyArray1<'py, i64>,
    deform: PyReadonlyArray1<'py, bool>,
    matrix_world: Option<PyReadonlyArray2<'py, f64>>,
    force: Option<bool>,
) -> PyResult<Py<PyAny>> {
    let h = crate::array_input::owned_two(&heads_local);
    let t = crate::array_input::owned_two(&tails_local);
    let n = h.nrows();
    if h.ncols() != 3 || t.dim() != h.dim() {
        return Err(PyValueError::new_err(
            "heads_local and tails_local must both be (N, 3)",
        ));
    }
    if lengths.len() != n || parent_idx.len() != n || deform.len() != n {
        return Err(PyValueError::new_err(
            "lengths, parent_idx and deform must be (N,)",
        ));
    }
    let matrix = matrix_world.map(|a| crate::array_input::owned_two(&a));
    if matrix.as_ref().is_some_and(|m| m.dim() != (4, 4)) {
        return Err(PyValueError::new_err("matrix_world must be (4, 4)"));
    }
    let transform = |a: &ndarray::Array2<f32>| -> Vec<V> {
        a.rows()
            .into_iter()
            .map(|r| {
                if let Some(m) = &matrix {
                    std::array::from_fn(|k| {
                        (m[[k, 3]]
                            + (r[1] as f64) * m[[k, 1]]
                            + ((r[0] as f64) * m[[k, 0]] + (r[2] as f64) * m[[k, 2]]))
                            as f32
                    })
                } else {
                    [r[0], r[1], r[2]]
                }
            })
            .collect()
    };
    let heads = transform(&h);
    let mut tails = transform(&t);
    let mut lens = crate::array_input::owned_one(&lengths);
    let p = crate::array_input::owned_one(&parent_idx).to_vec();
    let d: Vec<u8> = (0..n)
        .map(|i| unsafe {
            deform
                .data()
                .cast::<u8>()
                .offset(i as isize * deform.strides()[0])
                .read()
        })
        .collect();
    let mut rebuilt = force == Some(true) && n > 0;
    let mut mask = None;
    if n > 0 && force != Some(false) {
        let mut low = heads[0];
        let mut high = heads[0];
        for v in &heads {
            for a in 0..3 {
                low[a] = low[a].min(v[a]);
                high[a] = high[a].max(v[a]);
            }
        }
        let diag = norm(sub(high, low));
        if force.is_none() {
            let c = children(&p);
            let mut total = 0;
            let mut aligned = 0;
            for i in 0..n {
                if d[i] != 1 {
                    continue;
                }
                let c: Vec<_> = c[i]
                    .iter()
                    .copied()
                    .filter(|&j| d[j] == 1 && norm(sub(heads[j], heads[i])) > diag * 0.0001)
                    .collect();
                if c.is_empty() {
                    continue;
                }
                total += 1;
                if let Some(v) = normalized(sub(tails[i], heads[i])) {
                    if c.iter().any(|&j| {
                        normalized(sub(heads[j], heads[i]))
                            .is_some_and(|w| v[2] * w[2] + (v[0] * w[0] + v[1] * w[1]) > 0.9)
                    }) {
                        aligned += 1;
                    }
                }
            }
            rebuilt = total > 2 && (aligned as f32) < (total as f32) / 2.0;
        }
        if rebuilt {
            let (out, flags) = repair(&heads, &p, diag);
            tails = out;
            for i in 0..n {
                lens[i] = norm(sub(tails[i], heads[i]));
            }
            mask = Some(numpy::PyArray1::from_vec(py, flags));
        }
    }
    let segments =
        ndarray::Array3::from_shape_fn(
            (n, 2, 3),
            |(i, j, k)| if j == 0 { heads[i][k] } else { tails[i][k] },
        );
    Ok((
        segments.into_pyarray(py),
        lens.into_pyarray(py),
        rebuilt,
        mask,
    )
        .into_pyobject(py)?
        .into_any()
        .unbind())
}
