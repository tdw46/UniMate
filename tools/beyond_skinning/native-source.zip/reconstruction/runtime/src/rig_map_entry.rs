//! Typed public rig-map entry. Assembly is independent and rejects unrecovered routes.
use pyo3::prelude::*;
use numpy::{PyReadonlyArray1,PyReadonlyArray2,PyReadonlyArray3,PyArrayMethods,PyUntypedArrayMethods};
#[pyfunction]
#[pyo3(signature=(names,parent_idx,deform,segments,mesh_names=None,scope="verified",head=None,verts=None,edges=None))]
pub fn rig_map(py:Python<'_>,names:Vec<String>,parent_idx:PyReadonlyArray1<'_,i64>,deform:PyReadonlyArray1<'_,bool>,segments:PyReadonlyArray3<'_,f32>,mesh_names:Option<Vec<String>>,scope:&str,head:Option<i64>,verts:Option<PyReadonlyArray2<'_,f32>>,edges:Option<PyReadonlyArray2<'_,i64>>)->PyResult<Py<PyAny>> {
 let p=crate::array_input::owned_one(&parent_idx).to_vec();
 let d=(0..deform.len()).map(|i|unsafe{deform.data().cast::<u8>().offset(i as isize*deform.strides()[0]).read()}).collect::<Vec<_>>();
 if p.len()!=names.len()||d.len()!=names.len()||segments.shape()!=[names.len(),2,3]{return Err(pyo3::exceptions::PyValueError::new_err("names, parent_idx, deform and segments (N, 2, 3) must share length"));}
 if head.is_none()&&!matches!(scope,"verified"|"detected"|"off"){return Err(pyo3::exceptions::PyValueError::new_err(format!("unknown scope {:?}",scope)));}
 if verts.is_some()!=edges.is_some(){return Err(pyo3::exceptions::PyValueError::new_err("verts and edges go together"));}
 let a=crate::array_input::owned_three(&segments);
 let s=(0..names.len()).map(|i|[[a[[i,0,0]],a[[i,0,1]],a[[i,0,2]]],[a[[i,1,0]],a[[i,1,1]],a[[i,1,2]]]]).collect::<Vec<_>>();
 // Native extraction reads the first three/two columns; extra columns are ignored.
 // Validate even an empty skeleton/off scope, and snapshot before Python assembly.
 let surface=if let (Some(v),Some(e))=(verts,edges){
  if (v.shape()[0]>0&&v.shape()[1]<3)||(e.shape()[0]>0&&e.shape()[1]<2){return Err(pyo3::panic::PanicException::new_err("ndarray: index out of bounds"));}
  let va=crate::array_input::owned_two(&v);let ea=crate::array_input::owned_two(&e);
  let vs=(0..va.shape()[0]).map(|i|[va[[i,0]],va[[i,1]],va[[i,2]]]).collect::<Vec<_>>();
  let es=(0..ea.shape()[0]).map(|i|[ea[[i,0]],ea[[i,1]]]).collect::<Vec<_>>();
  Some((vs,es))
 }else{None};
 py.import("beyond_skinning.rig_map_public")?.getattr("assemble")?.call1((names,p,d,s,mesh_names,scope,head,surface)).map(Bound::unbind)
}
