// Binary table at 0x575078, 17 records of 120 bytes. Generated from pinned source.
pub struct Family {pub key: &'static str,pub label:&'static str,pub required:&'static [&'static str],pub exclude:&'static [&'static str],pub hips:&'static [&'static str],pub spine:&'static [&'static str],pub numeric:bool}
pub const FAMILIES: &[Family] = &[
Family {key:"mixamo",label:"Mixamo",required:&["hips","leftupleg"],exclude:&[],hips:&["hips"],spine:&["spine(\\d*)"],numeric:true},
Family {key:"arp",label:"Auto-Rig Pro",required:&["root\\.x","c_root_master\\.x"],exclude:&[],hips:&["root\\.x"],spine:&["(?:c_)?spine_(\\d+)(?:_bend)?\\.x"],numeric:true},
Family {key:"arp_export",label:"Auto-Rig Pro (export)",required:&["root\\.x","spine_01\\.x"],exclude:&["c_root_master\\.x"],hips:&["root\\.x"],spine:&["spine_(\\d+)\\.x"],numeric:true},
Family {key:"daz_g9",label:"DAZ Genesis 9",required:&["spine4","l_thigh"],exclude:&[],hips:&["pelvis"],spine:&["spine(\\d+)"],numeric:true},
Family {key:"daz_g8",label:"DAZ Genesis 3/8",required:&["abdomenlower","chestupper"],exclude:&[],hips:&["pelvis"],spine:&["abdomenlower","abdomenupper","chestlower","chestupper"],numeric:false},
Family {key:"rigify",label:"Rigify (DEF)",required:&["def-spine","def-spine\\.001"],exclude:&[],hips:&["def-spine"],spine:&["def-spine\\.001","def-spine\\.002","def-spine\\.003"],numeric:false},
Family {key:"def_words",label:"DEF_ words (Rigify-derived)",required:&["def_hips","def_spine 1"],exclude:&[],hips:&["def_hips"],spine:&["def_spine (\\d+)"],numeric:true},
Family {key:"mmd",label:"MMD",required:&["下半身","上半身"],exclude:&[],hips:&["下半身"],spine:&["上半身(\\d*)"],numeric:true},
Family {key:"biped",label:"3ds Max Biped",required:&["bip\\d+[ _-]pelvis"],exclude:&[],hips:&["bip\\d+[ _-]pelvis"],spine:&["bip\\d+[ _-]spine(\\d*)"],numeric:true},
Family {key:"unreal",label:"Unreal / MetaHuman",required:&["spine_01","thigh_l"],exclude:&[],hips:&["pelvis"],spine:&["spine_(\\d+)"],numeric:true},
Family {key:"cc",label:"Character Creator",required:&["cc_base_hip","cc_base_waist"],exclude:&[],hips:&["cc_base_pelvis"],spine:&["cc_base_waist","cc_base_spine01","cc_base_spine02"],numeric:false},
Family {key:"vrm",label:"VRoid / VRM",required:&["j_bip_c_hips"],exclude:&[],hips:&["j_bip_c_hips"],spine:&["j_bip_c_spine","j_bip_c_chest","j_bip_c_upperchest"],numeric:false},
Family {key:"secondlife",label:"Second Life",required:&["mpelvis","mtorso"],exclude:&[],hips:&["mpelvis"],spine:&["mspine1","mspine2","mtorso","mspine3","mspine4","mchest"],numeric:false},
Family {key:"roblox",label:"Roblox R15",required:&["lowertorso","uppertorso"],exclude:&[],hips:&["lowertorso"],spine:&["uppertorso"],numeric:false},
Family {key:"humanik",label:"HumanIK / Ready Player Me",required:&["hips","spine1","leftupleg"],exclude:&[],hips:&["hips"],spine:&["spine(\\d*)"],numeric:true},
Family {key:"rigify_metarig",label:"Rigify metarig",required:&["spine\\.001","thigh\\.l"],exclude:&["def-spine"],hips:&["spine"],spine:&["spine\\.(\\d+)"],numeric:true},
Family {key:"english",label:"English generic",required:&["(l|r|left|right)?[._ -]?(thigh|upleg|upperleg|upper_leg|up_leg)[._ -]?(l|r|left|right)?(\\.\\d+)?"],exclude:&[],hips:&["hips","pelvis","hip"],spine:&["waist|spine\\d*|spine[._-]\\d+|chest\\d*|chest[._-]\\d|upper_?chest|torso|torso[._-](lower|upper)|lower_?torso|upper_?torso"],numeric:false},
];
