//! Name/token and hierarchy face-role pass, recovered from 0x14ae6c.
//! This is not the separate 17-family humanoid rig map or geometric face pass.
use pyo3::{prelude::*,exceptions::PyValueError};
fn tokens(name:&str)->Vec<String>{
 let name=name.rsplit(':').next().unwrap_or(name);let mut out=Vec::new();let mut word=String::new();let mut previous='\0';
 let flush=|word:&mut String,out:&mut Vec<String>|{if !word.is_empty(){out.push(word.to_lowercase());word.clear();}};
 for c in name.chars(){
  if c.is_ascii_alphanumeric(){
   if (previous.is_ascii_lowercase()&&(c.is_ascii_uppercase()||c.is_ascii_digit())) || (previous.is_ascii_uppercase()&&c.is_ascii_digit()) || (previous.is_ascii_digit()&&c.is_ascii_alphabetic()){flush(&mut word,&mut out);}
   word.push(c);
  }else{flush(&mut word,&mut out);if c.is_alphabetic(){out.push(c.to_lowercase().collect());}}
  previous=c;
 }
 flush(&mut word,&mut out);out
}
pub(crate) fn role(parts:&[String])->Option<(&'static str,&'static str)>{
 let mut first=None;let(mut lid,mut lip,mut teeth,mut top,mut bottom,mut corner)=(false,false,false,false,false,false);let mut side="x";
 for t in parts{let r=match t.as_str(){
  "skull"|"cranium"|"頭"=>Some("skull"),
  "temple"|"forehead"|"額"=>Some("forehead"),
  "brow"|"brows"|"eyebrow"|"eyebrows"|"眉"=>Some("brow"),
  "eye"|"eyes"|"eyeball"|"目"|"眼"=>Some("eye"),
  "lid"|"lids"|"eyelid"|"eyelids"|"瞼"=>{lid=true;None},
  "eyecorner"=>Some("eyelid_corner"),
  "cheek"|"cheeks"|"頬"=>Some("cheek"),
  "nose"|"nostril"|"鼻"=>Some("nose"),
  "lip"|"lips"|"mouth"|"唇"|"口"=>{lip=true;None},
  "jaw"|"jawbone"|"jawroot"|"mandible"|"あご"|"顎"=>Some("jaw"),
  "chin"=>Some("chin"),"maxilla"=>Some("teeth_top"),
  "teeth"|"tooth"|"歯"=>{teeth=true;None},
  "tongue"|"tong"|"舌"=>Some("tongue"),"ear"|"ears"|"耳"=>Some("ear"),
  "top"|"upper"|"up"|"t"|"u"|"上"=>{top=true;None},
  "bot"|"bottom"|"low"|"lower"|"down"|"b"|"d"|"下"=>{bottom=true;None},
  "corner"|"corners"|"smile"=>{corner=true;None},
  "l"|"left"|"左"=>{side="l";None},"r"|"right"|"右"=>{side="r";None},
  "aim"|"target"|"hair"|"headgear"|"earrings"|"earring"|"eyewear"|"glasses"=>return None,
  _=>None};if first.is_none(){first=r;}
 }
 let r=if lid{Some(if corner{"eyelid_corner"}else if bottom{"eyelid_bot"}else{"eyelid_top"})}else if lip{Some(if corner{"lip_corner"}else if bottom{"lip_bot"}else{"lip_top"})}else if teeth{Some(if bottom{"teeth_bot"}else{"teeth_top"})}else if first==Some("jaw")&&top{Some("teeth_top")}else{first};r.map(|r|(r,side))
}
fn family(name:&str)->&'static str{
 let n=name.rsplit(':').next().unwrap_or(name).to_lowercase();
 if n.starts_with("cc_base_"){"cc"}else if n.starts_with("mface")||n.starts_with("mskull"){"secondlife"}
 else if !n.is_ascii(){"mmd"}
 else if n.starts_with("def-")||n.starts_with("org-")||n.contains(".t.")||n.contains(".b."){"rigify"}
 else if n.ends_with(".x")||n.ends_with(".l")||n.ends_with(".r"){"arp"}
 else if n.contains('_'){"faceit"}
 else if n.starts_with("left")||n.starts_with("right"){"mixamo"}else{"english"}
}
#[pyfunction]
#[pyo3(signature=(names,parent_idx,deform=None,head=-1))]
pub fn detect_face(names:Vec<String>,parent_idx:Vec<i64>,deform:Option<Vec<bool>>,head:i64)->PyResult<(Vec<(usize,String,String)>,String)>{
 let n=names.len();if n>100000||parent_idx.len()!=n||deform.as_ref().is_some_and(|x|x.len()!=n)||parent_idx.iter().any(|&x|x>=n as i64){return Err(PyValueError::new_err("invalid face skeleton"));}
 let parsed:Vec<_>=names.iter().map(|x|tokens(x)).collect();let mut rows=Vec::new();let mut counts=std::collections::BTreeMap::<&str,usize>::new();
 for i in 0..n{if deform.as_ref().is_some_and(|x|!x[i]){continue;}
  if head>=0{if i as i64==head{continue;}let mut p=parent_idx[i];let mut allowed=false;for _ in 0..n{if p<0{break;}if p==head||parsed[p as usize].iter().any(|s|matches!(s.as_str(),"head"|"face"|"facial"|"skull"|"頭")){allowed=true;break;}p=parent_idx[p as usize];}if !allowed{continue;}}
  if let Some((r,side))=role(&parsed[i]){rows.push((i,r.into(),side.into()));*counts.entry(family(&names[i])).or_default()+=1;}
 }
 // Native resolves equal vote totals by shortest family string, then hash-table
 // order. Equal-length ties are deliberately rejected instead of inventing parity.
 let best=counts.values().copied().max().unwrap_or(0);let len=counts.iter().filter(|(_,v)|**v==best).map(|(k,_)|k.len()).min().unwrap_or(0);
 let winners:Vec<_>=counts.iter().filter(|(k,v)|**v==best&&k.len()==len).map(|(k,_)|*k).collect();
 if winners.len()>1{return Err(PyValueError::new_err("ambiguous native family tie remains unqualified"));}
 Ok((rows,winners.first().unwrap_or(&"").to_string()))
}
