//! One private ordered diffusion row, reconstructed from the qualified Python
//! table algorithm. No entropy acquisition, shared cache or GIL release.
use pyo3::{prelude::*,types::PyList,exceptions::PyValueError};
use std::{collections::HashMap,hash::BuildHasherDefault};
type IntMap<V> = HashMap<i32,V,BuildHasherDefault<rustc_hash::FxHasher>>;
type Slot=Option<(i32,f32)>;
struct Table {slots:Vec<Slot>,hashes:IntMap<u64>,count:usize,k0:u64,k1:u64}
impl Table {
 fn resize(&mut self,size:usize){
  let old=std::mem::replace(&mut self.slots,vec![None;size]);self.count=0;
  for (b,w) in old.into_iter().flatten(){self.set(b,w);}
 }
 fn set(&mut self,b:i32,value:f32){
  if self.slots.is_empty(){self.resize(4);}
  let size=self.slots.len();let mask=size-1;
  let hashed=*self.hashes.entry(b).or_insert_with(||crate::weight_hash::weight_hash_u32(b as u32,self.k0,self.k1));
  let mut start=(hashed as usize)&mask;let mut step=0usize;
  let free=loop {
   let mut free=None;
   for j in 0..size.min(8){let i=(start+j)&mask;
    if let Some((id,_))=self.slots[i]{if id==b{self.slots[i]=Some((b,value));return;}}
    else if free.is_none(){free=Some(i);}
   }
   if let Some(i)=free{break i;}
   step+=8;start=(start+step)&mask;
  };
  let capacity=if size<8{size-1}else{size*7/8};
  if self.count>=capacity{self.resize(size*2);self.set(b,value);return;}
  self.slots[free]=Some((b,value));self.count+=1;
 }
}
fn row<'py>(rows:&Bound<'py,PyList>,index:usize)->PyResult<Bound<'py,PyList>>{
 // Borrow the existing Python slot list; don't flatten or clone the graph.
 Ok(rows.get_item(index)?.getattr("slots")?.downcast_into::<PyList>()?)
}
#[pyfunction]
pub fn weight_diffuse_row(rows:&Bound<'_,PyList>,near:&Bound<'_,PyList>,index:usize,factor:f32,k0:u64,k1:u64)->PyResult<(Vec<Slot>,IntMap<u64>)>{
 if near.is_empty(){return Err(PyValueError::new_err("diffusion row needs neighbors"));}
 let mut table=Table{slots:Vec::new(),hashes:IntMap::default(),count:0,k0,k1};
 let mut values=IntMap::<f32>::default();
 for entry in row(rows,index)?.iter(){
  if entry.is_none(){continue;}let (b,v)=entry.extract::<(i32,f32)>()?;
  if b<0{return Err(PyValueError::new_err("diffusion row has negative bone"));}
  let value=(1.0f32-factor)*v;values.insert(b,value);table.set(b,value);
 }
 let inv=1.0f32/(near.len() as f32);
 for j in near.iter(){
  let j=j.extract::<usize>()?;
  for entry in row(rows,j)?.iter(){
   if entry.is_none(){continue;}let (b,v)=entry.extract::<(i32,f32)>()?;
   if b<0{return Err(PyValueError::new_err("diffusion row has negative bone"));}
   let contribution=inv*(factor*v);
   let first=!values.contains_key(&b);let value=values.get(&b).copied().unwrap_or(0.0)+contribution;
   values.insert(b,value);if first{table.set(b,value);}
  }
 }
 for slot in &mut table.slots {
  if let Some((b,_))=*slot{let value=values[&b];*slot=if value>0.0{Some((b,value))}else{None};}
 }
 table.hashes.retain(|b,_|values[b]>0.0);
 Ok((table.slots,table.hashes))
}

/// Ordered initial table, without Python scalar extraction or repeated probes.
/// Each call receives one row and the already-acquired Python random-state keys.
#[pyfunction]
pub fn weight_initial_row(weights:numpy::PyReadonlyArray1<'_,f32>,bones:numpy::PyReadonlyArray1<'_,i32>,k0:u64,k1:u64)->PyResult<(Vec<Slot>,IntMap<u64>)>{
 let w=crate::array_input::one(&weights);let b=crate::array_input::one(&bones);
 if w.len()!=b.len(){return Err(PyValueError::new_err("initial weight row shape mismatch"));}
 let mut table=Table{slots:Vec::new(),hashes:IntMap::default(),count:0,k0,k1};
 let mut values=IntMap::<f32>::default();
 for (&v,&id) in w.iter().zip(b.iter()) {
  if id>=0 && v>0.0 {
   let value=values.get(&id).copied().unwrap_or(0.0)+v;
   values.insert(id,value);table.set(id,value);
  }
 }
 Ok((table.slots,table.hashes))
}
