//! Owned cage skinning recovered from 0x2ef0, 0x61acc, 0x145d88 and 0x146070.
//! No dual-quaternion / Preserve Volume deformation and no oracle dependency.
use crate::array_input::{one,two};
use numpy::{PyArray2, PyArrayMethods, PyUntypedArrayMethods, PyReadonlyArray1, PyReadonlyArray2};
use pyo3::{exceptions::PyValueError, panic::PanicException, prelude::*};
use std::collections::HashMap;
fn err(s: impl Into<String>) -> PyErr { PyValueError::new_err(s.into()) }
type Mat = [[f64;4];4];
fn identity()->Mat { let mut a=[[0.;4];4];for i in 0..4 {a[i][i]=1.;}a }
fn inverse(mut a:Mat)->Mat {
 let mut b=identity();
 for i in 0..4 {
  let mut pivot=i;
  for j in i+1..4 {if a[pivot][i].abs().to_bits()<=a[j][i].abs().to_bits(){pivot=j;}}
  if a[pivot][i]==0. {return identity();}
  a.swap(i,pivot);b.swap(i,pivot);let d=a[i][i];
  for k in 0..4 {a[i][k]/=d;b[i][k]/=d;}
  for j in 0..4 {if j!=i {let f=a[j][i];if f!=0. {for k in 0..4 {a[j][k]-=a[i][k]*f;b[j][k]-=b[i][k]*f;}}}}
 }
 b
}
fn mul(a:&Mat,b:&Mat)->Mat {
 let mut c=[[0.;4];4];
 for i in 0..4 {for j in 0..4 {for k in 0..4 {c[i][j]+=b[k][j]*a[i][k];}}}c
}
fn world(a:PyReadonlyArray2<'_,f64>,name:&str)->PyResult<Mat>{
 let a=two(&a);if a.shape()!=[4,4] {return Err(err(format!("{} must be (4, 4)",name)));}
 let mut out=[[0.;4];4];for i in 0..4 {for j in 0..4 {out[i][j]=a[[i,j]];}}Ok(out)
}
#[pyclass(module="_bvt_solver")]
pub struct CageBinding {
 rest:Vec<[f32;3]>, rows:Vec<Vec<(usize,f64)>>, sums:Vec<f64>,
 pose_indices:Vec<usize>, rest_indices:Vec<usize>, edges:Py<PyArray2<i32>>,
}
#[pymethods]
impl CageBinding {
 #[new]
 fn new(rest:PyReadonlyArray2<'_,f32>,edges:Bound<'_,PyArray2<i32>>,counts:PyReadonlyArray1<'_,i64>,groups:PyReadonlyArray1<'_,i32>,weights:PyReadonlyArray1<'_,f32>,group_names:Vec<String>,pose_names:Vec<String>,bone_names:Vec<String>,bone_deform:PyReadonlyArray1<'_,bool>)->PyResult<Self>{
  if edges.shape()[1]!=2{return Err(err("edges must be (E, 2)"));}
  let rest=two(&rest);if rest.ncols()!=3{return Err(err(format!("rest must be (N, 3), got {:?}",rest.shape())));}
  let counts=one(&counts);let groups=one(&groups);let weights=one(&weights);let deform=one(&bone_deform);
  if counts.len()!=rest.nrows(){return Err(err("counts must have one entry per rest vertex"));}
  if deform.len()!=bone_names.len(){return Err(err("bone_deform must have one entry per bone"));}
  if groups.len()!=weights.len(){return Err(err("groups and weights must share length"));}
  let count=counts.iter().try_fold(0usize,|s,&n|if n<0 {None}else{Some(s.wrapping_add(n as usize))});
  if count!=Some(groups.len()){return Err(err("counts must be non-negative and sum to len(groups)"));}
  if counts.iter().any(|&n|n as usize>groups.len()){
   return Err(PanicException::new_err(format!("index out of bounds: the len is {} but the index is {}",groups.len(),groups.len())));
  }
  let bones:HashMap<_,_>=bone_names.iter().enumerate().map(|(i,n)|(n.as_str(),i)).collect();
  let mut compact=HashMap::new();let mut pose_indices=Vec::new();let mut rest_indices=Vec::new();
  for (i,name) in pose_names.iter().enumerate(){if let Some(&j)=bones.get(name.as_str()){if deform.get(j).copied().unwrap_or(false){compact.insert(name.as_str(),pose_indices.len());pose_indices.push(i);rest_indices.push(j);}}}
  let mut rows=Vec::with_capacity(rest.nrows());let mut sums=Vec::with_capacity(rest.nrows());let mut offset=0;
  for &n in counts.iter() {
   let mut row:Vec<(usize,f32)>=Vec::new();
   for j in offset..offset+n as usize {let k=groups[j];if k>=0 && (k as usize)<group_names.len(){let k=k as usize;if let Some((_,w))=row.iter_mut().find(|(g,_)|*g==k){*w=weights[j]+*w;}else{row.push((k,weights[j]));}}}
   let mut out=Vec::new();let mut sum=0.;
   for (g,w) in row {if let Some(&k)=compact.get(group_names[g].as_str()){out.push((k,w as f64));sum+=w as f64;}}
   rows.push(out);sums.push(sum);offset+=n as usize;
  }
  Ok(Self{rest:rest.rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect(),rows,sums,pose_indices,rest_indices,edges:edges.unbind()})
 }
 #[getter] fn n(&self)->usize{self.rest.len()}
 #[getter] fn edges(&self,py:Python<'_>)->Py<PyArray2<i32>>{self.edges.clone_ref(py)}
 #[pyo3(signature=(mesh_world,arm_world,pose_mats,rest_mats,out=None))]
 fn pose<'py>(&self,py:Python<'py>,mesh_world:PyReadonlyArray2<'py,f64>,arm_world:PyReadonlyArray2<'py,f64>,pose_mats:PyReadonlyArray1<'py,f32>,rest_mats:PyReadonlyArray1<'py,f32>,out:Option<Bound<'py,PyArray2<f32>>>)->PyResult<Bound<'py,PyArray2<f32>>>{
  let mesh=world(mesh_world,"mesh_world")?;let arm=world(arm_world,"arm_world")?;
  if !pose_mats.is_contiguous() || !rest_mats.is_contiguous(){return Err(numpy::NotContiguousError.into());}
  let pose_values=one(&pose_mats);let rest_values=one(&rest_mats);
  let pose=pose_values.as_slice().ok_or(numpy::NotContiguousError)?;let rest=rest_values.as_slice().ok_or(numpy::NotContiguousError)?;
  if self.pose_indices.iter().any(|&i|(i+1)*16>pose.len()) || self.rest_indices.iter().any(|&i|(i+1)*16>rest.len()) {return Err(err("pose_mats / rest_mats miss a bone the binding uses"));}
  let out=out.unwrap_or_else(||PyArray2::zeros(py,[self.rest.len(),3],false));
  {let mut writer=out.try_readwrite().map_err(|e|PanicException::new_err(format!("called `Result::unwrap()` on an `Err` value: {:?}",e)))?;let shape=out.shape().to_vec();if shape!=[self.rest.len(),3]{return Err(err(format!("out must be ({}, 3)",self.rest.len())));}
   if !out.is_contiguous(){return Err(numpy::NotContiguousError.into());}
   let unaligned=(out.data() as usize)%std::mem::align_of::<f32>()!=0;
   let mut scratch=if unaligned {vec![0.0;self.rest.len()*3]} else {Vec::new()};
   let target=if unaligned {scratch.as_mut_slice()} else {writer.as_slice_mut()?};
   py.allow_threads(||{
    let left=mul(&inverse(mesh),&arm);let right=mul(&inverse(arm),&mesh);
    let mut transforms=Vec::new();
    for (&pi,&ri) in self.pose_indices.iter().zip(&self.rest_indices){
     let mut p=[[0.;4];4];let mut r=[[0.;4];4];
     for i in 0..4{for j in 0..4 {p[i][j]=pose[pi*16+j*4+i] as f64;r[i][j]=rest[ri*16+j*4+i] as f64;}}
     transforms.push(mul(&mul(&left,&mul(&p,&inverse(r))),&right));
    }
    for (v,point) in self.rest.iter().enumerate(){
     if self.rows[v].is_empty() || self.sums[v]<=1e-9 {target[v*3..v*3+3].copy_from_slice(point);continue;}
     let mut sum=[0.;3];for &(k,w) in &self.rows[v]{for i in 0..3 {let m=&transforms[k][i];sum[i]+=w*(m[3]+((m[0]*point[0] as f64+m[1]*point[1] as f64)+m[2]*point[2] as f64));}}
     for i in 0..3{target[v*3+i]=(sum[i]/self.sums[v]) as f32;}
    }
   });
   if unaligned {
    // Exclusive NumPy guard remains alive; copy into the original output buffer
    // without constructing an unaligned &mut [f32].
    for (i,value) in scratch.iter().enumerate(){unsafe{out.data().cast::<u8>().add(i*4).cast::<f32>().write_unaligned(*value);}}
   }
  }
  Ok(out)
 }
}
