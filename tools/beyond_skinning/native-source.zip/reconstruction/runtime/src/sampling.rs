//! Recovered vertex-to-cloud samples (0x5d370), occupancy and group culling.
use crate::occupancy_variants::{self,LevelInput,Level};
use rayon::prelude::*;
use numpy::{PyArray2,PyReadonlyArray1,PyReadonlyArray2};
use ndarray::ArrayView2;
use pyo3::{prelude::*,exceptions::PyValueError};
fn kernel_weight(distance:f32,last:f32,kernel:u8,radius:Option<f32>)->f32{
 let raw=distance/last;let a=if raw<0.0{0.0}else{raw};let t=if a<=1.0{a}else{1.0};
 let mut w=match kernel{
  0=>1.0/if 1e-8<distance{distance}else{1e-8},
  1=>(1.0-t)*(1.0-t)*((t*3.0)*(t*3.0*-0.5)).exp()+0.001,
  2=>1.0-t*t*(3.0-(t+t))+0.001,
  _=>{let a=1.0-t;(t*4.0+1.0)*(a*(a*(a*a)))+0.001}
 };
 if let Some(r)=radius{w=r*(r*(w*r));}w
}
#[pyfunction]
#[pyo3(signature=(queries,points,radii,rows,columns,origin,dimensions,cell,k,kernel,volume,search_radius,occupancy=None,query_groups=None,point_groups=None,bypass=None,allow_nonfinite_queries=false,requested_k=None,array_output=false,cell_coordinates=None,prepared_occupancy=None))]
pub fn sample_from_grid(py:Python<'_>,queries:PyReadonlyArray2<'_,f32>,points:PyReadonlyArray2<'_,f32>,radii:PyReadonlyArray1<'_,f32>,rows:PyReadonlyArray1<'_,u32>,columns:PyReadonlyArray1<'_,u32>,origin:[f32;3],dimensions:[u32;3],cell:f32,k:usize,kernel:u8,volume:bool,search_radius:f32,occupancy:Option<Vec<LevelInput>>,query_groups:Option<Vec<i32>>,point_groups:Option<Vec<i32>>,bypass:Option<Vec<bool>>,allow_nonfinite_queries:bool,requested_k:Option<usize>,array_output:bool,cell_coordinates:Option<PyReadonlyArray2<'_,u32>>,prepared_occupancy:Option<PyRef<'_,occupancy_variants::_PreparedOccupancy>>)->PyResult<PyObject>{
 let coordinates=cell_coordinates.as_ref().map(|a|a.as_array());
 sample_grid_impl(py,queries.as_array(),points.as_array(),radii.as_array(),rows.as_slice()?,columns.as_slice()?,origin,dimensions,cell,k,kernel,volume,search_radius,occupancy,query_groups,point_groups,bypass,allow_nonfinite_queries,requested_k,array_output,coordinates,prepared_occupancy,false)
}
fn sample_grid_impl(py:Python<'_>,q:ArrayView2<'_,f32>,p:ArrayView2<'_,f32>,r:ndarray::ArrayView1<'_,f32>,rows:&[u32],columns:&[u32],origin:[f32;3],dimensions:[u32;3],cell:f32,k:usize,kernel:u8,volume:bool,search_radius:f32,occupancy:Option<Vec<LevelInput>>,query_groups:Option<Vec<i32>>,point_groups:Option<Vec<i32>>,bypass:Option<Vec<bool>>,allow_nonfinite_queries:bool,requested_k:Option<usize>,array_output:bool,coordinates:Option<ArrayView2<'_,u32>>,prepared_occupancy:Option<PyRef<'_,occupancy_variants::_PreparedOccupancy>>,validated_grid:bool)->PyResult<PyObject>{
 // Public coarse sampling accumulates candidates directly (native 0x681c0).
 // A compact map may own fewer slots than requested, but search thresholds
 // still use the full usize request, including release-mode wrapping * 3.
 let selection_k=requested_k.unwrap_or(k);
 if requested_k.is_some() && (k>selection_k || k>p.nrows()){return Err(PyValueError::new_err("invalid compact sample width"));}

 let coordinate_slice=coordinates.as_ref().map(|a|a.as_slice().ok_or_else(||PyValueError::new_err("invalid sparse sampling coordinates"))).transpose()?;
 if !validated_grid {if let Some(ref a)=coordinates {
  if a.ncols()!=3 || a.nrows().checked_add(1)!=Some(rows.len()) ||
     a.outer_iter().any(|v|v[0]>=dimensions[2] || v[1]>=dimensions[1] || v[2]>=dimensions[0]) ||
     coordinate_slice.unwrap().chunks_exact(3).zip(coordinate_slice.unwrap().chunks_exact(3).skip(1)).any(|(a,b)|a>=b) {
   return Err(PyValueError::new_err("invalid sparse sampling coordinates"));
  }
 }
 }
 let cells=dimensions.iter().try_fold(1usize,|a,&b|a.checked_mul(b as usize));
 if q.ncols()!=3 || k==0 || (!array_output && q.nrows().checked_mul(k).is_none_or(|n|n>8_388_608)) || kernel>3 || (!allow_nonfinite_queries && q.iter().any(|x|!x.is_finite())) || !(search_radius>0.0 && search_radius.is_finite()) || (!validated_grid && (p.ncols()!=3 || p.nrows()!=r.len() || dimensions.contains(&0) || (coordinates.is_none() && cells.is_none_or(|n|n.checked_add(1)!=Some(rows.len()))) || rows.first()!=Some(&0) || rows.last().copied()!=Some(columns.len() as u32) || rows.windows(2).any(|x|x[0]>x[1]) || columns.iter().any(|&x|x as usize>=p.nrows()) || p.iter().chain(origin.iter()).any(|x|!x.is_finite()) || r.iter().any(|&x|!x.is_finite() || x<=0.0) || !(cell>0.0 && cell.is_finite()))) {return Err(PyValueError::new_err("invalid research sampling grid"));}
 if query_groups.as_ref().is_some_and(|g|g.len()!=q.nrows()) || point_groups.as_ref().is_some_and(|g|g.len()!=p.nrows()) || bypass.as_ref().is_some_and(|g|g.len()!=q.nrows()){return Err(PyValueError::new_err("invalid sampling group lengths"));}
 if occupancy.is_some() && prepared_occupancy.is_some(){return Err(PyValueError::new_err("provide occupancy or prepared occupancy, not both"));}
 let prepared=prepared_occupancy.map(|p|p.levels.clone());
 let owned=occupancy.map(occupancy_variants::prepare).transpose()?;
 let occupancy=prepared.as_deref().or(owned.as_ref());
 let shape = (q.nrows(), k);
 let count=crate::compact_fields::allocation_len(q.nrows(),k,std::mem::size_of::<f32>())?;
 let mut all_ids = vec![u32::MAX; count];
 let mut all_weights = vec![0.0f32; count];
 let inverse=1.0/cell;
 let packed_points=p.as_slice();
 py.allow_threads(|| {
 let sample_row=|(qi,(ids,weights)):(usize,(&mut [u32],&mut [f32])), candidates:&mut Vec<(f32,u32)>| {
  let query=q.row(qi);
  // Nonfinite mesh vertices have no valid geometric sample. Preserve empty
  // slots so the ordinary final orphan pass chooses the donor through edges.
  if query.iter().any(|x|!x.is_finite()) {
   return;
  }
  let group=query_groups.as_ref().map_or(-1,|g|g[qi]);
  let use_occupancy=occupancy.is_some() && !bypass.as_ref().is_some_and(|v|v[qi]);
  let wanted=if use_occupancy{selection_k.wrapping_mul(3)}else{selection_k};
  let mut radius=search_radius;
  candidates.clear();
  let mut previous:Option<([u32;3],[u32;3])>=None;
  for attempt in 0..6 {
   if coordinate_slice.is_some(){candidates.clear();}
   let low=std::array::from_fn::<_,3,_>(|a|((inverse*((query[a]-origin[a])-radius)) as i32).clamp(0,dimensions[a] as i32-1) as u32);
   let high=std::array::from_fn::<_,3,_>(|a|((inverse*(radius+(query[a]-origin[a]))) as i32).clamp(0,dimensions[a] as i32-1) as u32);
   let mut append = |range:std::ops::Range<usize>| {
    let entries=&columns[range];
    if group<0 {
     if let Some(points)=packed_points {
      let mut chunks=entries.chunks_exact(4);
      for ids in &mut chunks {
       let xyz: [[f32;4];3]=std::array::from_fn(|a|std::array::from_fn(|j|points[ids[j] as usize*3+a]));
       let distances=distance4([query[0],query[1],query[2]],xyz);
       for j in 0..4 {candidates.push((distances[j],ids[j]));}
      }
      for &id in chunks.remainder() {
       let i=id as usize*3;let d=[query[0]-points[i],query[1]-points[i+1],query[2]-points[i+2]];
       candidates.push((((d[0]*d[0]+d[1]*d[1])+d[2]*d[2]).sqrt(),id));
      }
      return;
     }
    }
    for &id in entries {
     let i=id as usize;
     if group>=0 && point_groups.as_ref().is_some_and(|g|g[i]>=0 && g[i]!=group) {continue;}
     let d=std::array::from_fn::<_,3,_>(|a|query[a]-p[[i,a]]);
     candidates.push((((d[0]*d[0]+d[1]*d[1])+d[2]*d[2]).sqrt(),id));
    }
   };
   if let Some(keys)=coordinate_slice {
    // Sparse keys are sorted z/y/x. Empty address ranges require no storage
    // or iteration, while candidate encounter order matches dense rows.
    // Search occupied z/y ranges before visiting x cells. The former z-only
    // scan walked every x/y cell in the slab for every query. Keep exactly the
    // same lexicographic encounter order, with no additional query scratch.
    let lower = |mut begin:usize,mut end:usize,wanted:[u32;3]| {
     while begin<end {let mid=begin+(end-begin)/2;
      let key=[keys[mid*3],keys[mid*3+1],keys[mid*3+2]];
      if key<wanted {begin=mid+1;}else{end=mid;}
     }begin
    };
    let count=keys.len()/3;
    let mut zi=lower(0,count,[low[2],0,0]);
    while zi<count {
     let z=keys[zi*3];if z>high[2]{break;}
     let ze=lower(zi,count,[z+1,0,0]);
     let mut yi=lower(zi,ze,[z,low[1],0]);
     while yi<ze {
      let y=keys[yi*3+1];if y>high[1]{break;}
      let ye=lower(yi,ze,[z,y+1,0]);
      let left=lower(yi,ye,[z,y,low[0]]);
      let right=lower(left,ye,[z,y,high[0]+1]);
      if left<right {append(rows[left] as usize..rows[right] as usize);}
      yi=ye;
     }
     zi=ze;
    }
   } else {
    for z in low[2]..=high[2] {for y in low[1]..=high[1] {
     let begin=((y as usize+z as usize*dimensions[1] as usize)*dimensions[0] as usize)+low[0] as usize;
     let end=begin+(high[0]-low[0]) as usize+1;
     if let Some((old_low,old_high))=previous {
      if z>=old_low[2] && z<=old_high[2] && y>=old_low[1] && y<=old_high[1] {
       // Expanded dense boxes retain already measured candidates. Visit only
       // the new x strips for old rows; new y/z rows still visit their full
       // range. Final selection sorts distance/index keys, so encounter order
       // is immaterial, including duplicate IDs with identical payload.
       let base=begin-low[0] as usize;
       if low[0]<old_low[0]{append(rows[begin] as usize..rows[base+old_low[0] as usize] as usize);}
       if high[0]>old_high[0]{append(rows[base+old_high[0] as usize+1] as usize..rows[end] as usize);}
       continue;
      }
     }
     append(rows[begin] as usize..rows[end] as usize);
    }}
   }
   if candidates.len()>=wanted || attempt==5 {break;}
   previous=Some((low,high));radius+=radius;
  }
  // Original compares nonnegative distance bits then source index, not encounter order.
  if use_occupancy {select_in_place(candidates,[query[0],query[1],query[2]],p,occupancy.as_ref().unwrap(),selection_k,true);}
  else {sort_prefix(candidates,selection_k);candidates.truncate(selection_k);}
  if let Some(&(last,_))=candidates.last(){
   let last=if 1e-8<last{last}else{1e-8};
   // Raw weights already have a final output slot. Preserve the original
   // sequential f32 sum, then normalize only the populated prefix in place.
   for (j,&(d,i)) in candidates.iter().enumerate(){ids[j]=i;weights[j]=kernel_weight(d,last,kernel,if volume{Some(r[i as usize])}else{None});}
   let sum=weights[..candidates.len()].iter().fold(0.0f32,|a,&b|a+b);let inverse=1.0/if 1e-20<sum{sum}else{1e-20};
   for w in &mut weights[..candidates.len()]{*w=inverse*(*w);}
  }

 };
 if q.nrows()>=256 {
  // At most four candidate buffers are live, even on large Rayon pools.
  // Keep their worst-case growth inside the per-point resource reserve.
  // Distribute small adjacent-row tiles round-robin across exactly four tasks.
  // Output slices are disjoint; each row still sees the same candidate order.
  // Four reusable candidate buffers remain the hard concurrency ceiling.
  let mut tasks:[Vec<_>;4]=std::array::from_fn(|_|Vec::new());
  let tile_rows=64usize;
  for (tile,(ids,weights)) in all_ids.chunks_mut(k*tile_rows).zip(all_weights.chunks_mut(k*tile_rows)).enumerate() {
   tasks[tile%4].push((tile*tile_rows,ids,weights));
  }
  tasks.into_par_iter().for_each(|tiles| {
   let mut candidates=Vec::new();
   for (begin,ids,weights) in tiles {
    for (offset,pair) in ids.chunks_mut(k).zip(weights.chunks_mut(k)).enumerate() {
     sample_row((begin+offset,pair),&mut candidates);
    }
   }
  });
 } else {
  let mut candidates=Vec::new();
  for pair in all_ids.chunks_mut(k).zip(all_weights.chunks_mut(k)).enumerate(){sample_row(pair,&mut candidates);}
 }
 });

 if array_output {
     let ids = ndarray::Array2::from_shape_vec(shape, all_ids)
         .map_err(|e| PyValueError::new_err(e.to_string()))?;
     let weights = ndarray::Array2::from_shape_vec(shape, all_weights)
         .map_err(|e| PyValueError::new_err(e.to_string()))?;
     return Ok((PyArray2::from_owned_array(py, ids), PyArray2::from_owned_array(py, weights))
         .into_pyobject(py)?.into_any().unbind());
 }
 let ids: Vec<_> = all_ids.chunks_exact(k).collect();
 let weights: Vec<_> = all_weights.chunks_exact(k).collect();
 Ok((ids, weights).into_pyobject(py)?.into_any().unbind())
}

/// Sample-order f32 dense field accumulation from the recovered stencil.
#[pyfunction]
pub fn accumulate_sample_fields(ids:PyReadonlyArray2<'_,u32>,weights:PyReadonlyArray2<'_,f32>,fields:PyReadonlyArray2<'_,f32>)->PyResult<Vec<Vec<f32>>>{
 let ids=ids.as_array();let w=weights.as_array();let field=fields.as_array();
 if ids.shape()!=w.shape() || ids.iter().any(|&i|i!=u32::MAX && i as usize>=field.nrows()) || w.iter().chain(field.iter()).any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid sampled field inputs"));}
 let mut output=vec![vec![0.0;field.ncols()];ids.nrows()];
 // Use contiguous bone lanes for the ordinary field. LLVM can vectorize
 // across bones while each bone still accumulates neighbors in source order.
 if let Some(values) = field.as_slice() {
     let width = field.ncols();
     for (row, result) in output.iter_mut().enumerate() {
         for (&id, &weight) in ids.row(row).iter().zip(w.row(row).iter()) {
             if id == u32::MAX { continue; }
             let start = (id as usize) * width;
             for (dest, &value) in result.iter_mut().zip(&values[start..start + width]) {
                 *dest += weight * value;
             }
         }
     }
 } else {
     // Array views with strides keep their logical index order.
 for row in 0..ids.nrows(){for j in 0..ids.ncols(){let i=ids[[row,j]];if i==u32::MAX{continue;}for b in 0..field.ncols(){output[row][b]=output[row][b]+w[[row,j]]*field[[i as usize,b]];}}}
 }
 Ok(output)
}
/// Original bleed attenuation, stable top-k insertion and sequential normalization.
#[pyfunction]
#[pyo3(signature=(values,k,bleed,allow_nonfinite_values=false))]
pub fn reduce_top_weights(values:Vec<f32>,k:usize,bleed:f32,allow_nonfinite_values:bool)->PyResult<(Vec<i32>,Vec<f32>)>{
 if k>32 || !bleed.is_finite() || (!allow_nonfinite_values && values.iter().any(|x|!x.is_finite())){return Err(PyValueError::new_err("invalid top weight inputs"));}
 let mut adjusted=values.clone();if bleed>0.0{
  let start=bleed*0.5;let width=bleed*1.5;
  for w in &mut adjusted{let raw=(*w-start)/width;let lo=if raw<0.0{0.0}else{raw};let t=if lo<=1.0{lo}else{1.0};*w=*w*(t*t*(3.0-(t+t)));}
  if adjusted.iter().all(|&x|x<=0.0){adjusted=values;}
 }
 let count=(k+1).min(adjusted.len());let mut best=vec![f32::NEG_INFINITY;count];let mut ids=vec![-1i32;count];
 for (i,&w) in adjusted.iter().enumerate(){if count==0{break;}if w<=best[count-1]{continue;}let mut at=count-1;while at>0 && best[at-1]<w{best[at]=best[at-1];ids[at]=ids[at-1];at-=1;}best[at]=w;ids[at]=i as i32;}
 let mut out=vec![0.0;k];let mut out_ids=vec![-1;k];for i in 0..k.min(adjusted.len()){out_ids[i]=ids[i];out[i]=if best[i]>0.0{best[i]}else{0.0};}
 let sum=out.iter().fold(0.0f32,|a,&b|a+b);let denom=if sum>1e-8{sum}else{1e-8};for v in &mut out{*v=*v/denom;}Ok((out_ids,out))
}

/// Three-probe visibility filter; dense, sparse and implicit-dilation variants.
#[pyfunction]
pub fn select_sample_candidates(distances:Vec<f32>,indices:Vec<u32>,query:[f32;3],points:PyReadonlyArray2<'_,f32>,levels:Vec<LevelInput>,k:usize)->PyResult<(Vec<u32>,Vec<f32>)>{
 let p=points.as_array();
 if p.ncols()!=3 || distances.len()!=indices.len() || distances.iter().any(|&x|!x.is_finite() || x<0.0) || indices.iter().any(|&i|i as usize>=p.nrows()) || query.iter().chain(p.iter()).any(|x|!x.is_finite()) || k==0 || k>512{return Err(PyValueError::new_err("invalid sample candidates"));}
 let levels=occupancy_variants::prepare(levels)?;
 Ok(select_owned(distances.into_iter().zip(indices).collect(),query,p,&levels,k))
}
fn select_owned(mut candidates:Vec<(f32,u32)>,query:[f32;3],p:ArrayView2<'_,f32>,levels:&[Level],k:usize)->(Vec<u32>,Vec<f32>){
 select_in_place(&mut candidates,query,p,levels,k,false);
 candidates.into_iter().map(|(distance,index)|(index,distance)).unzip()
}
// Selection needs no second pair of growing vectors or recombined candidate
// buffer. Writes only reach the already-read prefix. The closest original
// candidate (j == 0), not the first surviving candidate, bypasses occlusion.
// Exact prefix selection: order is still distance bits then source index.
// Equal keys have identical payload, including duplicate sample IDs.
fn sort_prefix(candidates:&mut [(f32,u32)],count:usize){
 let count=count.min(candidates.len());
 if count<candidates.len(){candidates.select_nth_unstable_by_key(count,|&(d,i)|(d.to_bits(),i));}
 candidates[..count].sort_unstable_by_key(|&(d,i)|(d.to_bits(),i));
}
fn select_in_place(candidates:&mut Vec<(f32,u32)>,query:[f32;3],p:ArrayView2<'_,f32>,levels:&[Level],k:usize,measured_distances:bool){
 let prefix=k.saturating_mul(3).max(32).min(candidates.len());
 sort_prefix(candidates,prefix);let mut accepted=0;
 'candidate:for j in 0..candidates.len(){
  if accepted==k{break;}
  // Heavy occlusion may need the remainder; sort it once, only if reached.
  if j==prefix{candidates[prefix..].sort_unstable_by_key(|&(d,i)|(d.to_bits(),i));}
  let (distance,index)=candidates[j];
  if j!=0 {
   let delta=std::array::from_fn::<_,3,_>(|a|p[[index as usize,a]]-query[a]);let length=if measured_distances {distance}else{((delta[0]*delta[0]+delta[1]*delta[1])+delta[2]*delta[2]).sqrt()};
   for t in [0.5f32,0.3,0.7]{let probe=std::array::from_fn::<_,3,_>(|a|query[a]+delta[a]*t);let mut solid=false;
    for level in levels {if level.cell>length{continue;}
     let xyz=std::array::from_fn(|a|floor_i32((probe[a]-level.origin[a])*level.inverse));
     if level.solid(xyz){solid=true;break;}
     if level.dilated(xyz){continue 'candidate;}
    }
    // All non-skipped levels already returned false above. Only coarse
    // levels skipped by the length test can supply the fallback solid hit.
    if !solid {solid=levels.iter().filter(|level|level.cell>length).any(|level|level.solid(std::array::from_fn(|a|floor_i32((probe[a]-level.origin[a])*level.inverse))));}
    if !solid{continue 'candidate;}
   }
  }
  candidates[accepted]=(distance,index);accepted+=1;
 }
 candidates.truncate(accepted);
}

/// Sparse point fields to dense sampled rows (0x678a0). Slots stop at the first
/// u16::MAX; zero-weight samples do not dereference their point index.
#[pyfunction]
pub fn accumulate_sparse_sample_fields(ids:PyReadonlyArray2<'_,u32>,weights:PyReadonlyArray2<'_,f32>,slots:PyReadonlyArray2<'_,u16>,fields:PyReadonlyArray2<'_,f32>,bone_count:usize)->PyResult<Vec<Vec<f32>>>{
 let ids=ids.as_array();let w=weights.as_array();let slots=slots.as_array();let fields=fields.as_array();
 if ids.shape()!=w.shape() || slots.shape()!=fields.shape() || bone_count>65535 || ids.nrows().saturating_mul(bone_count)>16_000_000 || w.iter().chain(fields.iter()).any(|v|!v.is_finite()) {return Err(PyValueError::new_err("invalid sparse sample field shape"));}
 for row in slots.rows(){for &bone in row{if bone==u16::MAX{break;}if bone as usize>=bone_count{return Err(PyValueError::new_err("sparse sample bone is out of range"));}}}
 let mut result=vec![vec![0.0f32;bone_count];ids.nrows()];
 for i in 0..ids.nrows(){for j in 0..ids.ncols(){let weight=w[[i,j]];if weight==0.0{continue;}let point=ids[[i,j]] as usize;if point>=slots.nrows(){return Err(PyValueError::new_err("sparse sample point is out of range"));}
  for s in 0..slots.ncols(){let bone=slots[[point,s]];if bone==u16::MAX{break;}result[i][bone as usize]=result[i][bone as usize]+weight*fields[[point,s]];}
 }}Ok(result)
}

/// Nearest-label graph fallback, native 0x5cb40. The unfilled output slots are
/// u32::MAX/zero; this stage intentionally does not renormalize the top four.
#[pyfunction]
pub fn fallback_label_samples(queries:Vec<usize>,rows:Vec<u32>,columns:Vec<u32>,weights:Vec<f32>,labels:Vec<u32>)->PyResult<(Vec<[u32;4]>,Vec<[f32;4]>)>{
 if rows.len()!=labels.len()+1 || rows.first()!=Some(&0) || rows.last().copied().unwrap_or(0) as usize!=columns.len() || columns.len()!=weights.len() || rows.windows(2).any(|x|x[0]>x[1]) || columns.iter().any(|&i|i as usize>=labels.len()) || queries.iter().any(|&i|i>=labels.len()) || weights.iter().any(|w|!w.is_finite() || *w<0.0){return Err(PyValueError::new_err("invalid fallback graph inputs"));}
 let mut ids=Vec::new();let mut values=Vec::new();
 for i in queries{
  let range=rows[i] as usize..rows[i+1] as usize;
  let sum=weights[range.clone()].iter().fold(-0.0f32,|a,&b|a+b);
  let mut pairs=vec![(labels[i],1.0f32)];
  if sum>1e-12 {for edge in range{let label=labels[columns[edge] as usize];let value=weights[edge]/sum;
   if let Some(pair)=pairs.iter_mut().find(|p|p.0==label){pair.1=pair.1+value;}else{pairs.push((label,value));}
  }}
  pairs.sort_unstable_by(|a,b|b.1.partial_cmp(&a.1).unwrap().then(a.0.cmp(&b.0)));
  let mut row=[u32::MAX;4];let mut val=[0.0f32;4];
  for (j,p) in pairs.into_iter().take(4).enumerate(){row[j]=p.0;val[j]=p.1;}
  ids.push(row);values.push(val);
 }
 Ok((ids,values))
}

/// Preserve accumulation order while avoiding per-scalar Python objects.
#[pyfunction]
pub fn accumulate_sample_array<'py>(py:Python<'py>,ids:PyReadonlyArray2<'py,u32>,weights:PyReadonlyArray2<'py,f32>,fields:PyReadonlyArray2<'py,f32>)->PyResult<Bound<'py,numpy::PyArray2<f32>>>{
 let width=fields.as_array().ncols();
 let output=accumulate_sample_fields(ids,weights,fields)?;
 crate::field_arrays::owned_rows(py,output,width)
}

/// Owned top-weight rows without Python scalar/list staging; same recovered
/// insertion and normalization order as the scalar helper. Finishing does not
/// observe cancellation in the original, so this transport adds no checkpoint.
#[pyfunction]
pub fn reduce_sample_array<'py>(py:Python<'py>,fields:PyReadonlyArray2<'py,f32>,k:usize)->PyResult<(Bound<'py,numpy::PyArray2<i32>>,Bound<'py,numpy::PyArray2<f32>>)> {
 let field=fields.as_array();let n=field.nrows();
 if k>32 || n.checked_mul(k).is_none(){return Err(PyValueError::new_err("invalid reduced sample dimensions"));}
 let (ids,weights)=py.allow_threads(||->PyResult<_>{
  let mut ids=Vec::with_capacity(n*k);let mut weights=Vec::with_capacity(n*k);
  for row in field.rows(){let (i,w)=reduce_top_weights(row.to_vec(),k,0.0,false)?;ids.extend(i);weights.extend(w);}
  Ok((ids,weights))
 })?;
 let ia=ndarray::Array2::from_shape_vec((n,k),ids).map_err(|e|PyValueError::new_err(e.to_string()))?;
 let wa=ndarray::Array2::from_shape_vec((n,k),weights).map_err(|e|PyValueError::new_err(e.to_string()))?;
 Ok((numpy::PyArray2::from_owned_array(py,ia),numpy::PyArray2::from_owned_array(py,wa)))
}

/// Validated immutable inputs for one blocked public sampling operation only.
#[pyclass(module="_bvt_solver", frozen)]
pub struct _PreparedSampleGrid {
 points:ndarray::Array2<f32>,radii:ndarray::Array1<f32>,rows:Vec<u32>,columns:Vec<u32>,
 origin:[f32;3],dimensions:[u32;3],cell:f32,coordinates:Option<ndarray::Array2<u32>>,
}
#[pymethods]
impl _PreparedSampleGrid {
 #[new]
 #[pyo3(signature=(points,radii,rows,columns,origin,dimensions,cell,cell_coordinates=None))]
 fn new(py:Python<'_>,points:PyReadonlyArray2<'_,f32>,radii:PyReadonlyArray1<'_,f32>,rows:PyReadonlyArray1<'_,u32>,columns:PyReadonlyArray1<'_,u32>,origin:[f32;3],dimensions:[u32;3],cell:f32,cell_coordinates:Option<PyReadonlyArray2<'_,u32>>)->PyResult<Self>{
  let empty=ndarray::Array2::<f32>::zeros((0,3));
  let coords=cell_coordinates.as_ref().map(|a|a.as_array());
  sample_grid_impl(py,empty.view(),points.as_array(),radii.as_array(),rows.as_slice()?,columns.as_slice()?,origin,dimensions,cell,1,0,false,cell,None,None,None,None,true,None,true,coords,None,false)?;
  Ok(Self{points:points.as_array().to_owned(),radii:radii.as_array().to_owned(),rows:rows.as_slice()?.to_vec(),columns:columns.as_slice()?.to_vec(),origin,dimensions,cell,coordinates:coords.map(|a|a.to_owned())})
 }
 #[pyo3(signature=(queries,k,kernel,volume,search_radius,requested_k=None,prepared_occupancy=None))]
 fn query(&self,py:Python<'_>,queries:PyReadonlyArray2<'_,f32>,k:usize,kernel:u8,volume:bool,search_radius:f32,requested_k:Option<usize>,prepared_occupancy:Option<PyRef<'_,occupancy_variants::_PreparedOccupancy>>)->PyResult<PyObject>{
  sample_grid_impl(py,queries.as_array(),self.points.view(),self.radii.view(),&self.rows,&self.columns,self.origin,self.dimensions,self.cell,k,kernel,volume,search_radius,None,None,None,None,true,requested_k,true,self.coordinates.as_ref().map(|a|a.view()),prepared_occupancy,true)
 }
}

type Four=[f32;4];
// Explicit baseline SIMD avoids scalarization across recursive packet calls.
// No fused arithmetic, reciprocal approximations, or horizontal reductions.
#[inline(always)] pub(crate) fn add4(a:Four,b:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vaddq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_add_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]+b[i])}
}
#[inline(always)] pub(crate) fn sub4(a:Four,b:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vsubq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_sub_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]-b[i])}
}
#[inline(always)] pub(crate) fn mul4(a:Four,b:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vmulq_f32(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_mul_ps(std::mem::transmute(a),std::mem::transmute(b)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {std::array::from_fn(|i|a[i]*b[i])}
}
#[inline(always)] fn sqrt4(a:Four)->Four{
 #[cfg(target_arch="aarch64")] unsafe {use std::arch::aarch64::*; return std::mem::transmute(vsqrtq_f32(std::mem::transmute(a)));}
 #[cfg(target_arch="x86_64")] unsafe {use std::arch::x86_64::*; return std::mem::transmute(_mm_sqrt_ps(std::mem::transmute(a)));}
 #[cfg(not(any(target_arch="aarch64",target_arch="x86_64")))] {a.map(f32::sqrt)}
}
#[inline(always)] fn dot4(a:[Four;3],b:[Four;3])->Four{add4(add4(mul4(a[0],b[0]),mul4(a[1],b[1])),mul4(a[2],b[2]))}

// Same per-point subtract, multiply, left-associated add and correctly rounded
// sqrt as scalar sampling. Baseline NEON/SSE; no FMA or reciprocal approximation.
#[inline(always)] fn distance4(q:[f32;3],p:[Four;3])->Four{
 let d=std::array::from_fn(|a|sub4([q[a];4],p[a]));sqrt4(dot4(d,d))
}

// Saturating floor-to-i32 without a scalar libm round trip on baseline x86.
// Large f32 integers are already integral; NaN and infinities retain Rust cast
// saturation. The negative fractional correction cannot underflow.
#[inline(always)] pub(crate) fn floor_i32(value:f32)->i32 {
 let truncated=value as i32;
 if value < truncated as f32 && truncated>i32::MIN {truncated-1}else{truncated}
}
