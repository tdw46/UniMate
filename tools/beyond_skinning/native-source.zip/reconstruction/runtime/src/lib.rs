//! Research runtime foundation. NOT a reconstructed complete solver.
mod gpu_contract;
mod field_arrays;
mod face_entry;
mod bind_session;
mod bind_entry;
mod named_fingers;
mod geometric_fingers;
mod combined_fingers;
mod spine_entry;
mod bind_env;
mod orphan;
mod seed_clearance;
mod level_graph;
mod rig_family_table;
mod rig_families;
mod sparse_setup;
mod compact_fields;
mod arrays;
mod array_input;
mod bvh;
mod ghost;
mod winding_tree;
mod voxel;
mod refinement;
mod cloud;
mod sampling;
mod occupancy_variants;
mod seeds;
mod seed_shapes;
mod seed_postprocess;
mod automatic_shapes;
mod cage;
mod cpu;
mod cancel;
#[cfg(feature = "gpu")]
mod gpu;
#[cfg(feature = "gpu")]
mod transport_input;
#[cfg(feature = "gpu")]
use transport_input::ReplayInput;
#[cfg(feature = "gpu")]
mod context_cache;
#[cfg(feature = "gpu")]
mod readback;
mod tree;
mod rest;
mod mesh;
mod skeleton;
mod rig_map_entry;
mod face_parts_entry;
mod full_skeleton;
mod face_roles;
mod side_names;
mod bone_hues;
mod thigh_name;
mod metadata;
mod face_seam_entry;
mod smooth_weights;
mod weight_hash;
mod weight_diffusion;
mod weight_tables;
mod mouth_graph;
mod grid;
mod graph;
mod reskin;
pub mod types;
mod weights;
use pyo3::prelude::*;
pyo3::create_exception!(_bvt_solver, GpuDeviceError, pyo3::exceptions::PyRuntimeError);
#[cfg(feature = "gpu")]
fn replay_error(error:gpu::ReplayFailure)->PyErr {
    match error {
        gpu::ReplayFailure::Device(message)=>GpuDeviceError::new_err(message),
        gpu::ReplayFailure::Transport(message)=>PyValueError::new_err(message),
    }
}

#[cfg(feature = "gpu")]
use pyo3::{exceptions::PyValueError, types::PyBytes};
#[pyfunction]
fn reconstruction_complete() -> bool {
    false
}
#[cfg(feature = "gpu")]
#[pyfunction]
#[pyo3(signature=(kind,arrays,initial,iterations,generated_uniforms=false))]
fn replay_gpu<'py>(
    py: Python<'py>,
    kind: &str,
    arrays: Vec<ReplayInput<'py>>,
    initial: ReplayInput<'py>,
    iterations: u32,
    generated_uniforms: bool,
) -> PyResult<Bound<'py, PyBytes>> {
    let views: Vec<&[u8]> = arrays.iter().map(ReplayInput::as_bytes).collect();
    let initial_view = initial.as_bytes();
    let result = py
        .allow_threads(|| gpu::capture(||if generated_uniforms {gpu::replay_generated(kind,&views,initial_view,iterations)} else {gpu::replay(kind, &views, initial_view, iterations)}))
        .map_err(replay_error)?;
    Ok(PyBytes::new(py, &result))
}
#[cfg(feature = "gpu")]
#[pyfunction]
fn replay_gpu_auto<'py>(py:Python<'py>,kind:&str,arrays:Vec<ReplayInput<'py>>,initial:ReplayInput<'py>,iterations:u32,batch:u32,tolerance:f32,fraction:f32)->PyResult<(Bound<'py,PyBytes>,u32,Vec<(u32,f32,u32)>)>{
    let views: Vec<&[u8]> = arrays.iter().map(ReplayInput::as_bytes).collect();
    let initial_view = initial.as_bytes();
    let (bytes,completed,history)=py.allow_threads(||gpu::capture(||gpu::replay_auto(kind,&views,initial_view,iterations,gpu::StopPolicy{batch,tolerance,fraction}))).map_err(replay_error)?;
    Ok((PyBytes::new(py,&bytes),completed,history))
}
#[pyfunction]
fn probe_multiplier(max_depth: i64, refine_multiplier: i64) -> u32 {
    let mut depth = max_depth.max(0) as u32;
    let mut multiplier = refine_multiplier.max(1) as u32;
    let mut result = 1u32;
    while depth != 0 {
        if depth & 1 != 0 {
            match result.checked_mul(multiplier) {
                Some(v) => result = v,
                None => return 8,
            }
        }
        depth >>= 1;
        if depth != 0 {
            match multiplier.checked_mul(multiplier) {
                Some(v) => multiplier = v,
                None => return 8,
            }
        }
    }
    result.clamp(1, 8)
}
#[pyfunction]
fn gpu_compiled() -> bool {
    cfg!(feature = "gpu")
}
#[cfg(feature = "gpu")]
#[pyfunction]
fn gpu_info() -> PyResult<(String, String)> {
    gpu::info().map_err(PyValueError::new_err)
}
#[cfg(feature = "gpu")]
#[pyfunction]
fn gpu_device_limits(py: Python<'_>) -> PyResult<(u64,u32)> {
    py.allow_threads(gpu::device_limits).map_err(PyValueError::new_err)
}
#[pymodule]
fn _bvt_solver(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<occupancy_variants::_PreparedOccupancy>()?;
    m.add_class::<seeds::_PreparedSeedMasks>()?;
    m.add_class::<sampling::_PreparedSampleGrid>()?;
    m.add_class::<cloud::_SurfaceQuery>()?;
    #[cfg(feature="gpu")]
    m.add_class::<winding_tree::_PreparedGpuWinding>()?;
    m.add_function(wrap_pyfunction!(orphan::fill_orphan_weights, m)?)?;
    m.add_function(wrap_pyfunction!(seed_clearance::seed_bone_clearance, m)?)?;
    m.add_function(wrap_pyfunction!(level_graph::coarsen_level_graph, m)?)?;
    m.add_function(wrap_pyfunction!(level_graph::build_interlevel_map, m)?)?;
    m.add_function(wrap_pyfunction!(level_graph::coarsen_level_array, m)?)?;
    m.add_function(wrap_pyfunction!(level_graph::build_interlevel_arrays, m)?)?;
    m.add_function(wrap_pyfunction!(face_roles::detect_face, m)?)?;
    m.add("detect_face_public", wrap_pyfunction!(face_entry::detect_face, m)?)?;
    m.add_function(wrap_pyfunction!(rig_families::rig_family_keys, m)?)?;
    m.add_function(wrap_pyfunction!(sparse_setup::sparse_seed_slots, m)?)?;
    m.add_function(wrap_pyfunction!(sparse_setup::interpolate_level_field, m)?)?;
    m.add_function(wrap_pyfunction!(sparse_setup::build_sparse_edge_map, m)?)?;
    m.add_function(wrap_pyfunction!(sparse_setup::build_sparse_edge_array, m)?)?;
    m.add_function(wrap_pyfunction!(seeds::constrained_seed_mask_block, m)?)?;
    m.add_function(wrap_pyfunction!(rig_families::select_rig_family, m)?)?;
    m.add_function(wrap_pyfunction!(winding_tree::build_winding_tree, m)?)?;
    m.add_function(wrap_pyfunction!(winding_tree::winding_solid_angles_cpu, m)?)?;
    m.add_function(wrap_pyfunction!(bind_env::set_bind_env, m)?)?;
    m.add_function(wrap_pyfunction!(bind_env::bind_env_snapshot, m)?)?;
    m.add_function(wrap_pyfunction!(voxel::grid_admission, m)?)?;
    m.add_function(wrap_pyfunction!(voxel::triangle_box, m)?)?;
    m.add_function(wrap_pyfunction!(voxel::surface_voxels, m)?)?;
    m.add_function(wrap_pyfunction!(voxel::surface_voxel_bucket_order, m)?)?;
    m.add_function(wrap_pyfunction!(voxel::probe_surface, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::sample_from_grid, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::accumulate_sample_fields, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::accumulate_sparse_sample_fields, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::reduce_top_weights, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::select_sample_candidates, m)?)?;
    m.add_function(wrap_pyfunction!(seeds::nearest_seed_bones, m)?)?;
    m.add_function(wrap_pyfunction!(seeds::normal_seed_groups, m)?)?;
    m.add_function(wrap_pyfunction!(cloud::coarse_cloud, m)?)?;
    m.add_function(wrap_pyfunction!(ghost::ghost_cull, m)?)?;
    m.add_function(wrap_pyfunction!(bvh::triangle_closest_point, m)?)?;
    m.add_function(wrap_pyfunction!(cloud::assemble_adaptive_cloud, m)?)?;
    m.add_function(wrap_pyfunction!(cloud::_assemble_adaptive_arrays, m)?)?;
    m.add_function(wrap_pyfunction!(cloud::adaptive_surface_points, m)?)?;
    m.add_function(wrap_pyfunction!(refinement::refinement_cluster_bounds, m)?)?;
    m.add_function(wrap_pyfunction!(refinement::refinement_cluster_groups, m)?)?;
    m.add_function(wrap_pyfunction!(seeds::seed_profile_masks, m)?)?;
    m.add_function(wrap_pyfunction!(seeds::constrained_seed_masks, m)?)?;
    m.add_function(wrap_pyfunction!(automatic_shapes::auto_bone_mid_profile, m)?)?;
    m.add_function(wrap_pyfunction!(automatic_shapes::bone_base_radii, m)?)?;
    m.add_function(wrap_pyfunction!(automatic_shapes::fit_cloud_radii, m)?)?;
    m.add_function(wrap_pyfunction!(automatic_shapes::eyelid_ring_profile, m)?)?;
    m.add_function(wrap_pyfunction!(automatic_shapes::eyelid_group_shapes, m)?)?;
    m.add_function(wrap_pyfunction!(seeds::regular_seed_field, m)?)?;
    m.add_function(wrap_pyfunction!(seed_postprocess::custom_seed_field, m)?)?;
    m.add_function(wrap_pyfunction!(seed_postprocess::clean_dense_field, m)?)?;
    m.add_function(wrap_pyfunction!(seed_postprocess::seed_strengths, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::fallback_label_samples, m)?)?;
    m.add_function(wrap_pyfunction!(cloud::refinement_replacement_keys, m)?)?;
    m.add_function(wrap_pyfunction!(refinement::refinement_probe, m)?)?;
    m.add_function(wrap_pyfunction!(refinement::refinement_depths, m)?)?;
    m.add_function(wrap_pyfunction!(refinement::refinement_markers, m)?)?;
    m.add_function(wrap_pyfunction!(refinement::rescale_refinement_box, m)?)?;
    #[cfg(feature="gpu")]
    m.add_function(wrap_pyfunction!(winding_tree::winding_values, m)?)?;
    m.add_function(wrap_pyfunction!(rest::rest_space_keep, m)?)?;
    m.add_function(wrap_pyfunction!(mesh::join_meshes, m)?)?;
    m.add_function(wrap_pyfunction!(grid::bind_grid, m)?)?;
    m.add_function(wrap_pyfunction!(smooth_weights::smooth_weights, m)?)?;
    m.add_function(wrap_pyfunction!(weight_hash::weight_hash_u32, m)?)?;
    m.add_function(wrap_pyfunction!(weight_diffusion::weight_diffuse_row, m)?)?;
    m.add_function(wrap_pyfunction!(weight_tables::weight_adjacency, m)?)?;
    m.add_function(wrap_pyfunction!(weight_tables::weight_component_entries, m)?)?;
    m.add_function(wrap_pyfunction!(weight_tables::weight_finalize_tables, m)?)?;

    m.add_function(wrap_pyfunction!(weight_diffusion::weight_initial_row, m)?)?;
    m.add_function(wrap_pyfunction!(mouth_graph::mouth_mesh_graph, m)?)?;
    m.add_function(wrap_pyfunction!(bone_hues::bone_hues, m)?)?;
    m.add_function(wrap_pyfunction!(thigh_name::is_thigh_name, m)?)?;
    m.add_function(wrap_pyfunction!(faceprobe_entry::detect_refine_faceprobe, m)?)?;
    m.add_function(wrap_pyfunction!(face_seam_entry::face_seam_labels, m)?)?;
    m.add_function(wrap_pyfunction!(metadata::version, m)?)?;
    m.add_function(wrap_pyfunction!(metadata::tuning_values, m)?)?;
    m.add_function(wrap_pyfunction!(side_names::flip_side, m)?)?;
    m.add_function(wrap_pyfunction!(side_names::blender_flips, m)?)?;
    m.add_function(wrap_pyfunction!(graph::graph_diagonal, m)?)?;
    m.add_function(wrap_pyfunction!(graph::build_graph, m)?)?;
    m.add_function(wrap_pyfunction!(graph::build_sample_grid, m)?)?;
    m.add_function(wrap_pyfunction!(graph::build_occupancy, m)?)?;
    m.add_function(wrap_pyfunction!(reskin::scoped_reskin, m)?)?;
    m.add_function(wrap_pyfunction!(skeleton::deform_subset, m)?)?;
    m.add_function(wrap_pyfunction!(skeleton::core_chain_mask, m)?)?;
    m.add_function(wrap_pyfunction!(full_skeleton::full_skeleton, m)?)?;
    m.add_function(wrap_pyfunction!(rig_map_entry::rig_map, m)?)?;
    m.add_function(wrap_pyfunction!(face_parts_entry::plan_face_parts, m)?)?;
    m.add_function(wrap_pyfunction!(cancel::request_cancel, m)?)?;
    m.add_function(wrap_pyfunction!(cancel::clear_cancel, m)?)?;
    m.add_function(wrap_pyfunction!(cancel::cancel_message, m)?)?;
    m.add_function(wrap_pyfunction!(cancel::check_cancel, m)?)?;
    m.add_class::<arrays::VoxelCloud>()?;
    m.add_class::<weights::WeightRows>()?;
    m.add_class::<tree::VertexTree>()?;
    m.add_class::<bvh::MeshBvh>()?;
    m.add_class::<winding_tree::_WindingQuery>()?;
    m.add("GpuDeviceError", m.py().get_type::<GpuDeviceError>())?;
    m.add("PanicException", m.py().get_type::<pyo3::panic::PanicException>())?;
    m.add_function(wrap_pyfunction!(bind_entry::bind,m)?)?;
    m.add_function(wrap_pyfunction!(bind_entry::invalid_viz,m)?)?;
    m.add_function(wrap_pyfunction!(named_fingers::detect_fingers_by_name,m)?)?;
    m.add_function(wrap_pyfunction!(geometric_fingers::detect_fingers_geometric,m)?)?;
    m.add_function(wrap_pyfunction!(combined_fingers::detect_fingers,m)?)?;
    m.add_function(wrap_pyfunction!(spine_entry::detect_spine,m)?)?;
    m.add_function(wrap_pyfunction!(bind_entry::fail_empty_cloud,m)?)?;
    m.add_class::<bind_session::BindSession>()?;
    m.add_function(wrap_pyfunction!(bind_session::validate_cloud_geometry,m)?)?;
    m.add_class::<cage::CageBinding>()?;
    m.add_function(wrap_pyfunction!(seed_postprocess::clean_dense_array, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::accumulate_sample_array, m)?)?;
    m.add_function(wrap_pyfunction!(sampling::reduce_sample_array, m)?)?;
    m.add_function(wrap_pyfunction!(sparse_setup::interpolate_level_array, m)?)?;
    m.add_function(wrap_pyfunction!(sparse_setup::interpolate_sparse_arrays, m)?)?;
    m.add_function(wrap_pyfunction!(compact_fields::interpolate_compact_arrays, m)?)?;
    m.add_function(wrap_pyfunction!(compact_fields::clean_compact_arrays, m)?)?;
    m.add_function(wrap_pyfunction!(compact_fields::sample_compact_array, m)?)?;
    m.add_function(wrap_pyfunction!(compact_fields::sample_compact_reduced, m)?)?;
    m.add_function(wrap_pyfunction!(cpu::solve_dense_cpu, m)?)?;
    m.add_function(wrap_pyfunction!(cpu::solve_sparse_cpu, m)?)?;
    m.add_function(wrap_pyfunction!(arrays::morton_order, m)?)?;
    m.add_function(wrap_pyfunction!(reconstruction_complete, m)?)?;
    m.add_function(wrap_pyfunction!(gpu_compiled, m)?)?;
    m.add_function(wrap_pyfunction!(gpu_contract::gpu_limits, m)?)?;
    m.add_function(wrap_pyfunction!(gpu_contract::gpu_budget_check, m)?)?;
    #[cfg(feature = "gpu")]
    {
        m.add("immutable_replay_inputs", true)?;
        m.add("staged_auto_readback", true)?;
        m.add("generated_fixed_uniforms", true)?;
        m.add_function(wrap_pyfunction!(replay_gpu, m)?)?;
        m.add_function(wrap_pyfunction!(replay_gpu_auto, m)?)?;
        m.add_function(wrap_pyfunction!(gpu_info, m)?)?;
        m.add_function(wrap_pyfunction!(gpu_device_limits, m)?)?;
    }
    m.add_function(wrap_pyfunction!(probe_multiplier, m)?)?;
    Ok(())
}

mod faceprobe_entry;
