//! Adaptive surface probes and level-box mapping recovered from 0x5ef8c/0xda0ac.
use rustc_hash::FxHashMap;
use rayon::prelude::*;
use pyo3::{prelude::*,exceptions::PyValueError};
use numpy::PyReadonlyArray2;
#[pyfunction]
#[pyo3(signature=(coords,normals,dimensions,maximum,bounded=true))]
pub fn refinement_probe(py:Python<'_>,coords:PyReadonlyArray2<'_,i64>,normals:PyReadonlyArray2<'_,f32>,dimensions:[i64;3],maximum:f32,bounded:bool)->PyResult<(Vec<u32>,Vec<u32>)>{
 let xyz=crate::array_input::owned_two(&coords);let ns=crate::array_input::owned_two(&normals);
 py.allow_threads(move || {

 if xyz.ncols()!=3 || ns.ncols()!=3 || xyz.nrows()!=ns.nrows() || dimensions.iter().any(|&d|d<=0) || !maximum.is_finite() || (maximum<0.0 || (bounded && maximum>10000.0)) || (bounded && ns.iter().any(|x|!x.is_finite())) || xyz.rows().into_iter().any(|r|(0..3).any(|k|r[k]<0 || r[k]>=dimensions[k])){return Err(PyValueError::new_err("invalid refinement probe inputs"));}
 let points:Vec<[i64;3]>=xyz.rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect();
 // Lookup only: duplicate coordinates retain their last source index. No map
 // iteration order enters the algorithm.
 let map:FxHashMap<[i64;3],usize>=points.iter().enumerate().map(|(i,&p)|(p,i)).collect();
 let mut distances=vec![0u32;points.len()];let mut targets=vec![u32::MAX;points.len()];
 let run=|(i,(distance,target)):(usize,(&mut u32,&mut u32))| {
  let point=&points[i];
  let mut entered_gap=false;let mut gap_start=0.0f32;let mut t=0.5f32;
  while t<=maximum {
   let q=std::array::from_fn::<_,3,_>(|k|((point[k] as f32+0.5)+ns[[i,k]]*t).floor() as i64);
   if (0..3).any(|k|q[k]<0 || q[k]>=dimensions[k]){break;}
   let near=(0..3).all(|k|(q[k]-point[k]).abs()<=1);let hit=map.get(&q).copied();
   if entered_gap {
    if let Some(j)=hit {*distance=(t-gap_start).round() as u32+1;*target=j as u32;break;}
   } else if let Some(j)=hit {
    if near && j!=i {
     let dot=(ns[[i,0]]*ns[[j,0]]+ns[[i,1]]*ns[[j,1]])+ns[[i,2]]*ns[[j,2]];
     if dot < -0.5 {*distance=1;*target=j as u32;break;}
    }
   } else if !near {entered_gap=true;gap_start=t;}
   t=t+0.5;
  }
 };
 if points.len()>=1024 {distances.par_iter_mut().zip(targets.par_iter_mut()).enumerate().for_each(run);}
 else {distances.iter_mut().zip(targets.iter_mut()).enumerate().for_each(run);}
 Ok((distances,targets))

 })
}
#[pyfunction]
#[pyo3(signature=(bounds,target,multiplier,bounded=true))]
pub fn rescale_refinement_box(bounds:[i64;7],target:u32,multiplier:u32,bounded:bool)->PyResult<[i32;6]>{
 let source=bounds[0];
 if source<0 || source>u32::MAX as i64 || multiplier==0 || bounds[1..].iter().any(|&x|x<i32::MIN as i64 || x>i32::MAX as i64) || (bounded && (source>32 || target>32 || multiplier>16)){return Err(PyValueError::new_err("invalid refinement box levels"));}
 let exponent=(source as u32).abs_diff(target);
 let factor=if bounded {multiplier.checked_pow(exponent).filter(|&x|x<=i32::MAX as u32).ok_or_else(||PyValueError::new_err("research refinement box scale exceeds signed range"))? as i32}else{multiplier.wrapping_pow(exponent) as i32};
 if target<source as u32 {
  let mut out=[0i32;6];
  for k in 0..6 {out[k]=(bounds[k+1] as i32).checked_div_euclid(factor).ok_or_else(||pyo3::panic::PanicException::new_err(if factor==0{"attempt to divide by zero"}else{"attempt to divide with overflow"}))?;}
  Ok(out)
 }else{Ok(std::array::from_fn(|k|if k<3{(bounds[k+1] as i32).wrapping_mul(factor)}else{(bounds[k+1] as i32).wrapping_mul(factor).wrapping_add(factor.wrapping_sub(1))}))}
}
#[pyfunction]
#[pyo3(signature=(distances,targets,coarse_cell,probe_cell,multiplier,max_depth,bounded=true))]
pub fn refinement_depths(py:Python<'_>,distances:Vec<u32>,targets:Vec<u32>,coarse_cell:f32,probe_cell:f32,multiplier:u32,max_depth:u32,bounded:bool)->PyResult<Vec<u32>>{
 py.allow_threads(move || {
 if distances.len()!=targets.len() || targets.iter().any(|&i|i!=u32::MAX && i as usize>=distances.len()) || !(coarse_cell>0.0 && probe_cell>0.0 && (!bounded || (coarse_cell.is_finite() && probe_cell.is_finite()))) || (bounded && max_depth>32) {return Err(PyValueError::new_err("invalid refinement depth inputs"));}
 let m=multiplier.max(2) as f32;let mut depths=vec![0u32;distances.len()];
 for (i,&distance) in distances.iter().enumerate(){if distance!=0 {for depth in 0..max_depth{if probe_cell*((distance-1) as f32)<coarse_cell*(2.0/m.powi(depth as i32)){depths[i]=depth+1;}}}}
 // Original propagates once in source order, reading already updated depths.
 for (i,&j) in targets.iter().enumerate(){if j!=u32::MAX && depths[j as usize]<depths[i]{depths[j as usize]=depths[i];}}
 Ok(depths)

 })
}

/// Per-level region membership from the serial leaf of 0x6abf4.
/// Optional native hash bucket order retains the original insertion stream.
#[pyfunction]
#[pyo3(signature=(coords,depths,origin,probe_cell,coarse_cell,multiplier,max_depth,padding,native_order=false,bounded=true))]
pub fn refinement_markers(py:Python<'_>,coords:PyReadonlyArray2<'_,i32>,depths:Vec<u32>,origin:[f32;3],probe_cell:f32,coarse_cell:f32,multiplier:u32,max_depth:u32,padding:u32,native_order:bool,bounded:bool)->PyResult<Vec<Vec<[i32;3]>>>{
 let xyz=crate::array_input::owned_two(&coords);
 py.allow_threads(move || {
 use std::collections::HashSet;

 if xyz.ncols()!=3 || xyz.nrows()!=depths.len() || (bounded && origin.iter().any(|v|!v.is_finite())) || !(probe_cell>0.0 && coarse_cell>0.0 && (!bounded || (probe_cell.is_finite() && coarse_cell.is_finite()))) || multiplier==0 || (bounded && (multiplier>16 || max_depth>16 || padding>16)) {return Err(PyValueError::new_err("invalid refinement marker inputs"));}
 let mut sets:Vec<HashSet<(i32,i32,i32),rustc_hash::FxBuildHasher>>=(0..max_depth).map(|_|HashSet::default()).collect();
 let mut scales=Vec::new();let mut visits=0u64;
 for level in 0..depths.iter().copied().max().unwrap_or(0).min(max_depth) {
  let scale=if bounded {multiplier.checked_pow(level).filter(|&s|s<=i32::MAX as u32).ok_or_else(||PyValueError::new_err("refinement marker scale exceeds research bound"))?}else{multiplier.wrapping_pow(level)};
  let pad=if bounded {scale.checked_mul(padding).filter(|&p|p<=1000).ok_or_else(||PyValueError::new_err("refinement marker padding exceeds research bound"))? as i32}else{scale.wrapping_mul(padding) as i32};
  let active=depths.iter().filter(|&&d|d>level).count() as u64;
  let width=(pad as i64-pad.wrapping_neg() as i64+1).max(0) as u64;
  visits=visits.saturating_add(width.saturating_pow(3).saturating_mul(active));
  if bounded && visits>2_000_000 {return Err(PyValueError::new_err("refinement marker work exceeds research bound"));}
  scales.push((scale,pad));
 }
 for (i,row) in xyz.rows().into_iter().enumerate(){
  // Keep both origin operations: cancellation at large origins is observable.
  let center: [f32;3]=std::array::from_fn(|k|origin[k]+probe_cell*(row[k] as f32+0.5));
  for level in 0..depths[i].min(max_depth) as usize {
   let (scale,pad)=scales[level];let cell=coarse_cell/scale as f32;
   let mapped:[f32;3]=std::array::from_fn(|k|((center[k]-origin[k])/cell).floor());
   if bounded && mapped.iter().any(|&v|!v.is_finite() || v< -2_147_000_000.0 || v>2_147_000_000.0) {return Err(PyValueError::new_err("refinement marker coordinate exceeds research bound"));}
   // ARM64 fcvtms saturates at signed endpoints; padding then wraps.
   let c=mapped.map(|v|v as i32);
   for x in pad.wrapping_neg()..=pad {for y in pad.wrapping_neg()..=pad {for z in pad.wrapping_neg()..=pad {sets[level].insert((c[0].wrapping_add(x),c[1].wrapping_add(y),c[2].wrapping_add(z)));}}}
  }
 }
 Ok(sets.into_iter().map(|set|{let mut merged=HashSet::<(i32,i32,i32),rustc_hash::FxBuildHasher>::with_capacity_and_hasher(set.len(),rustc_hash::FxBuildHasher);for key in set{merged.insert(key);}let mut points:Vec<_>=merged.into_iter().map(|(x,y,z)|[x,y,z]).collect();if !native_order{points.sort_unstable();}points}).collect())

 })
}

/// 26-connected marker clusters and world bounds, inline 0xaaaf4 (0xacce8+).
/// Seed order is supplied explicitly so parallel marker reductions are separate.
#[pyfunction]
#[pyo3(signature=(markers,origin,cell,bounded=true))]
pub fn refinement_cluster_bounds(markers:Vec<[i32;3]>,origin:[f32;3],cell:f32,bounded:bool)->PyResult<Vec<[f32;6]>>{
 use std::collections::HashSet;
 if (bounded && (markers.len()>2_000_000 || markers.iter().flatten().any(|&x|x.abs_diff(0)>2_000_000_000))) || !(cell>0.0 && cell.is_finite()) || origin.iter().any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid refinement cluster inputs"));}
 let members:rustc_hash::FxHashSet<_>=markers.iter().copied().collect();let mut seen=rustc_hash::FxHashSet::default();let mut boxes=Vec::new();
 for start in markers{if !seen.insert(start){continue;}let mut stack=vec![start];let mut lo=start;let mut hi=start;
  while let Some(p)=stack.pop(){for k in 0..3{lo[k]=lo[k].min(p[k]);hi[k]=hi[k].max(p[k]);}
   for x in -1..=1 {for y in -1..=1{for z in -1..=1{if x==0 && y==0 && z==0{continue;}let q=[p[0].wrapping_add(x),p[1].wrapping_add(y),p[2].wrapping_add(z)];if members.contains(&q)&&seen.insert(q){stack.push(q);}}}}
  }
  // The next stage re-snaps world bounds to this lattice using reciprocal
  // multiplication. Keep this round trip: cancellation can add a boundary cell.
  // Assembly 0x6e35c/0x6e36c floors minima; 0x6e378/0x6e3a0 ceils maxima.
  let raw:[f32;6]=std::array::from_fn(|k|if k<3{origin[k]+cell*lo[k] as f32}else{origin[k-3]+cell*hi[k-3].wrapping_add(1) as f32});
  let inverse=1.0f32/cell;
  boxes.push(std::array::from_fn(|k|{let q=(raw[k]-origin[k%3])*inverse;origin[k%3]+cell*if k<3{q.floor()}else{q.ceil()}}));
 }Ok(boxes)
}

/// Serial cluster traversal and per-cluster Fx bucket order (0xacce8..0xad95c).
#[pyfunction]
#[pyo3(signature=(markers,bounded=true))]
pub fn refinement_cluster_groups(py:Python<'_>,markers:Vec<[i32;3]>,bounded:bool)->PyResult<Vec<Vec<[i32;3]>>>{
 py.allow_threads(move || {
 use std::collections::HashSet;
 if bounded && (markers.len()>2_000_000 || markers.iter().flatten().any(|&x|x.abs_diff(0)>2_000_000_000)){return Err(PyValueError::new_err("invalid refinement markers"));}
 let members:rustc_hash::FxHashSet<_>=markers.iter().copied().collect();let mut seen=rustc_hash::FxHashSet::default();let mut groups=Vec::new();
 for start in markers{if !seen.insert(start){continue;}let mut stack=vec![start];let mut group=Vec::new();
  while let Some(p)=stack.pop(){group.push(p);
   for x in -1..=1{for y in -1..=1{for z in -1..=1{if x==0&&y==0&&z==0{continue;}let q=[p[0].wrapping_add(x),p[1].wrapping_add(y),p[2].wrapping_add(z)];if members.contains(&q)&&seen.insert(q){stack.push(q);}}}}
  }
  let mut ordered=HashSet::<(i32,i32,i32),rustc_hash::FxBuildHasher>::with_capacity_and_hasher(group.len(),rustc_hash::FxBuildHasher);
  for q in group{ordered.insert((q[0],q[1],q[2]));}
  groups.push(ordered.into_iter().map(|(x,y,z)|[x,y,z]).collect());
 }Ok(groups)

 })
}
