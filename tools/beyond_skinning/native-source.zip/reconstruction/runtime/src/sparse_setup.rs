//! Sparse fixed-width seed-slot construction (0x168774), bounded finite inputs.
use pyo3::{prelude::*,exceptions::PyValueError};
use rayon::prelude::*;
#[pyfunction]
pub fn sparse_seed_slots(field:Vec<f32>,k:usize,seed:u32)->PyResult<(Vec<u16>,Vec<f32>)>{
 if k==0 || k>16 || field.len()>65534 || field.iter().any(|x|!x.is_finite()) || (seed!=u32::MAX && seed>=65535){return Err(PyValueError::new_err("invalid bounded sparse field"))}
 let mut selected:Vec<(u16,f32)>=Vec::new();
 for (i,&w) in field.iter().enumerate(){if w>0. {
  if selected.len()<k { selected.push((i as u16,w));if selected.len()==k{selected.sort_by(|a,b|b.1.total_cmp(&a.1));}}
  else if w>selected[k-1].1 {selected[k-1]=(i as u16,w);let mut j=k-1;while j>0 && selected[j].1>selected[j-1].1{selected.swap(j,j-1);j-=1;}}
 }}
 if selected.len()<k{selected.sort_by(|a,b|b.1.total_cmp(&a.1));}
 if seed!=u32::MAX && !selected.iter().any(|x|x.0==seed as u16){
  let v=(seed as u16,field.get(seed as usize).copied().unwrap_or(0.));
  if selected.len()<k{selected.push(v)}else{selected[k-1]=v;}
 }
 selected.sort_by_key(|x|x.0);let mut ids=vec![u16::MAX;k];let mut values=vec![0.;k];
 for (i,(id,w)) in selected.into_iter().enumerate(){ids[i]=id;values[i]=w;}
 Ok((ids,values))
}

#[pyfunction]
pub fn build_sparse_edge_map(py:Python<'_>,rows:numpy::PyReadonlyArray1<'_,u32>,columns:numpy::PyReadonlyArray1<'_,u32>,groups:numpy::PyReadonlyArray2<'_,u16>)->PyResult<Vec<u8>>{
 edge_map_owned(py,rows,columns,groups,16_000_000,false)
}
fn edge_map_owned(py:Python<'_>,rows:numpy::PyReadonlyArray1<'_,u32>,columns:numpy::PyReadonlyArray1<'_,u32>,groups:numpy::PyReadonlyArray2<'_,u16>,budget:usize,cancellable:bool)->PyResult<Vec<u8>>{
 let rs=rows.as_slice()?;let cs=columns.as_slice()?;let g=groups.as_array();let n=g.nrows();let k=g.ncols();
 if k==0 || k>255 || rs.len()!=n+1 || rs.first()!=Some(&0) || rs.last().copied()!=Some(cs.len() as u32) || rs.windows(2).any(|x|x[0]>x[1]) || cs.iter().any(|&x|x as usize>=n) || cs.len().saturating_mul(k)>budget {return Err(PyValueError::new_err("invalid bounded sparse graph"))}
 for row in g.rows(){if row.windows(2).into_iter().any(|w|w[0]>w[1]){return Err(PyValueError::new_err("sparse slots must be sorted"))}}
 let count=crate::compact_fields::allocation_len(cs.len(),k,1)?;
 let out=py.allow_threads(||{
 let mut out=vec![255;count];
 let run=|(batch,output):(usize,&mut[u8])| {
  let start=batch*256;let mut i=rs.partition_point(|&x|x as usize<=start).saturating_sub(1);
  if cancellable{crate::cancel::check();}
  for (offset,row) in output.chunks_exact_mut(k).enumerate(){let e=start+offset;
   while i+1<n && rs[i+1] as usize<=e{i+=1;}
   let source=g.row(i);let target=g.row(cs[e] as usize);let mut j=0;
   for (slot,&bone) in source.iter().enumerate(){if bone==u16::MAX{break}while j<k && target[j]<bone{j+=1}if j<k && target[j]==bone{row[slot]=j as u8;}}
  }
 };
 if cs.len()>=1024 {out.par_chunks_mut(k*256).enumerate().for_each(run);}
 else {out.chunks_mut(k*256).enumerate().for_each(run);}

 out
 });
 Ok(out)
}
#[pyfunction]
pub fn build_sparse_edge_array<'py>(py:Python<'py>,rows:numpy::PyReadonlyArray1<'py,u32>,columns:numpy::PyReadonlyArray1<'py,u32>,groups:numpy::PyReadonlyArray2<'py,u16>)->PyResult<Bound<'py,numpy::PyArray1<u8>>>{
 let output=edge_map_owned(py,rows,columns,groups,isize::MAX as usize,true)?;
 Ok(numpy::PyArray1::from_vec(py,output))
}


/// Coarse-to-fine four-sample interpolation normalizes by the valid sample sum.
/// This is deliberately separate from final vertex-field accumulation.
#[pyfunction]
pub fn interpolate_level_field(ids:numpy::PyReadonlyArray2<'_,u32>,weights:numpy::PyReadonlyArray2<'_,f32>,fields:numpy::PyReadonlyArray2<'_,f32>)->PyResult<Vec<Vec<f32>>>{
 interpolate_owned(ids,weights,fields,true)
}
fn interpolate_owned(ids:numpy::PyReadonlyArray2<'_,u32>,weights:numpy::PyReadonlyArray2<'_,f32>,fields:numpy::PyReadonlyArray2<'_,f32>,bounded:bool)->PyResult<Vec<Vec<f32>>>{
 let ids=ids.as_array();let w=weights.as_array();let f=fields.as_array();
 if ids.ncols()!=4 || ids.shape()!=w.shape() || ids.iter().any(|&i|i!=u32::MAX && i as usize>=f.nrows()) || w.iter().chain(f.iter()).any(|x|!x.is_finite()) || (bounded && ids.nrows().saturating_mul(f.ncols())>2_000_000) {return Err(PyValueError::new_err("invalid bounded level interpolation"))}
 let mut out=vec![vec![0.;f.ncols()];ids.nrows()];
 for i in 0..ids.nrows(){let mut sum=0.0f32;for j in 0..4{let id=ids[[i,j]];if id==u32::MAX{break}let weight=w[[i,j]];sum+=weight;for b in 0..f.ncols(){out[i][b]+=weight*f[[id as usize,b]];}}if sum>0. {let inv=1.0f32/sum;for v in &mut out[i]{*v*=inv;}}}
 Ok(out)
}

#[pyfunction]
pub fn interpolate_level_array<'py>(py:Python<'py>,ids:numpy::PyReadonlyArray2<'py,u32>,weights:numpy::PyReadonlyArray2<'py,f32>,fields:numpy::PyReadonlyArray2<'py,f32>)->PyResult<Bound<'py,numpy::PyArray2<f32>>>{
 let width=fields.as_array().ncols();
 let output=interpolate_owned(ids,weights,fields,false)?;
 crate::field_arrays::owned_rows(py,output,width)
}

/// Public adaptive transport: interpolate one row then select its sparse slots.
/// Arithmetic/order and stable tie selection are shared with existing kernels;
/// no full fine-level dense matrix or Python row/scalar staging is allocated.
#[pyfunction]
pub fn interpolate_sparse_arrays<'py>(py:Python<'py>,ids:numpy::PyReadonlyArray2<'py,u32>,weights:numpy::PyReadonlyArray2<'py,f32>,fields:numpy::PyReadonlyArray2<'py,f32>,seeds:numpy::PyReadonlyArray1<'py,u32>,slots:usize)->PyResult<(Bound<'py,numpy::PyArray2<u16>>,Bound<'py,numpy::PyArray2<f32>>)>{
 let ids=ids.as_array();let w=weights.as_array();let f=fields.as_array();let seeds=seeds.as_array();let n=ids.nrows();let width=f.ncols();
 if ids.ncols()!=4 || ids.shape()!=w.shape() || seeds.len()!=n || ids.iter().any(|&i|i!=u32::MAX && i as usize>=f.nrows()) || w.iter().chain(f.iter()).any(|x|!x.is_finite()) {return Err(PyValueError::new_err("invalid bounded level interpolation"))}
 if slots==0 || slots>16 || width>65534 || seeds.iter().any(|&s|s!=u32::MAX && s>=65535){return Err(PyValueError::new_err("invalid bounded sparse field"))}
 let count=crate::compact_fields::allocation_len(n,slots,std::mem::size_of::<f32>())?;
 let (groups,initial)=py.allow_threads(|| -> PyResult<_> {
 let mut groups=vec![u16::MAX;count];let mut initial=vec![0f32;count];let block=n.div_ceil(4).max(32);let chunk=block*slots;
 let run=|(batch,(og,ov)):(usize,(&mut[u16],&mut[f32]))|->PyResult<()> {
  let mut row=vec![0.0f32;width];
  for offset in 0..og.len()/slots {let i=batch*block+offset;
   if i%1024==0{crate::cancel::check();}row.fill(0.);let mut sum=0.0f32;
   for j in 0..4{let id=ids[[i,j]];if id==u32::MAX{break}let weight=w[[i,j]];sum+=weight;for (dst,&source) in row.iter_mut().zip(f.row(id as usize).iter()){*dst+=weight*source;}}
   if sum>0.{let inv=1.0f32/sum;for v in &mut row{*v*=inv;}}
   let (g,v)=sparse_seed_slots(row.clone(),slots,seeds[i])?;
   og[offset*slots..(offset+1)*slots].copy_from_slice(&g);ov[offset*slots..(offset+1)*slots].copy_from_slice(&v);
  }Ok(())
 };
 if n>=128 && width<=16384 {groups.par_chunks_mut(chunk).zip(initial.par_chunks_mut(chunk)).enumerate().try_for_each(run)?;}
 else {for batch in groups.chunks_mut(chunk).zip(initial.chunks_mut(chunk)).enumerate(){run(batch)?;}}
 Ok((groups,initial))

 })?;
 let g=ndarray::Array2::from_shape_vec((n,slots),groups).map_err(|e|PyValueError::new_err(e.to_string()))?;
 let v=ndarray::Array2::from_shape_vec((n,slots),initial).map_err(|e|PyValueError::new_err(e.to_string()))?;
 Ok((numpy::PyArray2::from_owned_array(py,g),numpy::PyArray2::from_owned_array(py,v)))
}
