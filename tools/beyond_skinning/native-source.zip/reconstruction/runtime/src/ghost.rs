//! Five-direction ghost culling from 0xaaaf4 / 0x70f38 / 0x17b6a4.
use pyo3::{prelude::*,exceptions::PyValueError};
use numpy::{PyReadonlyArray2,PyUntypedArrayMethods};
use rustc_hash::FxHashMap;
use rayon::prelude::*;
#[pyfunction]
#[pyo3(signature=(verts,faces,points,levels,minimum,maximum,cell,multiplier,bounded=true))]
pub fn ghost_cull(py:Python<'_>,verts:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,points:PyReadonlyArray2<'_,f32>,levels:Vec<u8>,minimum:[f32;3],maximum:[f32;3],cell:f32,multiplier:u32,bounded:bool)->PyResult<(Vec<u8>,Vec<usize>)>{
 let n=points.shape()[0];if points.shape()[1]!=3 || levels.len()!=n || (bounded && n>2000000) || (bounded && !cell.is_finite()) || cell<=0.0 || multiplier<1 || (bounded && multiplier>16) || (bounded && (minimum.iter().chain(&maximum).any(|x|!x.is_finite()) || points.as_array().iter().any(|x|!x.is_finite()))){return Err(PyValueError::new_err("invalid ghost cull inputs"));}
 let bvh=crate::bvh::MeshBvh::new(py,verts,faces)?;let points:Vec<[f32;3]>=points.as_array().rows().into_iter().map(|r|[r[0],r[1],r[2]]).collect();let half:Vec<f32>=levels.iter().map(|&l|(cell*0.5)/(multiplier as f32).powi(l as i32)).collect();
 py.allow_threads(move || {
 let mut keep=vec![1u8;n];let mut counts=Vec::new();
 for (axis,sign) in [(2usize,-1.0f32),(0,-1.0),(0,1.0),(1,-1.0),(1,1.0)]{
  let other:Vec<_>=(0..3).filter(|&k|k!=axis).collect();let mut groups=FxHashMap::<(u32,u32),Vec<usize>>::default();
  for (i,p) in points.iter().enumerate(){if keep[i]!=0{groups.entry((p[other[0]].to_bits(),p[other[1]].to_bits())).or_default().push(i);}}
  let start=if sign<0.0{cell+maximum[axis]}else{minimum[axis]-cell};let mut dir=[0.0;3];dir[axis]=sign;// Groups are independent within a direction. Restore original key order
  // before bounded parallel chunks; publish removals only after the direction.
  let mut groups:Vec<_>=groups.into_iter().collect();groups.sort_unstable_by_key(|(key,_)|*key);
  let removed:Vec<Vec<usize>>=groups.par_chunks(128).map(|chunk|{
   let mut removed=Vec::new();
   for (_,ids) in chunk{let mut origin=points[ids[0]];origin[axis]=start;let r=ids.iter().map(|&i|half[i]).fold(0.0f32,f32::max);
   let hit=if let Some((distance,_))=bvh.raycast(origin,dir){Some(distance)}else{let mut hit=None;for (a,b) in [(-1.0,-1.0),(-1.0,1.0),(1.0,-1.0),(1.0,1.0)]{let mut q=origin;q[other[0]]=if a<0.0{q[other[0]]-r}else{r+q[other[0]]};q[other[1]]=if b<0.0{q[other[1]]-r}else{r+q[other[1]]};if let Some((d,_))=bvh.raycast(q,dir){hit=Some(hit.map_or(d,|v:f32|v.min(d)));}}hit};
   for &i in ids{let remove=match hit{None=>true,Some(d)=>sign*(points[i][axis]-start)<d-(half[i]+half[i]) && !bvh.within_mesh(points[i],half[i]*1.75)};if remove{removed.push(i);}}
  }
   removed
  }).collect();
  counts.push(removed.iter().map(Vec::len).sum());for part in removed{for i in part{keep[i]=0;}}
 }
 Ok((keep,counts))
 })
}
