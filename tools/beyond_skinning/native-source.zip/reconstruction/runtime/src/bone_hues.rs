//! Recovered public 0x10d6c0 and largest circular-gap allocator 0x916d4.
use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use numpy::{PyReadonlyArray1,PyArray1,IntoPyArray};
use std::collections::{HashMap,VecDeque};
fn golden(i:usize)->f64{((i as f64)*0.618033988749895).fract()}
#[pyfunction]
#[pyo3(signature=(names,bone_names=None,bone_parents=None))]
pub fn bone_hues<'py>(py:Python<'py>,names:Vec<String>,bone_names:Option<Vec<String>>,bone_parents:Option<PyReadonlyArray1<'py,i64>>)->PyResult<Bound<'py,PyArray1<f64>>>{
 let parents=bone_parents.map(|p|crate::array_input::owned_one(&p).to_vec());
 if bone_names.is_some()!=parents.is_some() || bone_names.as_ref().zip(parents.as_ref()).is_some_and(|(n,p)|n.len()!=p.len()){return Err(PyValueError::new_err("bone_names and bone_parents go together, same length"));}
 let out=py.allow_threads(move||{
  let mut by_name=HashMap::new();
  if let Some((bn,pa))=bone_names.zip(parents){
   let n=bn.len();let mut children=vec![Vec::new();n];let mut queue=VecDeque::new();
   for (i,&p) in pa.iter().enumerate(){if p<0 || p as u64>=n as u64 {queue.push_back(i);}else{children[p as usize].push(i);}}
   let mut assigned=vec![None;n];let mut sorted:Vec<f64>=Vec::new();
   // Roots and then each breadth-first sibling list share one global hue pool.
   while let Some(i)=queue.pop_front(){
    let hue=if sorted.is_empty(){0.0}else if sorted.len()==1{(sorted[0]+0.5).fract()}else{
     let mut largest=-1.0;let mut hue=0.0;
     for j in 0..sorted.len(){let next=if j+1==sorted.len(){sorted[0]+1.0}else{sorted[j+1]};let gap=next-sorted[j];if gap>largest{largest=gap;hue=(sorted[j]+gap*0.5).fract();}}
     hue
    };
    sorted.insert(sorted.partition_point(|&x|x<=hue),hue);assigned[i]=Some(hue);queue.extend(children[i].iter().copied());
   }
   for (name,hue) in bn.into_iter().zip(assigned){if let Some(hue)=hue{by_name.insert(name,hue);}}
  }
  let mut missing=0;names.iter().map(|n|if let Some(&h)=by_name.get(n){h}else{missing+=1;golden(missing)}).collect::<Vec<_>>()
 });Ok(ndarray::Array1::from_vec(out).into_pyarray(py))
}
