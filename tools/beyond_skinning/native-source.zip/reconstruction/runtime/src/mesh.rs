//! Joined solve body and evaluated-to-base correspondence (0x141450/0x13f040).
use numpy::{PyArray1,PyArray2,PyReadonlyArray2,PyUntypedArrayMethods};
use pyo3::{exceptions::PyValueError,prelude::*,types::{PyDict,PyList}};
// Edge dedup is membership-only; the original does not consume the smoothing
// RandomState stream, even for a nonempty join. Never add a random hasher here.
use rustc_hash::FxHashSet;
// Standalone join uses field-aware enum extraction; bind's positional adapter
// has a distinct public error contract and deliberately remains separate.
#[derive(FromPyObject)]
pub enum MeshPartArg<'py> {
 Flagged(PyReadonlyArray2<'py,f32>,PyReadonlyArray2<'py,i32>,Option<PyReadonlyArray2<'py,f32>>,Option<PyReadonlyArray2<'py,f32>>,bool),
 Plain(PyReadonlyArray2<'py,f32>,PyReadonlyArray2<'py,i32>,Option<PyReadonlyArray2<'py,f32>>,Option<PyReadonlyArray2<'py,f32>>),
}
impl<'py> MeshPartArg<'py> {
 fn flagged(self)->(PyReadonlyArray2<'py,f32>,PyReadonlyArray2<'py,i32>,Option<PyReadonlyArray2<'py,f32>>,Option<PyReadonlyArray2<'py,f32>>,bool){
  match self {Self::Flagged(a,b,c,d,e)=>(a,b,c,d,e),Self::Plain(a,b,c,d)=>(a,b,c,d,false)}
 }
}
use crate::array_input::two;
#[pyfunction]
pub fn join_meshes<'py>(py:Python<'py>,meshes:Vec<MeshPartArg<'py>>)->PyResult<Bound<'py,PyDict>> {
 let meshes:Vec<_>=meshes.into_iter().map(MeshPartArg::flagged).collect();
 // Array metadata is validated for every part before topology is traversed.
 // This preserves original cross-part error priority without copying inputs.
 for (index,(v,f,base,matrix,_)) in meshes.iter().enumerate(){
  if v.shape()[1]!=3 || f.shape()[1]!=3{return Err(PyValueError::new_err(format!("[invalid_mesh] mesh {index}: vertices and faces must be (N, 3)")));}
  if base.is_some()!=matrix.is_some(){return Err(PyValueError::new_err(format!("mesh {index}: pass the base vertices and the world matrix together")));}
  if let (Some(base),Some(matrix))=(base,matrix){if base.shape()[1]!=3 || matrix.shape()!=[4,4]{return Err(PyValueError::new_err(format!("[invalid_mesh] mesh {index}: base vertices must be (V, 3), the matrix (4, 4)")));}}
 }
 let mut verts=Vec::<[f32;3]>::new();let mut faces=Vec::<[i32;3]>::new();let mut bases=Vec::new();
 for (index,(v,f,base,matrix,base_first)) in meshes.iter().enumerate(){
  let v=two(v);let f=two(f);
  let offset=verts.len();if offset.checked_add(v.nrows()).is_none_or(|n|n>i32::MAX as usize){return Err(PyValueError::new_err("joined mesh exceeds index capacity"));}
  for triangle in f.rows(){for &j in triangle{if j<0 || j as usize>=v.nrows(){return Err(PyValueError::new_err(format!("[invalid_mesh] mesh {index}: face index out of range {:?} ({} vertices)",triangle.to_vec(),v.nrows())));}}
   faces.push(std::array::from_fn(|axis|triangle[axis]+offset as i32));
  }
  verts.extend(v.rows().into_iter().map(|r|[r[0],r[1],r[2]]));
  let mapped=if let (Some(base),Some(matrix))=(base,matrix){let base=two(base);let matrix=two(matrix);
   if base.nrows()==v.nrows() || (*base_first && base.nrows()<=v.nrows()){Some((true,(0..base.nrows()).map(|i|[v[(i,0)],v[(i,1)],v[(i,2)]]).collect::<Vec<_>>(),offset))}
   else{Some((false,base.rows().into_iter().map(|r|std::array::from_fn(|axis|((matrix[(axis,0)]*r[0]) as f64+0.0+(matrix[(axis,1)]*r[1]) as f64+(matrix[(axis,2)]*r[2]) as f64+matrix[(axis,3)] as f64) as f32)).collect::<Vec<_>>(),offset))}
  }else{None};bases.push(mapped);
 }
 let (edges,mappings)=py.allow_threads(||{
  let count=if faces.len()<1000{1}else{8};let mut seen=FxHashSet::default();let mut buckets=vec![Vec::<[i64;2]>::new();count];
  for f in &faces{for i in 0..3{let a=f[(i+2)%3];let b=f[i];if a==b{continue;}let edge=[a.min(b) as i64,a.max(b) as i64];if seen.insert(edge){buckets[edge[0] as usize&(count-1)].push(edge);}}}
  let edges:Vec<_>=buckets.into_iter().flatten().collect();
  let tree=if bases.iter().any(Option::is_some) && !verts.is_empty(){Some(crate::tree::VertexTree::from_points(&verts))}else{None};
  let mappings:Vec<Option<Vec<u32>>>=bases.into_iter().map(|base|base.and_then(|(fast,points,offset)|tree.as_ref().map(|tree|points.iter().enumerate().map(|(i,&p)|if fast && verts[offset+i]==p{(offset+i) as u32}else{tree.nearest(p)}).collect()))).collect();(edges,mappings)
 });
 let out=PyDict::new(py);let mappings_py=PyList::empty(py);for m in mappings{if let Some(m)=m{mappings_py.append(PyArray1::from_vec(py,m))?;}else{mappings_py.append(py.None())?;}}
 let mut positions=ndarray::Array2::zeros((verts.len(),3));for (i,v) in verts.iter().enumerate(){for a in 0..3{positions[(i,a)]=v[a]+0.0;}}
 let mut triangles=ndarray::Array2::zeros((faces.len(),3));for (i,f) in faces.iter().enumerate(){for a in 0..3{triangles[(i,a)]=f[a];}}
 let mut edge_array=ndarray::Array2::zeros((edges.len(),2));for (i,e) in edges.iter().enumerate(){edge_array[(i,0)]=e[0];edge_array[(i,1)]=e[1];}
 out.set_item("verts",PyArray2::from_owned_array(py,positions))?;out.set_item("faces",PyArray2::from_owned_array(py,triangles))?;out.set_item("edges",PyArray2::from_owned_array(py,edge_array))?;out.set_item("base_to_body",mappings_py)?;Ok(out)
}
