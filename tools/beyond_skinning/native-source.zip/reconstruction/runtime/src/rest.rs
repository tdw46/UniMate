//! Rest-space outlier filter reconstructed from the original public wrapper.
use numpy::{PyReadonlyArray2,PyUntypedArrayMethods};
use pyo3::{exceptions::PyValueError, prelude::*};
fn stats(points:ndarray::ArrayView2<'_,f32>)->([f32;3], [f32;3]) {
 let mut lo=[points[(0,0)],points[(0,1)],points[(0,2)]];
 let mut hi=lo;let mut sum=lo;
 for p in points.rows().into_iter().skip(1){for j in 0..3 {
  // The native comparisons propagate the incoming NaN at this point.
  lo[j]=if p[j].is_nan() || p[j]<lo[j] {p[j]}else{lo[j]};
  hi[j]=if p[j].is_nan() || p[j]>hi[j] {p[j]}else{hi[j]};
  sum[j]+=p[j];
 }}
 (std::array::from_fn(|j|hi[j]-lo[j]),std::array::from_fn(|j|(sum[j] as f64/points.nrows() as f64) as f32))
}
#[pyfunction]
pub fn rest_space_keep(bone_points:PyReadonlyArray2<'_,f32>,meshes:Vec<PyReadonlyArray2<'_,f32>>)->PyResult<Vec<Option<bool>>> {
 // Validate all metadata before reading/copying any potentially unaligned data.
 if bone_points.shape()[1]!=3 || meshes.iter().any(|m|m.shape()[1]!=3){return Err(PyValueError::new_err("bone_points and every mesh must be (N, 3)"));}
 let points=crate::array_input::two(&bone_points);
 let bone_stats=if points.nrows()==0{None}else{Some(stats(points.view()))};
 Ok(meshes.iter().map(|m|{
  if m.shape()[0]==0{return None;}
  let Some((span,center))=bone_stats else{return Some(true);};
  let a=crate::array_input::two(m);
  let (mspan,mcenter)=stats(a.view());
  let bone_size=(span[1]*span[1]+(span[0]*span[0]+span[2]*span[2])).sqrt() as f64;
  let mesh_size=(mspan[1]*mspan[1]+(mspan[0]*mspan[0]+mspan[2]*mspan[2])).sqrt() as f64;
  let d=std::array::from_fn::<_,3,_>(|j|mcenter[j]-center[j]);
  let distance=(d[1]*d[1]+(d[2]*d[2]+d[0]*d[0])).sqrt() as f64;
  Some(!(bone_size*10.<mesh_size) && !(bone_size+bone_size<distance))
 }).collect())
}
