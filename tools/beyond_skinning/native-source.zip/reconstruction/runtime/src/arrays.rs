//! Recovered public array types. Storage is owned; borrowed NumPy input never escapes.
use numpy::{PyArray1, PyArray2, PyReadonlyArray1, PyReadonlyArray2, PyUntypedArrayMethods};
use pyo3::{exceptions::PyValueError, prelude::*};
#[pyclass(module = "_bvt_solver")]
pub struct VoxelCloud {
    positions: ndarray::Array2<f32>,
    levels: Vec<u8>,
    radii: Vec<f32>,
}
#[pymethods]
impl VoxelCloud {
    #[new]
    fn new(
        positions: PyReadonlyArray2<'_, f32>,
        levels: PyReadonlyArray1<'_, u8>,
        radii: PyReadonlyArray1<'_, f32>,
    ) -> PyResult<Self> {
        let shape = positions.shape();
        if shape[1] != 3 {
            return Err(PyValueError::new_err(format!(
                "positions must have shape (N, 3), got {:?}",
                shape
            )));
        }
        if shape[0] != levels.len() || shape[0] != radii.len() {
            return Err(PyValueError::new_err(
                "positions, levels and radii must share length",
            ));
        }
        // Match NumPy/ndarray logical element ordering, while allowing
        // unaligned data without creating invalid Rust references.
        let p=crate::array_input::two(&positions);
        let l=crate::array_input::one(&levels);
        let r=crate::array_input::one(&radii);
        let point_values=p.iter().copied().collect();
        let level_values=l.iter().copied().collect();
        let radius_values=r.iter().copied().collect();
        Ok(Self {
            positions: ndarray::Array2::from_shape_vec((shape[0],3),point_values)
                .expect("validated point shape"),
            levels: level_values,
            radii: radius_values,
        })
    }
    #[getter]
    fn n_points(&self) -> usize {
        self.positions.nrows()
    }
    fn positions<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<f32>> {
        PyArray2::from_owned_array(py, self.positions.clone())
    }
    fn levels<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<u8>> {
        if self.levels.is_empty() { return PyArray1::from_owned_array(py,ndarray::Array1::zeros(0)); }
        PyArray1::from_vec(py, self.levels.clone())
    }
    fn radii<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f32>> {
        if self.radii.is_empty() { return PyArray1::from_owned_array(py,ndarray::Array1::zeros(0)); }
        PyArray1::from_vec(py, self.radii.clone())
    }
}
fn spread(mut v: u64) -> u64 {
    v = (((v & 0xff00) << 16) | (v << 32) | (v & 0xff)) & 0x1f0000ff0000ff;
    v = (v | v << 8) & 0x100f00f00f00f00f;
    v = (v | v << 4) & 0x10c30c30c30c30c3;
    (v | v << 2) & 0x1249249249249249
}
#[pyfunction]
pub fn morton_order<'py>(
    py: Python<'py>,
    positions: PyReadonlyArray2<'py, f32>,
) -> PyResult<Bound<'py, PyArray1<u32>>> {
    crate::cancel::check();
    if positions.shape()[0] != 0 && positions.shape()[1] != 3 {
        return Err(PyValueError::new_err("positions must be (N,3)"));
    }
    let a = crate::array_input::owned_two(&positions);
    let indices = py.allow_threads(move || {
    let mut lo = [f32::INFINITY; 3];
    let mut hi = [f32::NEG_INFINITY; 3];
    for row in a.rows() {
        for axis in 0..3 {
            lo[axis] = lo[axis].min(row[axis]);
            hi[axis] = hi[axis].max(row[axis]);
        }
    }
    let scale = std::array::from_fn::<_, 3, _>(|i| {
        if hi[i] > lo[i] {
            2097151.0f32 / (hi[i] - lo[i])
        } else {
            0.0
        }
    });
    let mut entries = Vec::with_capacity(a.nrows());
    for (i, row) in a.rows().into_iter().enumerate() {
        let mut code = 0u64;
        for axis in 0..3 {
            let mut q = (row[axis] - lo[axis]) * scale[axis];
            if q < 0.0 {
                q = 0.0
            }
            if q > 2097151.0 {
                q = 2097151.0
            }
            code |= spread(q as u64) << axis;
        }
        entries.push((code, i as u32));
    }
    entries.sort_unstable();
    entries.into_iter().map(|(_, i)| i).collect()
    });
    Ok(PyArray1::from_vec(py, indices))
}
