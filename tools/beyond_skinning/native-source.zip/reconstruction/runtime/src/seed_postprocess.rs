//! Custom priority, exclusion and parent field stages, inline 0x98138..0x9912c.
//! Takes independently supplied records/masks; not automatic shape construction.
use pyo3::{prelude::*,types::PyDict,exceptions::PyValueError};
use numpy::{PyReadonlyArray2,PyUntypedArrayMethods,PyArray1};
use crate::seed_shapes::Shape;
use rayon::prelude::*;
type Stage=(Vec<u8>,Vec<u32>);
#[pyfunction]
#[pyo3(signature=(points,masks,priorities,custom_shapes,array_output=false))]
pub fn custom_seed_field(py:Python<'_>,points:PyReadonlyArray2<'_,f32>,masks:PyReadonlyArray2<'_,u8>,priorities:Vec<f32>,custom_shapes:Vec<Bound<'_,PyDict>>,array_output:bool)->PyResult<PyObject>{
 let n=points.shape()[0];let b=masks.shape()[0];
 if points.shape()[1]!=3 || masks.shape()[1]!=n || priorities.len()!=b || custom_shapes.len()!=b || priorities.iter().any(|x|!x.is_finite()) || b*n>10000000{return Err(PyValueError::new_err("invalid custom seed field dimensions or priorities"));}
 let ps=points.as_array();let ms=masks.as_array();if ps.iter().any(|x|!x.is_finite()) || ms.outer_iter().any(|row|row.iter().any(|&x|x>1)){return Err(PyValueError::new_err("invalid custom seed field data"));}
 let shapes:Vec<_>=custom_shapes.iter().map(Shape::decode).collect::<PyResult<_>>()?;
 // Curve masks may carry a separate profile for these field stages.
 // Require that profile instead of inventing missing record metadata.
 if shapes.iter().any(|s|matches!(s,Shape::Curve{profile:None,..})){return Err(PyValueError::new_err("curve seed postprocessing requires unrecovered combined profile records"));}
 let mut fixed=vec![0u8;n];let mut ids=vec![u32::MAX;n];let mut best=vec![f32::INFINITY;n];
 // Independent point blocks retain the original bone-priority visitation order.
 // At most four workers share borrowed read-only masks; no additional mask copy.
 let block=n.div_ceil(4).max(1);
 let run=|(chunk,((fixed,ids),best)):(usize,((&mut [u8],&mut [u32]),&mut [f32]))|{
  let begin=chunk*block;let end=begin+fixed.len();
  for (j,mask) in ms.outer_iter().enumerate(){let mask=mask.slice(ndarray::s![begin..end]);
   if let Some(bytes)=mask.as_slice(){
    // Masks have already been validated as bytes 0/1. Skip eight empty
    // entries together, then visit only set bytes in ascending point order.
    // No output is touched for a zero byte, just as in the scalar path.
    let mut chunks=bytes.chunks_exact(8);
    for (packet,chunk) in (&mut chunks).enumerate(){
     let mut bits=u64::from_le_bytes(chunk.try_into().unwrap());
     while bits!=0{let i=packet*8+(bits.trailing_zeros() as usize/8);bits&=bits-1;
      fixed[i]=1;if priorities[j]<best[i]{best[i]=priorities[j];ids[i]=j as u32;}
     }
    }
    let begin=bytes.len()/8*8;
    for (offset,&hit) in chunks.remainder().iter().enumerate(){let i=begin+offset;
     if hit!=0{fixed[i]=1;if priorities[j]<best[i]{best[i]=priorities[j];ids[i]=j as u32;}}
    }
   }else{
    for (((&hit,fixed),best),id) in mask.iter().zip(fixed.iter_mut()).zip(best.iter_mut()).zip(ids.iter_mut()){
     if hit!=0{*fixed=1;if priorities[j]<*best{*best=priorities[j];*id=j as u32;}}
    }
   }
  }
 };
 // Retain the GIL while workers borrow caller-owned mutable arrays, as the
 // previous serial entrypoint did. Workers access no Python objects.
 {
  if n>=1024{fixed.par_chunks_mut(block).zip(ids.par_chunks_mut(block)).zip(best.par_chunks_mut(block)).enumerate().for_each(run);}
  else{fixed.chunks_mut(block).zip(ids.chunks_mut(block)).zip(best.chunks_mut(block)).enumerate().for_each(run);}
 }
 let mut touched=vec![0u8;n];let mut protected=vec![0u8;n];let mut flags=vec![0u8;n];
 for pass in [1u8,0u8]{for (j,s) in shapes.iter().enumerate(){
  if matches!(s,Shape::None) || (matches!(s,Shape::Box{..}) as u8)==pass{continue;}
  for i in 0..n{if ms[[j,i]]==0 || (pass==0 && flags[i]&1!=0){continue;}touched[i]=1;
   if s.priority_hit([ps[[i,0]],ps[[i,1]],ps[[i,2]]]){ids[i]=j as u32;protected[i]=1;flags[i]|=pass;}
  }
 }}
 for i in 0..n{if touched[i]!=0 && protected[i]==0{ids[i]=u32::MAX;fixed[i]=0;}}
 let priority=(!array_output).then(||(fixed.clone(),ids.clone()));
 for s in &shapes{if matches!(s,Shape::None|Shape::Box{..}){continue;}for i in 0..n{if fixed[i]!=0 && protected[i]==0 && s.exclusion_hit([ps[[i,0]],ps[[i,1]],ps[[i,2]]]){ids[i]=u32::MAX;fixed[i]=0;}}}
 let exclusion=(!array_output).then(||(fixed.clone(),ids.clone()));
 for (s,d) in shapes.iter().zip(custom_shapes){
  let nested=d.get_item("profile")?;let d=if let Some(ref nested)=nested{nested.downcast::<PyDict>()?}else{&d};
  let kind:u64=d.get_item("record_kind")?.map(|x|x.extract()).transpose()?.unwrap_or(0);
  if kind>1{return Err(PyValueError::new_err("invalid profile record kind"));}
  if kind!=1{continue;}
  let parent:usize=d.get_item("parent")?.map(|x|x.extract()).transpose()?.unwrap_or(0);
  let depth:f32=d.get_item("parent_depth")?.map(|x|x.extract()).transpose()?.unwrap_or(0.0);
  let width:f32=d.get_item("parent_width")?.map(|x|x.extract()).transpose()?.unwrap_or(0.0);
  if !depth.is_finite() || !width.is_finite(){return Err(PyValueError::new_err("nonfinite parent limits"));}
  if parent>=b{continue;}
  for i in 0..n{if touched[i]==0 && s.parent_hit([ps[[i,0]],ps[[i,1]],ps[[i,2]]],depth,width){ids[i]=parent as u32;fixed[i]=1;}}
 }
 if array_output {
  // Transfer final owned vectors directly; the ordinary bind never consumes
  // the diagnostic intermediate stages or Python scalar lists.
  Ok((PyArray1::from_vec(py,fixed),PyArray1::from_vec(py,ids),PyArray1::from_vec(py,touched),PyArray1::from_vec(py,protected)).into_pyobject(py)?.into_any().unbind())
 }else{Ok((priority.unwrap(),exclusion.unwrap(),(fixed,ids),touched,protected).into_pyobject(py)?.into_any().unbind())}
}

/// Trunk radial fade and lateral principal direction, inline 0x99548..0x9abf8.
#[pyfunction]
#[pyo3(signature=(points,heads,tails,labels,trunk,edge,lateral,power,bounded=true))]
pub fn seed_strengths(points:Vec<[f32;3]>,heads:Vec<[f32;3]>,tails:Vec<[f32;3]>,labels:Vec<u32>,trunk:Vec<u8>,edge:f32,lateral:f32,power:f32,bounded:bool)->PyResult<(Vec<f32>,Option<[f32;3]>)>{
 let n=points.len();let b=heads.len();
 if labels.len()!=n || tails.len()!=b || trunk.len()!=b || trunk.iter().any(|&x|x>1) || points.iter().chain(&heads).chain(&tails).flatten().any(|x|!x.is_finite()) || (bounded && (![edge,lateral,power].iter().all(|x|x.is_finite()) || !(0.0..=1.0).contains(&edge) || !(0.0..=1.0).contains(&lateral) || power<0.0)){return Err(PyValueError::new_err("invalid seed strength inputs"));}
 let dot=|a:[f32;3],b:[f32;3]|(a[0]*b[0]+a[1]*b[1])+a[2]*b[2];
 let mut axis=None;
 if lateral>0.0{
  let mut direction=[0.0;3];
  for j in 0..b{if trunk[j]==1{let delta=std::array::from_fn(|k|tails[j][k]-heads[j][k]);let length=dot(delta,delta).sqrt();if length>1e-9{for k in 0..3{direction[k]=delta[k]/length+direction[k];}}}}
  let len=dot(direction,direction).sqrt();
  if len>1e-9{let d=direction.map(|x|x/len);let proj=(d[0]+d[1]*0.0)+d[2]*0.0;let mut u=[1.0-d[0]*proj,0.0-d[1]*proj,0.0-d[2]*proj];let mut norm=u[2]*u[2]+(u[0]*u[0]+u[1]*u[1]);
   if norm<1e-6{let proj=(d[1]+d[0]*0.0)+d[2]*0.0;u=[0.0-d[0]*proj,1.0-d[1]*proj,0.0-d[2]*proj];norm=u[2]*u[2]+(u[1]*u[1]+u[0]*u[0]);}
   let norm=norm.sqrt();u=u.map(|x|x/norm);let v=[d[1]*u[2]-d[2]*u[1],d[2]*u[0]-d[0]*u[2],d[0]*u[1]-d[1]*u[0]];
   let (mut aa,mut ab,mut bb,mut count)=(0.0f32,0.0f32,0.0f32,0usize);
   for j in 0..b{if trunk[j]==0{let x=dot(u,heads[j]);let y=dot(v,heads[j]);aa+=x*x;ab+=x*y;bb+=y*y;count+=1;}}
   if count>=2{let (x,y)=if ab.abs()<=1e-9{if aa>=bb{(1.0,0.0)}else{(0.0,1.0)}}else{let sum=aa+bb;let discriminant=((ab*ab-aa*bb)+sum*sum*0.25).max(0.0);((sum*0.5+discriminant.sqrt())-bb,ab)};
    let a=std::array::from_fn(|k|v[k]*y+u[k]*x);let norm=(a[2]*a[2]+(a[0]*a[0]+a[1]*a[1])).sqrt();if norm>=1e-9{axis=Some(a.map(|x|x/norm));}
   }
  }
 }
 let mut radii=vec![0.0f32;n];let mut offsets=vec![[0.0;3];n];let mut maximum=vec![0.0f32;b];
 for (i,&j) in labels.iter().enumerate(){let j=j as usize;if j>=b || trunk[j]==0{continue;}
  let d=std::array::from_fn(|k|tails[j][k]-heads[j][k]);let p=std::array::from_fn(|k|points[i][k]-heads[j][k]);let len=dot(d,d);let t=if len>1e-12{(dot(p,d)/len).clamp(0.0,1.0)}else{0.0};let q=std::array::from_fn(|k|p[k]-d[k]*t);let r=(q[2]*q[2]+(q[0]*q[0]+q[1]*q[1])).sqrt();radii[i]=r;offsets[i]=q;maximum[j]=maximum[j].max(r);
 }
 let mut values=vec![1.0;n];
 if edge<1.0{for (i,&j) in labels.iter().enumerate(){let j=j as usize;if j>=b || trunk[j]==0 || maximum[j]<=1e-8{continue;}let mut ratio=(radii[i]/maximum[j]).clamp(0.0,1.0);
  if let Some(a)=axis{let cosine=if radii[i]>1e-8{(dot(a,offsets[i])/radii[i]).abs()}else{0.0};ratio*= (1.0-lateral)+lateral*cosine.powf(power);}
  values[i]=1.0-(1.0-edge)*ratio;
 }}
 Ok((values,axis))
}

/// Dense field support cleanup: 0x5f5e4, 0x71ea0, 0x72478.
/// Finite bounded controls; this is not solver/level dispatch.
#[pyfunction]
#[pyo3(signature=(rows,columns,radii,fields,threshold,top_k,bounded=true))]
pub fn clean_dense_field(rows:Vec<u32>,columns:Vec<u32>,radii:Vec<f32>,fields:PyReadonlyArray2<'_,f32>,threshold:f32,top_k:usize,bounded:bool)->PyResult<Vec<Vec<f32>>>{
 use rustc_hash::FxHashMap;
 let f=fields.as_array();let n=f.nrows();let b=f.ncols();
 if b==0||(bounded && (b>256||n*b>2_000_000))||rows.len()!=n+1||rows.first()!=Some(&0)||rows.last().copied()!=Some(columns.len() as u32)||rows.windows(2).any(|x|x[0]>x[1])||columns.iter().any(|&x|x as usize>=n)||radii.len()!=n||radii.iter().any(|x|!x.is_finite()||*x<=0.)||(bounded && (f.iter().any(|x|!x.is_finite())||!threshold.is_finite()||threshold<0.))||top_k==0{return Err(PyValueError::new_err("invalid bounded dense cleanup inputs"));}
 let mut out:Vec<Vec<f32>>=f.rows().into_iter().map(|r|r.to_vec()).collect();
 fn root(p:&mut [usize],mut i:usize)->usize{while p[i]!=i{p[i]=p[p[i]];i=p[i];}i}
 for j in 0..b{
  let selected:Vec<usize>=(0..n).filter(|&i|out[i][j]>threshold).collect();if selected.len()<2{continue;}
  let mut lookup=vec![usize::MAX;n];for (k,&i) in selected.iter().enumerate(){lookup[i]=k;}
  let mut parent:Vec<_>=(0..selected.len()).collect();
  for (k,&i) in selected.iter().enumerate(){for e in rows[i]..rows[i+1]{let q=lookup[columns[e as usize] as usize];if q!=usize::MAX{let a=root(&mut parent,k);let z=root(&mut parent,q);if a!=z{parent[a]=z;}}}}
  let mut mass=FxHashMap::<u32,f64>::default();
  for (k,&i) in selected.iter().enumerate(){let r=radii[i] as f64;let v=((out[i][j] as f64*r)*r)*r;*mass.entry(root(&mut parent,k) as u32).or_default()+=v;}
  let mut winner=0;let mut largest=f64::NEG_INFINITY;
  for (&key,&v) in &mass{if v>=largest{largest=v;winner=key;}}
  for (k,&i) in selected.iter().enumerate(){if root(&mut parent,k) as u32!=winner{out[i][j]=0.;}}
 }
 let k=top_k.min(b).min(32);let bleed=0.25f32/k as f32;
 for row in &mut out{
  let largest=row.iter().copied().fold(0.0f32,f32::max).min(1.).max(f32::MIN_POSITIVE);let floor=threshold*largest;
  for w in row.iter_mut(){if *w>0.&&*w<=floor{*w=0.;}}
  let (ids,w)=crate::sampling::reduce_top_weights(row.clone(),k,bleed,!bounded)?;row.fill(0.);
  for (&i,&v) in ids.iter().zip(&w){if i>=0{row[i as usize]=v;}}
 }
 Ok(out)
}

/// Owned array transport for the admitted public pipeline; same cleanup arithmetic.
#[pyfunction]
pub fn clean_dense_array<'py>(py:Python<'py>,rows:Vec<u32>,columns:Vec<u32>,radii:Vec<f32>,fields:PyReadonlyArray2<'py,f32>,threshold:f32,top_k:usize)->PyResult<Bound<'py,numpy::PyArray2<f32>>>{
 let width=fields.as_array().ncols();
 let output=clean_dense_field(rows,columns,radii,fields,threshold,top_k,false)?;
 crate::field_arrays::owned_rows(py,output,width)
}
