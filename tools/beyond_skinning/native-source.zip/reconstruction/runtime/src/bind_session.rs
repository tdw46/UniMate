//! Public lifecycle ownership. Cache algorithms remain in the independent research layer.
use pyo3::{prelude::*, panic::PanicException, types::PyDict};
use std::sync::Mutex;
use numpy::{PyReadonlyArray2, PyReadonlyArray1, PyArray2, PyArray1};
use pyo3::exceptions::PyValueError;
#[derive(Default)]
struct State { owner: Option<Py<PyAny>>, poisoned: bool }
#[pyclass(module = "_bvt_solver")]
pub struct BindSession { state: Mutex<State> }
impl BindSession {
    fn locked<T: Send, F>(&self, py: Python<'_>, f: F) -> PyResult<T>
    where F: for<'p> FnOnce(Python<'p>, &mut State) -> PyResult<T> + Send {
        // Never wait for another cache operation while retaining Python's GIL.
        py.allow_threads(|| {
            let mut state = self.state.lock().unwrap_or_else(|e|e.into_inner());
            Python::with_gil(|py| {
                if state.poisoned { return Err(PanicException::new_err("called `Result::unwrap()` on an `Err` value: PoisonError { .. }")); }
                let result=f(py,&mut state);
                if result.as_ref().err().is_some_and(|e|e.is_instance_of::<PanicException>(py)) { state.poisoned=true; }
                result
            })
        })
    }
    fn owner(py: Python<'_>, state: &mut State) -> PyResult<Py<PyAny>> {
        if state.owner.is_none() {
            let kw=PyDict::new(py);kw.set_item("interior_route","winding")?;kw.set_item("bounded_preparation",false)?;kw.set_item("bounded_cloud",false)?;
            let runtime=py.import("beyond_skinning._bvt_solver")?;
            state.owner=Some(py.import("beyond_skinning.session")?.getattr("ResearchBindSession")?.call((runtime,),Some(&kw))?.unbind());
        }
        Ok(state.owner.as_ref().unwrap().clone_ref(py))
    }
}
#[pymethods]
impl BindSession {
    #[new]
    fn new()->Self { Self { state:Mutex::new(State::default()) } }
    fn clear(&self,py:Python<'_>)->PyResult<()> {
        self.locked(py,|py,state|{
            if let Some(owner)=&state.owner { owner.bind(py).call_method0("clear")?; }
            Ok(())
        })
    }
    #[getter]
    fn _owner(&self,py:Python<'_>)->PyResult<Py<PyAny>> { self.locked(py,Self::owner) }
    // Internal adapter acquires the same session ownership for ordinary bind.
    fn _run_bind(&self,py:Python<'_>,function:Py<PyAny>,kwargs:Py<PyDict>)->PyResult<Py<PyAny>> {
        // Original bind owns cache results, not the session lock, between stages.
        let owner=self.locked(py,Self::owner)?;
        kwargs.bind(py).set_item("_owner",owner)?;
        function.bind(py).call((),Some(kwargs.bind(py))).map(Bound::unbind)
    }
    #[pyo3(signature=(verts, faces, bbox_min, bbox_max, coarse_res, refine_multiplier, max_depth, fill_interior, winding_threshold, ghost_cull, probe_multiplier=None, void_boxes=None, refine_boxes=None))]
    fn cloud_for(&self,py:Python<'_>,verts:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,bbox_min:[f32;3],bbox_max:[f32;3],coarse_res:u32,refine_multiplier:u32,max_depth:u32,fill_interior:bool,winding_threshold:f32,ghost_cull:bool,probe_multiplier:Option<u32>,void_boxes:Option<Vec<(u32,[i32;3],[i32;3])>>,refine_boxes:Option<Vec<(u32,[i32;3],[i32;3])>>)->PyResult<Py<PyAny>> {
        // Own aligned geometry before releasing the GIL; match ndarray stride semantics.
        let v=crate::array_input::two(&verts).into_owned();
        let f=crate::array_input::two(&faces).into_owned();
        let verts=PyArray2::from_owned_array(py,v).unbind();
        let faces=PyArray2::from_owned_array(py,f).unbind();
        // Own the adapter while geometry builds outside the session mutex.
        let owner=self.locked(py,Self::owner)?;
        let kw=PyDict::new(py);
        kw.set_item("coarse_res",coarse_res)?;kw.set_item("refine_multiplier",refine_multiplier)?;
        kw.set_item("max_depth",max_depth)?;kw.set_item("fill_interior",fill_interior)?;
        kw.set_item("winding_threshold",winding_threshold)?;kw.set_item("ghost_cull",ghost_cull)?;
        kw.set_item("probe_multiplier",probe_multiplier)?;kw.set_item("void_boxes",void_boxes)?;kw.set_item("refine_boxes",refine_boxes)?;
        owner.bind(py).call_method("cloud_for",(verts,faces,bbox_min,bbox_max),Some(&kw)).map(Bound::unbind)
    }

    fn bones_for(&self,py:Python<'_>,heads:PyReadonlyArray2<'_,f32>,tails:PyReadonlyArray2<'_,f32>,parent_idx:PyReadonlyArray1<'_,i64>,shape_cfg:String)->PyResult<Py<PyAny>> {
        // The original row conversion takes the first three columns before locking.
        let h=crate::array_input::two(&heads);let t=crate::array_input::two(&tails);
        for a in [&h,&t] { if a.nrows()>0 && a.ncols()<3 { return Err(PanicException::new_err("ndarray: index out of bounds")); } }
        let h=ndarray::Array2::from_shape_fn((h.nrows(),3),|(i,j)|h[[i,j]]);
        let t=ndarray::Array2::from_shape_fn((t.nrows(),3),|(i,j)|t[[i,j]]);
        let p=crate::array_input::one(&parent_idx).into_owned();let n=h.nrows();
        if n!=t.nrows() || n!=p.len() { return Err(PyValueError::new_err("heads, tails and parent_idx must share length")); }
        let invalid=p.iter().copied().find(|&v|v>=n as i64);
        let bucket=shape_cfg.split(',').map(|v|v.trim().parse::<i64>()).collect::<Result<Vec<_>,_>>().ok().filter(|v|v.len()==5).map(|v|v.into_iter().map(|x|x as u8).collect::<Vec<_>>());
        let h=PyArray2::from_owned_array(py,h).unbind();let t=PyArray2::from_owned_array(py,t).unbind();let p=PyArray1::from_owned_array(py,p).unbind();
        // Own the session adapter, not the cache lock, during preparation.
        // Input panics must not poison cache ownership.
        let owner=self.locked(py,Self::owner)?;
        if !owner.bind(py).getattr("_cloud")?.is_none() {
            if let Some(index)=invalid { return Err(PanicException::new_err(format!("index out of bounds: the len is {} but the index is {}",n,index))); }
        }
        let kw=PyDict::new(py);kw.set_item("_bucket",bucket)?;
        owner.bind(py).call_method("bones_for",(h,t,p,shape_cfg),Some(&kw)).map(Bound::unbind)

    }
}

/// Original geometry validation order (0xbaa1c), before any cache lookup.
#[pyfunction]
pub fn validate_cloud_geometry(verts:PyReadonlyArray2<'_,f32>,faces:PyReadonlyArray2<'_,i32>,bbox_min:[f32;3],bbox_max:[f32;3],coarse_res:u32,refine_multiplier:u32,probe_multiplier:u32)->PyResult<()> {
    let v=crate::array_input::two(&verts);let f=crate::array_input::two(&faces);
    if v.ncols()!=3 {return Err(PyValueError::new_err(format!("vertices must have shape (N, 3), got {:?}",v.shape())));}
    if f.ncols()!=3 {return Err(PyValueError::new_err(format!("faces must have shape (M, 3), got {:?}",f.shape())));}
    for a in 0..3 {if !(bbox_min[a]<bbox_max[a]) {return Err(PyValueError::new_err(format!("bbox axis {}: min ({}) must be strictly less than max ({})",a,bbox_min[a],bbox_max[a])));}}
    if coarse_res==0 || refine_multiplier==0 || probe_multiplier==0 {return Err(PyValueError::new_err("resolution, refine_multiplier and probe_l4_multiplier must be > 0"));}
    if !f.is_empty() {
        let lo=*f.iter().min().unwrap();let hi=*f.iter().max().unwrap();
        if lo<0 || hi as usize>=v.nrows() {return Err(PyValueError::new_err(format!("face indices out of range [0, {}): observed [{}, {}]",v.nrows(),lo,hi)));}
    }
    Ok(())
}
