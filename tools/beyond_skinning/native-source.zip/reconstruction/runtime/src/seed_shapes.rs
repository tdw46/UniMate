//! Mode 17 typed geometry reconstructed from 0x62aec, 0xd92e0, 0xe12a8.
//! Record construction from skeleton metadata remains a separate recovery gate.
use pyo3::{prelude::*,types::PyDict,exceptions::PyValueError};
type V=[f32;3];
fn dot(a:V,b:V)->f32{(a[0]*b[0]+a[1]*b[1])+a[2]*b[2]}
fn sub(a:V,b:V)->V{std::array::from_fn(|k|a[k]-b[k])}
fn cross(a:V,b:V)->V{[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
fn get<'py,T:FromPyObject<'py>>(d:&Bound<'py,PyDict>,key:&str)->PyResult<T>{d.get_item(key)?.ok_or_else(||PyValueError::new_err(format!("missing custom shape {key}")))?.extract()}
fn floats(d:&Bound<'_,PyDict>,key:&str)->PyResult<Vec<f32>>{let v:Vec<f32>=get(d,key)?;if v.iter().any(|v|!v.is_finite()){return Err(PyValueError::new_err("nonfinite custom shape"));}Ok(v)}
fn fixed<const N:usize>(d:&Bound<'_,PyDict>,key:&str)->PyResult<[f32;N]>{floats(d,key)?.try_into().map_err(|_|PyValueError::new_err("invalid custom shape dimensions"))}
pub enum Shape{
 None,
 Box{center:V,a:V,b:V,extents:V},
 Curve{points:Vec<V>,lengths:Vec<f32>,reference:V,bounds:[f32;5],fallback:V,profile:Option<Box<Shape>>},
 Profile{center:V,a:V,b:V,angles:Vec<f32>,radii:Vec<f32>,heights:Vec<f32>,lengths:Vec<f32>,params:[f32;14],plane:Option<[f32;6]>,sphere:Option<f32>,fallback:V},
}
impl Shape{
 pub fn decode(d:&Bound<'_,PyDict>)->PyResult<Self>{let kind:String=get(d,"kind")?;Ok(match kind.as_str(){
  "none"=>Self::None,
  "box"=>Self::Box{center:fixed(d,"center")?,a:fixed(d,"axis")?,b:fixed(d,"lateral")?,extents:fixed(d,"extents")?},
  "curve"=>{let ps=floats(d,"points")?;let lengths=floats(d,"lengths")?;if ps.len()%3!=0 || lengths.len()!=ps.len()/3 || lengths.len()>100000{return Err(PyValueError::new_err("invalid custom curve arrays"));}let profile=if let Some(value)=d.get_item("profile")?{let value=value.downcast::<PyDict>()?;let p=Self::decode(value)?;if !matches!(p,Self::Profile{..}){return Err(PyValueError::new_err("combined curve requires profile geometry"));}Some(Box::new(p))}else{None};Self::Curve{profile,points:ps.chunks_exact(3).map(|p|[p[0],p[1],p[2]]).collect(),lengths,reference:fixed(d,"reference")?,bounds:fixed(d,"bounds")?,fallback:if d.contains("fallback_center")?{fixed(d,"fallback_center")?}else{[0.0;3]}}},
  "profile"=>{let angles=floats(d,"angles")?;let radii=floats(d,"radii")?;let heights=floats(d,"heights")?;let lengths=floats(d,"lengths")?;if angles.is_empty() || angles.len()>100000 || [radii.len(),heights.len(),lengths.len()].iter().any(|&n|n!=angles.len()){return Err(PyValueError::new_err("invalid custom profile arrays"));}
   let plane=if d.contains("plane")?{Some(fixed(d,"plane")?)}else{None};let sphere=if d.contains("sphere")?{Some(fixed::<1>(d,"sphere")?[0])}else{None};
   Self::Profile{center:fixed(d,"center")?,a:fixed(d,"axis")?,b:fixed(d,"lateral")?,angles,radii,heights,lengths,params:fixed(d,"params")?,plane,sphere,fallback:if d.contains("fallback_center")?{fixed(d,"fallback_center")?}else{[0.0;3]}}},
  _=>return Err(PyValueError::new_err("unknown custom seed shape")),
 })}
 pub fn fallback_center(&self)->V{match self{Self::Box{center,..}=>*center,Self::Curve{fallback,..}|Self::Profile{fallback,..}=>*fallback,Self::None=>[0.0;3]}}
 pub fn hit(&self,p:V)->bool{match self{
  Self::None=>false,
  Self::Box{center,a,b,extents}=>{let q=sub(p,*center);dot(q,*a).abs()<=extents[0] && dot(q,*b).abs()<=extents[1] && dot(q,cross(*a,*b)).abs()<=extents[2]},
  Self::Curve{points,lengths,reference,bounds,..}=>{
   if points.len()<2{return false;}let mut best=f32::INFINITY;let mut selected=0;let mut t=0.0;
   for i in 0..points.len()-1{let d=sub(points[i+1],points[i]);let len=dot(d,d);let u=if len>1e-12{(dot(d,sub(p,points[i]))/len).clamp(0.0,1.0)}else{0.0};let q=sub(p,std::array::from_fn(|k|points[i][k]+d[k]*u));let distance=dot(q,q);if distance<best{best=distance;selected=i;t=u;}}
   let d=sub(points[selected+1],points[selected]);let length=dot(d,d).sqrt();if length<=1e-12{return false;}let axis=d.map(|x|x/length);let origin=std::array::from_fn(|k|points[selected][k]+d[k]*t);let r=sub(*reference,origin);let proj=dot(axis,r);let r:V=std::array::from_fn(|k|r[k]-axis[k]*proj);let norm=dot(r,r).sqrt();if norm<=1e-12{return false;}let radial=r.map(|x|x/norm);let q=sub(p,origin);
   let along=lengths[selected]+t*length;let x=dot(radial,q);let y=dot(cross(axis,radial),q);
   for (end,previous) in [(0,1),(points.len()-1,points.len()-2)]{let d=sub(points[end],points[previous]);let length=dot(d,d).sqrt();if length>1e-12 && dot(d.map(|x|x/length),sub(p,points[end]))>0.0{return false;}}
   along>=bounds[0] && along<bounds[1] && y.abs()<=bounds[4] && x<=bounds[2] && -x<=bounds[3]
  },
  Self::Profile{params:r,plane,..}=>{
   if let Some(pl)=plane{if dot([pl[3],pl[4],pl[5]],sub(p,[pl[0],pl[1],pl[2]]))<0.0{return false;}}
   let q=self.projection(p).unwrap();
   !(r[4]!=0.0 && r[4]*(q.y-r[5])<0.0) && q.arc.abs()<=if q.arc<0.0{r[2]}else{r[3]} && q.signed<=q.factor*r[7] && (q.z-q.height).abs()<=r[6]
  }
 }}
 fn projection(&self,p:V)->Option<Projection>{match self{
  Self::Profile{center,a,b,angles,radii,heights,lengths,params:r,sphere,..}=>{
   let q=sub(p,*center);let mut x=dot(q,*a);let mut y=dot(q,*b);let mut z=dot(q,cross(*a,*b));
   if let Some(radius)=sphere{let radial=x.hypot(y);let (xx,yy)=if radial>1e-9{let arc=radius*radial.atan2(-z);((x/radial)*arc,(y/radial)*arc)}else{(if z>0.0{radius*std::f32::consts::PI}else{0.0},0.0)};z=((x*x+y*y)+z*z).sqrt()-radius;x=xx;y=yy;}
   // params: circumference, center arc, negative/positive arc widths,
   // side sign, side offset, thickness, outward depth, positive/negative
   // taper ranges, taper amount, priority edge fraction, exclusion distance;
   // final slot remains reserved, finite.
   let mut best=f32::MAX;let mut edge=0;let mut u=0.0;
   let point=|i:usize|{let (s,c)=crate::automatic_shapes::profile_sin_cos(angles[i]);[radii[i]*c,radii[i]*s]};
   for i in 0..angles.len(){let j=(i+1)%angles.len();let a=point(i);let b=point(j);let dx=b[0]-a[0];let dy=b[1]-a[1];let len=dx*dx+dy*dy;let t=if len>0.0{(((x-a[0])*dx+(y-a[1])*dy)/len).clamp(0.0,1.0)}else{0.0};let qx=(a[0]+dx*t)-x;let qy=(a[1]+dy*t)-y;let distance=qx*qx+qy*qy;if distance<best{best=distance;edge=i;u=t;}}
   let next=(edge+1)%angles.len();let a=point(edge);let b=point(next);let xx=a[0]+u*(b[0]-a[0]);let yy=a[1]+u*(b[1]-a[1]);let signed=if x.hypot(y)>xx.hypot(yy){best.sqrt()}else{-best.sqrt()};
   let end=if next==0{r[0]}else{lengths[next]};let mut arc=lengths[edge]+u*(end-lengths[edge])-r[1];if arc>r[0]*0.5{arc-=r[0];}else if arc<r[0]*-0.5{arc+=r[0];}
   let height=heights[edge]+u*(heights[next]-heights[edge]);let factor=if r[10]>0.0{let dy=yy-r[5];let range=if dy<0.0{r[9]}else{r[8]};let t=(dy.abs()/range.max(1e-9)).clamp(0.0,1.0);1.0-r[10]*(1.0-t)}else{1.0};
   Some(Projection{arc,signed,height,z,y,factor})
  },_=>None,
 }}
 pub fn priority_hit(&self,pnt:V)->bool{let p=pnt;match self{
  Self::Profile{params:r,..} if r[11]<1.0=>{let q=self.projection(p).unwrap();q.arc.abs()<=r[11]*if q.arc<0.0{r[2]}else{r[3]}},
  Self::Curve{profile:Some(p),..}=>p.priority_hit(pnt),Self::Curve{..}=>false,Self::None=>false,_=>true,
 }}
 pub fn exclusion_hit(&self,p:V)->bool{match self{
  Self::Curve{profile:Some(profile),..}=>profile.exclusion_hit(p),
  Self::Profile{center,radii,params:r,plane,sphere,..}=>{
   if r[12]<=0.0{return false;}
   let maximum=radii.iter().copied().fold(sphere.unwrap_or(0.0),f32::max);
   let bound=r[6]+(maximum+r[7]+(r[12]+r[12]));let d=sub(p,*center);
   if dot(d,d)>bound*bound{return false;}
   if let Some(pl)=plane{if dot([pl[3],pl[4],pl[5]],sub(p,[pl[0],pl[1],pl[2]]))<0.0{return false;}}
   let q=self.projection(p).unwrap();
   !(r[4]!=0.0 && r[4]*(q.y-r[5])<0.0) && q.signed>0.0 && q.arc.abs()<=if q.arc<0.0{r[2]}else{r[3]} && q.signed<=r[12]+q.factor*r[7] && (q.z-q.height).abs()<=r[6]
  },_=>false,
 }}
 pub fn parent_hit(&self,p:V,depth:f32,width:f32)->bool{match self{
  Self::Curve{profile:Some(profile),..}=>profile.parent_hit(p,depth,width),
  Self::Profile{center,a,b,plane:Some(pl),..}=>{
   let d=dot([pl[3],pl[4],pl[5]],sub(p,[pl[0],pl[1],pl[2]]));let q=sub(p,*center);
   d>=0.0 && d<=depth && dot(q,*b).abs()<=width && dot(q,cross(*a,*b))<=width
  },_=>false,
 }}
}
struct Projection{arc:f32,signed:f32,height:f32,z:f32,y:f32,factor:f32}
