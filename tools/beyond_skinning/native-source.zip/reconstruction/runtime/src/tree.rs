//! KD node layout and median partition recovered from 0xd726c/0x142730.
use crate::types::KdNode;
use numpy::{PyArray1, PyReadonlyArray2};
use pyo3::{exceptions::PyValueError, prelude::*, types::PyBytes};
#[pyclass(module = "_bvt_solver")]
pub struct VertexTree {
    nodes: Vec<KdNode>,
    root: i32,
}
fn build(nodes: &mut [KdNode], axis: usize, base: i32) -> i32 {
    let n = nodes.len();
    if n == 0 {
        return -1;
    }
    if n == 1 {
        return base;
    }
    let mid = n / 2;
    let mut low = 0usize;
    let mut high = n - 1;
    while low < high {
        let pivot = nodes[high].point[axis];
        let mut i = low;
        let mut j = high - 1;
        loop {
            while nodes[i].point[axis] < pivot {
                i += 1
            }
            // Native b.gt scan excludes unordered values.
            while j > low && nodes[j].point[axis] > pivot {
                j -= 1
            }
            if i >= j {
                break;
            }
            nodes.swap(i, j);
            i += 1;
            j -= 1;
        }
        nodes.swap(i, high);
        if mid <= i {
            if i == 0 {
                break;
            }
            high = i - 1
        }
        if i <= mid {
            low = i + 1
        }
    }
    nodes[mid].axis = axis as u32;
    let root = base + mid as i32;
    let next = (axis + 1) % 3;
    let left = build(&mut nodes[..mid], next, base);
    let right = build(&mut nodes[mid + 1..], next, root + 1);
    nodes[mid].left = left;
    nodes[mid].right = right;
    root
}
#[pymethods]
impl VertexTree {
    #[new]
    fn new(
        py: Python<'_>,
        coords: PyReadonlyArray2<'_, f32>,
        matrix_world: PyReadonlyArray2<'_, f32>,
    ) -> PyResult<Self> {
        let p = crate::array_input::two(&coords);
        let m = crate::array_input::two(&matrix_world);
        if p.ncols() != 3 {
            return Err(PyValueError::new_err(format!(
                "coords must be (N, 3), got {:?}",
                p.shape()
            )));
        }
        if m.shape() != [4, 4] {
            return Err(PyValueError::new_err("matrix_world must be (4, 4)"));
        }
        if p.nrows() > i32::MAX as usize {
            return Err(PyValueError::new_err(
                "research tree index capacity exceeded",
            ));
        }
        let mut nodes: Vec<_> = p
            .rows()
            .into_iter()
            .enumerate()
            .map(|(i, row)| {
                let point = std::array::from_fn(|axis| {
                    ((m[[axis, 0]] * row[0]) as f64
                        + 0.0
                        + (m[[axis, 1]] * row[1]) as f64
                        + (m[[axis, 2]] * row[2]) as f64
                        + m[[axis, 3]] as f64) as f32
                });
                KdNode {
                    point,
                    original_index: i as i32,
                    axis: 0,
                    left: -1,
                    right: -1,
                }
            })
            .collect();
        let root = py.allow_threads(|| build(&mut nodes, 0, 0));
        Ok(Self { nodes, root })
    }
    fn find_range<'py>(
        &self,
        py: Python<'py>,
        centres: PyReadonlyArray2<'_, f32>,
        radius: f64,
    ) -> PyResult<Bound<'py, PyArray1<i64>>> {
        let centres = crate::array_input::two(&centres);
        if centres.ncols() != 3 {
            return Err(PyValueError::new_err(format!(
                "centres must be (N, 3), got {:?}",
                centres.shape()
            )));
        }
        let centres: Vec<[f32; 3]> = centres
            .rows()
            .into_iter()
            .map(|r| [r[0], r[1], r[2]])
            .collect();
        let result = py.allow_threads(|| {
            let r = radius as f32;
            let mut found = Vec::new();
            let mut stack = Vec::new();
            for c in centres {
                if self.root != -1 {
                    stack.push(self.root)
                }
                while let Some(index) = stack.pop() {
                    let n = &self.nodes[index as usize];
                    let axis = n.axis as usize;
                    if r + c[axis] < n.point[axis] {
                        if n.left != -1 {
                            stack.push(n.left)
                        }
                    // ARM b.le admits unordered to the distance test; b.hi there
                    // rejects unordered. Negated comparisons are not equivalent.
                    } else if c[axis] - r > n.point[axis] {
                        if n.right != -1 {
                            stack.push(n.right)
                        }
                    } else {
                        let dx = n.point[0] - c[0];
                        let dy = n.point[1] - c[1];
                        let dz = n.point[2] - c[2];
                        if dx * dx + dy * dy + dz * dz <= r * r {
                            found.push(n.original_index as i64)
                        }
                        if n.left != -1 {
                            stack.push(n.left)
                        }
                        if n.right != -1 {
                            stack.push(n.right)
                        }
                    }
                }
            }
            found.sort_unstable();
            found.dedup();
            found
        });
        if result.is_empty() {
            Ok(PyArray1::from_owned_array(py, ndarray::Array1::zeros(0)))
        } else {
            Ok(PyArray1::from_vec(py, result))
        }
    }
    /// Research-only diagnostic for direct native layout comparison.
    fn _node_bytes<'py>(&self, py: Python<'py>) -> (i32, Bound<'py, PyBytes>) {
        (
            self.root,
            PyBytes::new(py, bytemuck::cast_slice(&self.nodes)),
        )
    }
}

impl VertexTree {
    pub(crate) fn from_points(points:&[[f32;3]])->Self {
        let mut nodes:Vec<_>=points.iter().enumerate().map(|(i,&point)|KdNode{point,original_index:i as i32,axis:0,left:-1,right:-1}).collect();
        let root=build(&mut nodes,0,0);Self{nodes,root}
    }
    pub(crate) fn nearest(&self,query:[f32;3])->u32 {
        if self.root<0{return 0;}
        let mut best=self.root;
        let distance=|p:[f32;3]|{let d=std::array::from_fn::<_,3,_>(|a|p[a]-query[a]);d[0]*d[0]+d[1]*d[1]+d[2]*d[2]};
        let root=&self.nodes[best as usize];let mut d2=distance(root.point);let mut stack=Vec::with_capacity(64);
        let children=|node:&KdNode|if query[node.axis as usize]<node.point[node.axis as usize]{(node.right,node.left)}else{(node.left,node.right)};
        let (far,near)=children(root);if far!=-1{stack.push(far);}if near!=-1{stack.push(near);}
        while let Some(i)=stack.pop(){let node=&self.nodes[i as usize];let delta=node.point[node.axis as usize]-query[node.axis as usize];
            // Native 0x5e96c uses delta < 0 for descendant traversal, unlike
            // the root query < point test. Equality therefore visits left first.
            let (far,near)=if delta<0.0{(node.left,node.right)}else{(node.right,node.left)};
            if delta*delta<d2{let d=distance(node.point);if d<d2{d2=d;best=i;}if far!=-1{stack.push(far);}}
            if near!=-1{stack.push(near);}
        }
        self.nodes[best as usize].original_index as u32
    }
}
