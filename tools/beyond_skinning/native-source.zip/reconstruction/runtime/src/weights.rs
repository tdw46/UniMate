//! Reconstructed sparse weight storage and color arithmetic. No foreign pointers.
use crate::array_input::{one, two};
use numpy::{PyArray1, PyArray2, PyReadonlyArray1, PyReadonlyArray2};
use pyo3::{exceptions::PyValueError, prelude::*};
#[pyclass(module = "_bvt_solver")]
pub struct WeightRows {
    rows: Vec<Vec<(i32, f32)>>,
    n_groups: usize,
}
fn error(s: &str) -> PyErr {
    PyValueError::new_err(s.to_owned())
}
fn hue(h: f64) -> [f32; 4] {
    let x = if h.is_finite() {
        (h - h.trunc()) * 6.0
    } else {
        f64::NAN.copysign(h)
    };
    let i = x as i64;
    let f = x - i as f64;
    let p = 0.14250000000000002;
    let q = (1.0 - f * 0.85) * 0.95;
    let t = (1.0 - (1.0 - f) * 0.85) * 0.95;
    let (r, g, b) = match i % 6 {
        0 => (0.95, t, p),
        1 => (q, 0.95, p),
        2 => (p, 0.95, t),
        3 => (p, q, 0.95),
        4 => (t, p, 0.95),
        _ => (0.95, p, q),
    };
    [r as f32, g as f32, b as f32, 0.9]
}
impl WeightRows {
    fn push(row: &mut Vec<(i32, f32)>, k: i32, w: f32) {
        if let Some((_, old)) = row.iter_mut().find(|(key, _)| *key == k) {
            *old = w + *old
        } else {
            row.push((k, w))
        }
    }
    fn colors(
        &self,
        hues: PyReadonlyArray1<'_, f64>,
        blend: bool,
        mark_empty: bool,
    ) -> PyResult<(ndarray::Array2<f32>, Vec<i32>)> {
        let h = one(&hues);
        if h.len() != self.n_groups {
            return Err(error(&format!(
                "hues has {} entries for {} groups",
                h.len(),
                self.n_groups
            )));
        }
        let palette: Vec<_> = h.iter().map(|&h| hue(h)).collect();
        let mut out = ndarray::Array2::zeros((self.rows.len(), 4));
        let mut dominant = Vec::with_capacity(self.rows.len());
        for (index, row) in self.rows.iter().enumerate() {
            let (mut sum, mut r, mut g, mut b) = (0.0f64, 0.0f64, 0.0f64, 0.0f64);
            let mut best = -1;
            let mut max_weight = 0.0f32;
            for &(k, w) in row {
                // Native FCMP/LS admits unordered values; unordered comparisons replace.
                if !(w <= 0.0) && (best < 0 || (!(max_weight > w) && (max_weight != w || k <= best))) {
                    best = k;
                    max_weight = w
                }
                if blend {
                    let c = palette[k as usize];
                    sum += w as f64;
                    r += c[0] as f64 * w as f64;
                    g += c[1] as f64 * w as f64;
                    b += c[2] as f64 * w as f64;
                }
            }
            let color = if blend {
                if sum <= 1e-8 {
                    best = -1;
                    if mark_empty {
                        r = 0.08;
                        g = 0.08;
                        b = 0.08
                    } else {
                        r /= 1e-8;
                        g /= 1e-8;
                        b /= 1e-8
                    }
                } else {
                    r /= sum;
                    g /= sum;
                    b /= sum
                }
                [r as f32, g as f32, b as f32, 1.0]
            } else {
                palette
                    .get(best.max(0) as usize)
                    .copied()
                    .unwrap_or([0.0; 4])
            };
            for c in 0..4 {
                out[[index, c]] = color[c]
            }
            dominant.push(best);
        }
        Ok((out, dominant))
    }
}
#[pymethods]
impl WeightRows {
    #[new]
    #[pyo3(signature=(counts,groups,weights,n_groups,mask=None))]
    fn new(
        counts: PyReadonlyArray1<'_, i64>,
        groups: PyReadonlyArray1<'_, i32>,
        weights: PyReadonlyArray1<'_, f32>,
        n_groups: usize,
        mask: Option<PyReadonlyArray1<'_, bool>>,
    ) -> PyResult<Self> {
        let counts = one(&counts);
        let groups = one(&groups);
        let weights = one(&weights);
        if groups.len() != weights.len() {
            return Err(error("groups and weights must share length"));
        }
        let sum = counts.iter().try_fold(0usize, |sum, &n| {
            if n < 0 {
                None
            } else {
                sum.checked_add(n as usize)
            }
        });
        if sum != Some(groups.len()) {
            return Err(error("counts must be non-negative and sum to len(groups)"));
        }
        let mask = mask.as_ref().map(one);
        if mask.as_ref().is_some_and(|m| m.len() != n_groups) {
            return Err(error("mask must have one entry per group"));
        }
        let mut rows = Vec::with_capacity(counts.len());
        let mut p = 0;
        for &n in counts.iter() {
            let mut row = Vec::new();
            for j in p..p + n as usize {
                let k = groups[j];
                if k >= 0 && (k as usize) < n_groups && mask.as_ref().is_none_or(|m| m[k as usize])
                {
                    Self::push(&mut row, k, weights[j])
                }
            }
            p += n as usize;
            rows.push(row)
        }
        Ok(Self { rows, n_groups })
    }
    #[staticmethod]
    fn from_top_k(
        weights: PyReadonlyArray2<'_, f32>,
        bones: PyReadonlyArray2<'_, i32>,
        n_groups: usize,
    ) -> PyResult<Self> {
        let w = two(&weights);
        let b = two(&bones);
        if w.shape() != b.shape() {
            return Err(error("weights and bones must share shape (V, K)"));
        }
        if b.iter().any(|&k| k >= 0 && k as usize >= n_groups) {
            return Err(error("a bone index is past the bone list"));
        }
        // Native flat-array chunking produces no rows when K is zero.
        if w.ncols() == 0 { return Ok(Self { rows: Vec::new(), n_groups }); }
        let mut rows = Vec::with_capacity(w.nrows());
        for (wr, br) in w.rows().into_iter().zip(b.rows()) {
            let mut row = Vec::new();
            for (&w, &k) in wr.iter().zip(br.iter()) {
                if k >= 0 {
                    Self::push(&mut row, k, w)
                }
            }
            rows.push(row)
        }
        Ok(Self { rows, n_groups })
    }
    #[getter]
    fn shape(&self) -> (usize, usize) {
        (self.rows.len(), self.n_groups)
    }
    fn __len__(&self) -> usize {
        self.rows.len()
    }
    fn column<'py>(&self, py: Python<'py>, idx: i64) -> Bound<'py, PyArray1<f32>> {
        let out = self
            .rows
            .iter()
            .map(|row| {
                let w = row
                    .iter()
                    .find(|(k, _)| i64::from(*k) == idx)
                    .map_or(0.0, |(_, w)| *w);
                if w > 0.0 {
                    w.min(1.0)
                } else {
                    0.0
                }
            })
            .collect();
        if self.rows.is_empty() { return PyArray1::from_owned_array(py,ndarray::Array1::zeros(0)); }
        PyArray1::from_vec(py, out)
    }
    #[pyo3(signature=(hues,mark_empty=true))]
    fn blend_colors<'py>(
        &self,
        py: Python<'py>,
        hues: PyReadonlyArray1<'py, f64>,
        mark_empty: bool,
    ) -> PyResult<(Bound<'py, PyArray2<f32>>, Bound<'py, PyArray1<i32>>)> {
        let (out, dom) = self.colors(hues, true, mark_empty)?;
        Ok((
            PyArray2::from_owned_array(py, out),
            if dom.is_empty() { PyArray1::from_owned_array(py,ndarray::Array1::zeros(0)) } else { PyArray1::from_vec(py, dom) },
        ))
    }
    fn dominant_colors<'py>(
        &self,
        py: Python<'py>,
        hues: PyReadonlyArray1<'py, f64>,
    ) -> PyResult<Bound<'py, PyArray2<f32>>> {
        let (out, _) = self.colors(hues, false, false)?;
        Ok(PyArray2::from_owned_array(py, out))
    }
    fn set_rows(&mut self, rows: PyReadonlyArray1<'_, i64>, src: &WeightRows) -> PyResult<()> {
        let rows = one(&rows);
        if rows.len() != src.rows.len() || self.n_groups != src.n_groups {
            return Err(error(
                "set_rows needs one source row per index, over the same columns",
            ));
        }
        if rows.iter().any(|&i| i < 0 || i as usize >= self.rows.len()) {
            return Err(error("a row index is out of range"));
        }
        for (&i, row) in rows.iter().zip(&src.rows) {
            self.rows[i as usize] = row.clone()
        }
        Ok(())
    }
}
