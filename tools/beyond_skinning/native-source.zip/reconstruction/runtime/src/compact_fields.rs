//! Compact adaptive storage. Dense arithmetic order retained, dense matrices avoided.
use pyo3::{prelude::*,exceptions::PyValueError};
use rayon::prelude::*;
use numpy::{PyReadonlyArray1,PyReadonlyArray2,PyArray2};
use ndarray::ArrayView2;
fn err(s:&str)->PyErr{PyValueError::new_err(s.to_string())}
// Match Vec's addressable allocation boundary without a research entry cap.
pub(crate) fn allocation_len(rows:usize,columns:usize,element_bytes:usize)->PyResult<usize>{
 rows.checked_mul(columns).filter(|&n|n<=isize::MAX as usize/element_bytes)
  .ok_or_else(||pyo3::panic::PanicException::new_err("capacity overflow"))
}
fn validate(g:ArrayView2<'_,u16>,v:ArrayView2<'_,f32>,b:usize)->PyResult<()>{
 if b==0||b>u16::MAX as usize||g.shape()!=v.shape()||g.ncols()==0||g.ncols()>32{return Err(err("invalid compact field dimensions"))}
 for r in g.rows(){let mut last=None;for &x in r{if x!=u16::MAX&&x as usize>=b{return Err(err("invalid compact bone index"))}if last.is_some_and(|p|p>x||(p==x&&x!=u16::MAX)){return Err(err("compact groups must be unique and sorted"))}last=Some(x);}}
 Ok(())
}
fn decode(g:ArrayView2<'_,u16>,v:ArrayView2<'_,f32>,i:usize,out:&mut[f32]){out.fill(0.);for (&b,&value) in g.row(i).iter().zip(v.row(i).iter()){if b==u16::MAX{break}out[b as usize]=value;}}
fn arrays<'py>(py:Python<'py>,n:usize,k:usize,g:Vec<u16>,v:Vec<f32>)->PyResult<(Bound<'py,PyArray2<u16>>,Bound<'py,PyArray2<f32>>)>{
 let g=ndarray::Array2::from_shape_vec((n,k),g).map_err(|e|err(&e.to_string()))?;let v=ndarray::Array2::from_shape_vec((n,k),v).map_err(|e|err(&e.to_string()))?;
 Ok((PyArray2::from_owned_array(py,g),PyArray2::from_owned_array(py,v)))
}
#[pyfunction]
pub fn interpolate_compact_arrays<'py>(py:Python<'py>,ids:PyReadonlyArray2<'py,u32>,weights:PyReadonlyArray2<'py,f32>,groups:PyReadonlyArray2<'py,u16>,values:PyReadonlyArray2<'py,f32>,bones:usize,seeds:PyReadonlyArray1<'py,u32>,slots:usize)->PyResult<(Bound<'py,PyArray2<u16>>,Bound<'py,PyArray2<f32>>)>{
 let ids=ids.as_array();let w=weights.as_array();let g=groups.as_array();let v=values.as_array();let seeds=seeds.as_array();validate(g,v,bones)?;
 let n=ids.nrows();if ids.ncols()!=4||ids.shape()!=w.shape()||seeds.len()!=n||slots==0||slots>16||ids.iter().any(|&i|i!=u32::MAX&&i as usize>=g.nrows())||(w.iter().any(|x|!x.is_finite())||g.iter().zip(v.iter()).any(|(&group,x)|group!=u16::MAX&&!x.is_finite()))||seeds.iter().any(|&i|i!=u32::MAX&&i>=65535){return Err(err("invalid compact interpolation inputs"))}
 let output_len=allocation_len(n,slots,std::mem::size_of::<f32>())?;
 let (og,ov)=py.allow_threads(||->PyResult<_>{
  let mut og=vec![u16::MAX;output_len];let mut ov=vec![0f32;output_len];
  let block=n.div_ceil(4).max(32);let chunk=block*slots;
  let run=|(batch,(oi,ow)):(usize,(&mut[u16],&mut[f32]))|->PyResult<()> {
   let mut row=vec![0.;bones];let mut src=vec![0.;bones];
   for offset in 0..oi.len()/slots {let i=batch*block+offset;if i%1024==0{crate::cancel::check();}row.fill(0.);let mut sum=0.0f32;
    for j in 0..4{let id=ids[[i,j]];if id==u32::MAX{break}let weight=w[[i,j]];sum+=weight;decode(g,v,id as usize,&mut src);for (dst,&source) in row.iter_mut().zip(&src){*dst+=weight*source;}}
    if sum>0.{let inv=1.0f32/sum;for x in &mut row{*x*=inv;}}
    let (gg,vv)=crate::sparse_setup::sparse_seed_slots(row.clone(),slots,seeds[i])?;
    oi[offset*slots..(offset+1)*slots].copy_from_slice(&gg);ow[offset*slots..(offset+1)*slots].copy_from_slice(&vv);
   }Ok(())
  };
  if n>=128 && bones<=16384 {og.par_chunks_mut(chunk).zip(ov.par_chunks_mut(chunk)).enumerate().try_for_each(run)?;}
  else {for batch in og.chunks_mut(chunk).zip(ov.chunks_mut(chunk)).enumerate(){run(batch)?;}}
  Ok((og,ov))
 })?;arrays(py,n,slots,og,ov)
}
#[pyfunction]
pub fn clean_compact_arrays<'py>(py:Python<'py>,rows:PyReadonlyArray1<'py,u32>,columns:PyReadonlyArray1<'py,u32>,radii:PyReadonlyArray1<'py,f32>,groups:PyReadonlyArray2<'py,u16>,values:PyReadonlyArray2<'py,f32>,bones:usize,threshold:f32,top_k:usize)->PyResult<(Bound<'py,PyArray2<u16>>,Bound<'py,PyArray2<f32>>)>{
 use rustc_hash::FxHashMap;
 let rows=rows.as_slice()?;let columns=columns.as_slice()?;let radii=radii.as_slice()?;let g=groups.as_array();let v=values.as_array();validate(g,v,bones)?;let n=g.nrows();let slots=g.ncols();let k=top_k.min(bones).min(32);
 if k==0||rows.len()!=n+1||rows.first()!=Some(&0)||rows.last().copied()!=Some(columns.len() as u32)||rows.windows(2).any(|x|x[0]>x[1])||columns.iter().any(|&x|x as usize>=n)||radii.len()!=n||radii.iter().any(|x|!x.is_finite()||*x<=0.){return Err(err("invalid compact cleanup inputs"))}
 let output_len=allocation_len(n,k,std::mem::size_of::<f32>())?;
 let (og,ov)=py.allow_threads(||->PyResult<_>{
  let mut out=v.to_owned();
  fn root(p:&mut[usize],mut i:usize)->usize{while p[i]!=i{p[i]=p[p[i]];i=p[i];}i}
  // Preserve dense column order, selection order, union operations and FxHashMap
  // mass tie handling. A single decoded column includes implicit zeros even
  // for negative thresholds; no heuristic omission of those rows is allowed.
  if threshold>=0. {
  // Invert only selected compact entries, in bone batches bounded by one
  // point-count of indices. This replaces repeated full-row binary searches.
  // Entries remain in original point order; union, mass and tie order match.
  let mut counts=vec![0usize;bones];
  for i in 0..n {if i%1024==0{crate::cancel::check();}
   for (&b,&value) in g.row(i).iter().zip(v.row(i).iter()) {
    if b==u16::MAX{break}if value>threshold{counts[b as usize]+=1;}
   }
  }
  let mut lookup=vec![usize::MAX;n];let mut entries=Vec::<usize>::new();
  let mut first=0;
  while first<bones {
   let mut last=first;let mut total=0;
   while last<bones {
    let count=if counts[last]>=2{counts[last]}else{0};
    if total>0 && count>n-total{break}
    total+=count;last+=1;
   }
   let mut offsets=vec![0usize;last-first+1];
   for b in first..last {offsets[b-first+1]=offsets[b-first]+if counts[b]>=2{counts[b]}else{0};}
   entries.resize(total,0);let mut cursor=offsets[..last-first].to_vec();
   if total>0 {for i in 0..n {if i%1024==0{crate::cancel::check();}
    for (slot,(&b,&value)) in g.row(i).iter().zip(v.row(i).iter()).enumerate() {
     let b=b as usize;if b>=last{break}if b>=first && counts[b]>=2 && value>threshold {
      entries[cursor[b-first]]=i*slots+slot;cursor[b-first]+=1;
     }
    }
   }}
   for b in first..last {crate::cancel::check();
    let selected=&entries[offsets[b-first]..offsets[b-first+1]];
    if selected.len()<2{continue;}
    for (j,&entry) in selected.iter().enumerate(){lookup[entry/slots]=j;}
    let mut parent:Vec<_>=(0..selected.len()).collect();
    for (j,&entry) in selected.iter().enumerate(){let i=entry/slots;
     for e in rows[i]..rows[i+1]{let q=lookup[columns[e as usize] as usize];if q!=usize::MAX{let a=root(&mut parent,j);let z=root(&mut parent,q);if a!=z{parent[a]=z;}}}
    }
    let mut mass=FxHashMap::<u32,f64>::default();
    for (j,&entry) in selected.iter().enumerate(){let i=entry/slots;let r=radii[i] as f64;let value=((out[[i,entry%slots]] as f64*r)*r)*r;*mass.entry(root(&mut parent,j) as u32).or_default()+=value;}
    let mut winner=0;let mut largest=f64::NEG_INFINITY;for (&key,&value) in &mass{if value>=largest{largest=value;winner=key;}}
    for (j,&entry) in selected.iter().enumerate(){let i=entry/slots;if root(&mut parent,j) as u32!=winner{out[[i,entry%slots]]=0.;}lookup[i]=usize::MAX;}
   }
   first=last;
  }
  } else {
  for b in 0..bones{crate::cancel::check();let mut column=vec![0.0f32;n];let mut location=vec![usize::MAX;n];
   for i in 0..n{for j in 0..slots{let x=g[[i,j]];if x as usize==b{column[i]=out[[i,j]];location[i]=j;break}if x as usize>b{break}}}
   let selected:Vec<usize>=(0..n).filter(|&i|column[i]>threshold).collect();if selected.len()<2{continue;}
   let mut lookup=vec![usize::MAX;n];for (j,&i) in selected.iter().enumerate(){lookup[i]=j;}let mut parent:Vec<_>=(0..selected.len()).collect();
   for (j,&i) in selected.iter().enumerate(){for e in rows[i]..rows[i+1]{let q=lookup[columns[e as usize] as usize];if q!=usize::MAX{let a=root(&mut parent,j);let z=root(&mut parent,q);if a!=z{parent[a]=z;}}}}
   let mut mass=FxHashMap::<u32,f64>::default();for (j,&i) in selected.iter().enumerate(){let r=radii[i] as f64;let value=((column[i] as f64*r)*r)*r;*mass.entry(root(&mut parent,j) as u32).or_default()+=value;}
   let mut winner=0;let mut largest=f64::NEG_INFINITY;for (&key,&value) in &mass{if value>=largest{largest=value;winner=key;}}
   for (j,&i) in selected.iter().enumerate(){if root(&mut parent,j) as u32!=winner&&location[i]!=usize::MAX{out[[i,location[i]]]=0.;}}
  }
  }
  let mut og=Vec::with_capacity(output_len);let mut ov=Vec::with_capacity(output_len);let mut row=vec![0.;bones];let bleed=0.25f32/k as f32;
  for i in 0..n{if i%1024==0{crate::cancel::check();}
   let source=out.row(i);let ids=g.row(i);
   if ids.iter().zip(source.iter()).take_while(|(id,_)|**id!=u16::MAX).all(|(_,v)|v.is_finite() && *v>=0.0){
    compact_finish_row(ids,source,bones,k,threshold,bleed,&mut og,&mut ov);
    continue;
   }
   decode(g,out.view(),i,&mut row);
   let largest=row.iter().copied().fold(0.0f32,f32::max).min(1.).max(f32::MIN_POSITIVE);let floor=threshold*largest;for w in &mut row{if *w>0.&&*w<=floor{*w=0.;}}
   let (ids,weights)=crate::sampling::reduce_top_weights(row.clone(),k,bleed,true)?;
   let mut pairs:Vec<_>=ids.into_iter().zip(weights).filter(|(i,_)|*i>=0).collect();pairs.sort_by_key(|x|x.0);
   let len=pairs.len();for (id,value) in pairs{og.push(id as u16);ov.push(value);}for _ in len..k{og.push(u16::MAX);ov.push(0.);}
  }Ok((og,ov))
 })?;arrays(py,n,k,og,ov)
}
#[pyfunction]
pub fn sample_compact_array<'py>(py:Python<'py>,ids:PyReadonlyArray2<'py,u32>,weights:PyReadonlyArray2<'py,f32>,groups:PyReadonlyArray2<'py,u16>,values:PyReadonlyArray2<'py,f32>,bones:usize)->PyResult<Bound<'py,PyArray2<f32>>>{
 let ids=ids.as_array();let w=weights.as_array();let g=groups.as_array();let v=values.as_array();validate(g,v,bones)?;let n=ids.nrows();
 if ids.shape()!=w.shape()||ids.iter().any(|&i|i!=u32::MAX&&i as usize>=g.nrows())||(w.iter().any(|x|!x.is_finite())||g.iter().zip(v.iter()).any(|(&group,x)|group!=u16::MAX&&!x.is_finite())){return Err(err("invalid compact sample inputs"))}
 // Decode a small, repeatedly sampled field once. Capping the temporary
 // at 64 KiB keeps sparse production fields on the ordinary row path.
 let output_len=allocation_len(n,bones,std::mem::size_of::<f32>())?;
 let output=py.allow_threads(|| {
     let mut output = vec![0.0f32; output_len];
     let dense = if g.nrows() <= ids.len()/2 && g.nrows() <= 16384/bones {
         let mut rows = vec![0.0; g.nrows()*bones];
         for (i, row) in rows.chunks_exact_mut(bones).enumerate() {
             decode(g, v, i, row);
         }
         Some(rows)
     } else { None };
     let update = |(block,rows):(usize,&mut [f32])| {
      let mut scratch=vec![0.0; bones];
      for (offset,row) in rows.chunks_exact_mut(bones).enumerate() {
       let i=block*32+offset;
         if i%1024==0 { crate::cancel::check(); }
         for (&id, &weight) in ids.row(i).iter().zip(w.row(i).iter()) {
             if id==u32::MAX { continue; }
             let index=id as usize;
             let src = if let Some(ref rows)=dense {
                 &rows[index*bones..(index+1)*bones]
             } else {
                 decode(g,v,index,&mut scratch);
                 &scratch[..]
             };
             for (value, &source) in row.iter_mut().zip(src) {
                 *value += weight*source;
             }
         }
     }
     };
     if n>=128 { output.par_chunks_mut(bones*32).enumerate().for_each(update); }
     else { output.chunks_mut(bones*32).enumerate().for_each(update); }
     output
 });
 let array=ndarray::Array2::from_shape_vec((n,bones),output).map_err(|e|err(&e.to_string()))?;Ok(PyArray2::from_owned_array(py,array))
}

/// Final compact sampling and reduction in one owned operation. Validate the
/// shared field once, keep dense scratch per worker, and retain row arithmetic
/// and the same public reducer's ordering. No full sampled dense matrix.
#[pyfunction]
pub fn sample_compact_reduced<'py>(py:Python<'py>,ids:PyReadonlyArray2<'py,u32>,weights:PyReadonlyArray2<'py,f32>,groups:PyReadonlyArray2<'py,u16>,values:PyReadonlyArray2<'py,f32>,bones:usize,k:usize)->PyResult<(Bound<'py,PyArray2<i32>>,Bound<'py,PyArray2<f32>>)> {
 let ids=ids.as_array();let w=weights.as_array();let g=groups.as_array();let v=values.as_array();validate(g,v,bones)?;let n=ids.nrows();
 if ids.shape()!=w.shape()||ids.iter().any(|&i|i!=u32::MAX&&i as usize>=g.nrows())||(w.iter().any(|x|!x.is_finite())||g.iter().zip(v.iter()).any(|(&group,x)|group!=u16::MAX&&!x.is_finite())){return Err(err("invalid compact sample inputs"))}
 if k>32{return Err(err("invalid reduced sample dimensions"))}
 let count=allocation_len(n,k,std::mem::size_of::<f32>())?;
 let (out_ids,out_weights)=py.allow_threads(|| -> PyResult<_> {
  let mut out_ids=vec![-1i32;count];let mut out_weights=vec![0f32;count];
  if k==0{return Ok((out_ids,out_weights));}
  let cancel_interval=1024usize.min((65536/bones).max(1));
  let run=|(block,(oi,ow)):(usize,(&mut[i32],&mut[f32]))| -> PyResult<()> {
   let mut row=vec![0f32;bones];let mut source=vec![0f32;bones];
   for offset in 0..oi.len()/k {
    let i=block*32+offset;if i%cancel_interval==0{crate::cancel::check();}row.fill(0.);
    for (&id,&weight) in ids.row(i).iter().zip(w.row(i).iter()) {
     if id==u32::MAX{continue;}decode(g,v,id as usize,&mut source);
     for (value,&src) in row.iter_mut().zip(&source){*value+=weight*src;}
    }
    let (bi,bw)=crate::sampling::reduce_top_weights(row.clone(),k,0.,false)?;
    oi[offset*k..(offset+1)*k].copy_from_slice(&bi);ow[offset*k..(offset+1)*k].copy_from_slice(&bw);
   }Ok(())
  };
  if n>=128 {out_ids.par_chunks_mut(k*32).zip(out_weights.par_chunks_mut(k*32)).enumerate().try_for_each(run)?;}
  else {for block in out_ids.chunks_mut(k*32).zip(out_weights.chunks_mut(k*32)).enumerate(){run(block)?;}}
  Ok((out_ids,out_weights))
 })?;
 let oi=ndarray::Array2::from_shape_vec((n,k),out_ids).map_err(|e|err(&e.to_string()))?;
 let ow=ndarray::Array2::from_shape_vec((n,k),out_weights).map_err(|e|err(&e.to_string()))?;
 Ok((PyArray2::from_owned_array(py,oi),PyArray2::from_owned_array(py,ow)))
}

// Finite nonnegative compact rows need at most their stored IDs plus the first
// k+1 bone IDs. Later implicit zeros cannot displace those earlier equal zeros.
// Preserve the dense reducer's bone-order insertion, attenuation fallback,
// selected-weight summation and final index order; unusual signed/nonfinite
// values keep the complete dense route above.
fn compact_finish_row(ids:ndarray::ArrayView1<'_,u16>,values:ndarray::ArrayView1<'_,f32>,bones:usize,k:usize,threshold:f32,bleed:f32,og:&mut Vec<u16>,ov:&mut Vec<f32>){
 let count=(k+1).min(bones);
 let mut raw=[0.0f32;32];let mut adjusted=[0.0f32;32];let mut len=0;let mut largest=0.0f32;
 for (&id,&v) in ids.iter().zip(values.iter()) {if id==u16::MAX{break;}largest=largest.max(v);raw[len]=v;len+=1;}
 largest=largest.min(1.).max(f32::MIN_POSITIVE);let floor=threshold*largest;
 let start=bleed*0.5;let width=bleed*1.5;let mut all_zero=true;
 for j in 0..len {
  let w=&mut raw[j];if *w>0. && *w<=floor{*w=0.;}
  let value=(*w-start)/width;let lo=if value<0.0{0.0}else{value};let t=if lo<=1.0{lo}else{1.0};
  adjusted[j]=*w*(t*t*(3.0-(t+t)));if adjusted[j]>0.0{all_zero=false;}
 }
 let mut best=[f32::NEG_INFINITY;33];let mut selected=[usize::MAX;33];
 let mut insert=|id:usize,w:f32| {
  if w<=best[count-1]{return;}
  let mut at=count-1;while at>0 && best[at-1]<w{best[at]=best[at-1];selected[at]=selected[at-1];at-=1;}
  best[at]=w;selected[at]=id;
 };
 let mut slot=0;
 for id in 0..count {
  let w=if slot<len && ids[slot] as usize==id{let j=slot;slot+=1;if all_zero{raw[j]}else{adjusted[j]}}else{0.};
  insert(id,w);
 }
 for j in slot..len {insert(ids[j] as usize,if all_zero{raw[j]}else{adjusted[j]});}
 let mut sum=0.0f32;
 for w in &mut best[..k]{*w=if *w>0.0{*w}else{0.0};sum+=*w;}
 let denom=if sum>1e-8{sum}else{1e-8};let mut pairs=[(u16::MAX,0.0f32);32];
 for j in 0..k{pairs[j]=(selected[j] as u16,best[j]/denom);}
 pairs[..k].sort_unstable_by_key(|x|x.0);
 for &(id,w) in &pairs[..k]{og.push(id);ov.push(w);}
}
