//! Public per-bind guard environment, recovered from 0xbe0a8 and 0xd9db0.
use pyo3::prelude::*;
use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};
static HOST_RAM: AtomicU64=AtomicU64::new(0);
static DEFAULT_BASE: AtomicU32=AtomicU32::new(0);
static DEFAULT_DEPTH: AtomicU32=AtomicU32::new(0);
#[pyfunction]
pub fn set_bind_env(host_ram:u64,default_base_res:u32,default_depth:u32){
 HOST_RAM.store(host_ram,Ordering::Relaxed);
 DEFAULT_BASE.store(default_base_res,Ordering::Relaxed);
 DEFAULT_DEPTH.store(default_depth,Ordering::Relaxed);
 crate::cancel::clear_cancel();
}
#[pyfunction]
pub fn bind_env_snapshot()->(u64,u32,u32,bool){
 (HOST_RAM.load(Ordering::Relaxed),DEFAULT_BASE.load(Ordering::Relaxed),DEFAULT_DEPTH.load(Ordering::Relaxed),crate::cancel::requested())
}
pub fn admit(cells:u64)->PyResult<()> {
 let ram=HOST_RAM.load(Ordering::Relaxed);
 if cells>u32::MAX as u64 || (ram!=0 && cells*8>((ram as f64*0.75) as u64)) {
  let base=DEFAULT_BASE.load(Ordering::Relaxed);let depth=DEFAULT_DEPTH.load(Ordering::Relaxed);
  let defaults=if base!=0 && depth!=0 {format!("The defaults (Base Resolution {base}, Depth {depth})")}else{"The defaults".to_owned()};
  return Err(pyo3::panic::PanicException::new_err(format!("Auto Skinning stopped before it started: at this voxel resolution the mesh cannot be voxelised in the memory this machine has.\n\nYou almost certainly do not need it this high. {defaults} cover nearly every model. A finer voxel grid only helps when weights bleed across a small gap in the mesh, between the thighs for instance.\n\nLower Base Resolution or Depth and run again. Nothing has been changed on your mesh or your rig.")));
 }
 Ok(())
}
