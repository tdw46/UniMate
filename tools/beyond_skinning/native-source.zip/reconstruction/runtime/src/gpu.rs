//! Independent wgpu 24 host for recovered kernels. No calls into original module.
use std::{
    borrow::Cow,
    sync::{Arc,atomic::{AtomicBool,Ordering}},
};
use wgpu::util::DeviceExt;
/// Typed device callback payload. Do not classify arbitrary panics or transport
/// validation failures as GPU allocation errors.
#[derive(Debug)]
pub struct DeviceFault(pub String);
pub enum ReplayFailure { Device(String), Transport(String) }
thread_local! { static CAPTURE_DEVICE_ERRORS: std::cell::Cell<bool> = const { std::cell::Cell::new(false) }; }
fn device_error(error:wgpu::Error) {
    if CAPTURE_DEVICE_ERRORS.with(|flag|flag.get()) { std::panic::panic_any(DeviceFault(error.to_string())); }
    log::error!("Handling wgpu errors as fatal by default");
    panic!("wgpu error: {error}\n");
}
pub fn capture<T>(operation:impl FnOnce()->Result<T,String>)->Result<T,ReplayFailure>{
    struct Restore(bool);
    impl Drop for Restore { fn drop(&mut self) { CAPTURE_DEVICE_ERRORS.with(|flag|flag.set(self.0)); } }
    let _restore=Restore(CAPTURE_DEVICE_ERRORS.with(|flag|flag.replace(true)));
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(operation)) {
        Ok(result)=>result.map_err(ReplayFailure::Transport),
        Err(payload)=>match payload.downcast::<DeviceFault>() {
            Ok(fault)=>Err(ReplayFailure::Device(fault.0)),
            Err(other)=>std::panic::resume_unwind(other),
        }
    }
}
struct Runtime {
    _instance: wgpu::Instance,
    device: wgpu::Device,
    queue: wgpu::Queue,
    adapter_name: String,
    backend: String,
    lost: Arc<AtomicBool>,
}
fn platform_backends() -> wgpu::Backends {
    #[cfg(target_os = "macos")]
    {
        wgpu::Backends::METAL
    }
    #[cfg(target_os = "windows")]
    {
        wgpu::Backends::VULKAN | wgpu::Backends::DX12
    }
    #[cfg(not(any(target_os = "macos", target_os = "windows")))]
    {
        wgpu::Backends::VULKAN
    }
}
/// Query the compute adapter itself, not the smaller requested device limits.
pub fn limits()->Option<(String,String,u64,u32)>{
    let instance=wgpu::Instance::new(&wgpu::InstanceDescriptor{backends:platform_backends(),..Default::default()});
    let adapter=pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions::default()))?;
    let info=adapter.get_info();let limits=adapter.limits();
    Some((info.name,format!("{:?}",info.backend),limits.max_buffer_size,limits.max_storage_buffer_binding_size))
}
pub fn device_limits() -> Result<(u64,u32),String> {
    let r=runtime()?;
    let limits=r.device.limits();
    Ok((limits.max_buffer_size,limits.max_storage_buffer_binding_size))
}
pub fn info() -> Result<(String, String), String> {
    let r = runtime()?;
    Ok((r.adapter_name.clone(), r.backend.clone()))
}
static RUNTIME: crate::context_cache::ContextCache<Runtime> = crate::context_cache::ContextCache::new();
fn runtime() -> Result<Arc<Runtime>, String> {
    RUNTIME
        .get(|r| !r.lost.load(Ordering::Acquire), || {
            let instance = wgpu::Instance::new(&wgpu::InstanceDescriptor {
                backends: platform_backends(),
                ..Default::default()
            });
            let adapter = pollster::block_on(
                instance.request_adapter(&wgpu::RequestAdapterOptions::default()),
            )
            .ok_or("No supported compute adapter")?;
            let mut limits = wgpu::Limits::default();
            limits.max_storage_buffers_per_shader_stage = 8;
            // Recovered original request: promote only these two fields to the
            // selected adapter's capabilities. Preserve all other defaults.
            let available = adapter.limits();
            limits.max_storage_buffer_binding_size = available.max_storage_buffer_binding_size;
            limits.max_buffer_size = available.max_buffer_size;
            let (device, queue) = pollster::block_on(adapter.request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("recovery research"),
                    required_features: wgpu::Features::empty(),
                    required_limits: limits,
                    memory_hints: wgpu::MemoryHints::MemoryUsage,
                },
                None,
            ))
            .map_err(|e| e.to_string())?;
            let lost=Arc::new(AtomicBool::new(false));
            let signal=lost.clone();
            device.set_device_lost_callback(move |_,_|signal.store(true,Ordering::Release));
            device.on_uncaptured_error(Box::new(device_error));
            let info = adapter.get_info();
            Ok(Runtime {
                _instance: instance,
                lost,
                device,
                queue,
                adapter_name: info.name,
                backend: format!("{:?}", info.backend),
            })
        })
}
#[derive(Clone,Copy)]
pub struct StopPolicy {pub batch:u32,pub tolerance:f32,pub fraction:f32}
pub type ReplayResult=(Vec<u8>,u32,Vec<(u32,f32,u32)>);
pub fn replay(kind:&str,arrays:&[&[u8]],initial:&[u8],iterations:u32)->Result<Vec<u8>,String>{
    Ok(replay_inner(kind,arrays,initial,iterations,None,false)?.0)
}
pub fn replay_generated(kind:&str,arrays:&[&[u8]],initial:&[u8],iterations:u32)->Result<Vec<u8>,String>{
    Ok(replay_inner(kind,arrays,initial,iterations,None,true)?.0)
}
pub fn replay_auto(kind:&str,arrays:&[&[u8]],initial:&[u8],iterations:u32,policy:StopPolicy)->Result<ReplayResult,String>{
    if policy.batch==0 || !policy.tolerance.is_finite() || policy.tolerance<0.0 || !policy.fraction.is_finite() || !(0.0..=1.0).contains(&policy.fraction){return Err("invalid automatic stop policy".into());}
    if arrays.len()!=7 || arrays[6].len()<32 || iterations==0 {return Err("invalid automatic solver dimensions".into());}
    runtime()?; // retain context acquisition before transport preparation
    replay_inner(kind,arrays,initial,iterations,Some(policy),true)
}
/// Validate packed native-endian CSR inputs without owning a second graph.
/// Keep the existing CsrGraph validation order; float payloads are not decoded
/// because that validator checks their lengths, not their numerical values.
fn validate_packed_graph(rows: &[u8], columns: &[u8], weights: &[u8], diagonal: &[u8]) -> Result<usize, &'static str> {
    if [rows, columns, weights, diagonal].iter().any(|v| v.len() % 4 != 0) {
        return Err("unaligned buffer length");
    }
    let n = diagonal.len() / 4;
    let word = |v: &[u8]| u32::from_ne_bytes(v[..4].try_into().unwrap());
    if rows.len() / 4 != n + 1 || word(rows) != 0 {
        return Err("invalid CSR row boundaries");
    }
    if columns.len() != weights.len() || word(&rows[n * 4..]) as usize != columns.len() / 4 {
        return Err("CSR edge lengths differ");
    }
    if rows.chunks_exact(4).zip(rows[4..].chunks_exact(4)).any(|(a,b)| word(a) > word(b))
        || columns.chunks_exact(4).any(|v| word(v) as usize >= n) {
        return Err("CSR index outside graph");
    }
    Ok(n)
}
fn replay_inner(kind:&str,arrays:&[&[u8]],initial:&[u8],iterations:u32,policy:Option<StopPolicy>,generated:bool)->Result<ReplayResult,String>{
    let (code, entry) = match kind {
        "dense" => (include_str!("../../../recovered/dense.wgsl"), "matvec_h"),
        "sparse" => (
            include_str!("../../../recovered/sparse.wgsl"),
            "matvec_sparse",
        ),
        _ => return Err("expected dense or sparse".into()),
    };
    if arrays.len() != 7
        || iterations == 0
        || arrays[6].len() < if generated{32}else{iterations as usize * 256}
        || initial.is_empty()
        || initial.len() % 4 != 0
    {
        return Err("invalid captured field dimensions".into());
    }
    if arrays[..6].iter().any(|b| b.len() % 4 != 0) {
        return Err("unaligned buffer length".into());
    }
    let points = validate_packed_graph(&arrays[0], &arrays[1], &arrays[2], &arrays[3])?;
    let mut dimensions = None;
    for uniform in arrays[6].chunks_exact(if generated{32}else{256}).take(if generated{1}else{iterations as usize}) {
        let (points_param, slots, gx, seed_words, mask_words) = if kind == "dense" {
            let p = bytemuck::pod_read_unaligned::<crate::types::DenseParams>(&uniform[..32]);
            if p.bones == 0 || p.bones % 4 != 0 {
                return Err("invalid dense bone count".into());
            }
            (p.points, p.bones, p.grid_x, p.seed_words, 0)
        } else {
            let p = bytemuck::pod_read_unaligned::<crate::types::SparseParams>(&uniform[..32]);
            if p.slots != 16 {
                return Err("unsupported sparse slot count".into());
            }
            (p.points, p.slots, p.grid_x, p.seed_words, p.mask_words)
        };
        let cells = points
            .checked_mul(slots as usize)
            .ok_or("field dimension overflow")?;
        if points_param as usize != points
            || cells.checked_mul(2) != Some(initial.len())
            || cells > u32::MAX as usize
        {
            return Err("field type dimensions disagree".into());
        }
        let dispatch = (cells / (if kind == "dense" { 4 } else { 2 })).div_ceil(256);
        if gx as usize != dispatch.min(32768) || gx == 0 {
            return Err("unsupported dispatch grid".into());
        }
        let signature = (points_param, slots, gx, seed_words, mask_words);
        if dimensions.is_some_and(|v| v != signature) {
            return Err("uniform dimensions change during solve".into());
        }
        dimensions = Some(signature);
        let words = cells.div_ceil(32);
        if kind == "dense" {
            let seed_end = if seed_words == 0 {
                words
            } else {
                seed_words as usize + points.div_ceil(2)
            };
            if arrays[4].len() < words * 4 || arrays[5].len() < seed_end.max(words) * 4 {
                return Err("dense seed buffer is truncated".into());
            }
        } else {
            let seed_end = if seed_words == 0 {
                0
            } else {
                seed_words as usize + points.div_ceil(2)
            };
            if (mask_words as usize) < points.div_ceil(32)
                || arrays[4].len() < (mask_words as usize + words).max(seed_end) * 4
            {
                return Err("sparse bit buffer is truncated".into());
            }
            if arrays[5].len() != (arrays[1].len() / 4) * 16
                || arrays[5].iter().any(|&s| s >= 16 && s != 255)
            {
                return Err("sparse edge slots are invalid".into());
            }
        }
    }
    let rt = runtime()?;
    let d = &rt.device;
    let limits = d.limits();
    if arrays[..6]
        .iter()
        .any(|v| v.len() as u64 > u64::from(limits.max_storage_buffer_binding_size))
        || initial.len() as u64 > u64::from(limits.max_storage_buffer_binding_size)
        || arrays[6].len() as u64 > limits.max_buffer_size
    {
        return Err("captured data exceeds device limits".into());
    }
    let shader = d.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: None,
        source: wgpu::ShaderSource::Wgsl(Cow::Borrowed(code)),
    });
    let pipeline = d.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
        label: None,
        layout: None,
        module: &shader,
        entry_point: Some(entry),
        compilation_options: Default::default(),
        cache: None,
    });
    let static_buffers: Vec<_> = arrays[..6]
        .iter()
        .map(|v| {
            d.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: v,
                usage: wgpu::BufferUsages::STORAGE,
            })
        })
        .collect();
    let usage = wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_SRC | wgpu::BufferUsages::COPY_DST;
    let mut a = d.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: None,
        contents: initial,
        usage,
    });
    let mut b = d.create_buffer(&wgpu::BufferDescriptor {
        label: None,
        size: initial.len() as u64,
        usage,
        mapped_at_creation: false,
    });
    // Generated schedules use bounded slots: 32 automatic, 256 fixed.
    // Fixed chunks wait for completion to bound retained command resources.
    let uniform_slots=iterations.min(if policy.is_some(){32}else{256});
    let mut uniform_chunk=if generated{vec![0u8;uniform_slots as usize*256]}else{Vec::new()};
    let uniforms = d.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: None,
        contents: if generated{&uniform_chunk}else{&arrays[6]},
        usage: wgpu::BufferUsages::UNIFORM|wgpu::BufferUsages::COPY_DST,
    });
    let create_readback = || d.create_buffer(&wgpu::BufferDescriptor {
        label: None,
        size: initial.len() as u64,
        usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    // Fixed replay retains its existing allocation/submission schedule.
    // Automatic replay allocates final readback after the last convergence wait.
    let readback = if policy.is_none() { Some(create_readback()) } else { None };
    // Independent previous-checkpoint field and eight-byte convergence readback.
    let convergence=policy.map(|p|{
        let shader=d.create_shader_module(wgpu::ShaderModuleDescriptor{label:None,source:wgpu::ShaderSource::Wgsl(Cow::Borrowed(include_str!("../../../recovered/delta.wgsl")))});
        let pipe=d.create_compute_pipeline(&wgpu::ComputePipelineDescriptor{label:None,layout:None,module:&shader,entry_point:Some("max_delta"),compilation_options:Default::default(),cache:None});
        let previous=d.create_buffer_init(&wgpu::util::BufferInitDescriptor{label:None,contents:initial,usage});
        let delta=d.create_buffer(&wgpu::BufferDescriptor{label:None,size:8,usage,mapped_at_creation:false});
        let stage=d.create_buffer(&wgpu::BufferDescriptor{label:None,size:8,usage:wgpu::BufferUsages::COPY_DST|wgpu::BufferUsages::MAP_READ,mapped_at_creation:false});
        let words=(initial.len()/4) as u32;let gx=words.div_ceil(256).min(32768);
        let uniform=d.create_buffer_init(&wgpu::util::BufferInitDescriptor{label:None,contents:bytemuck::cast_slice(&[words,gx,p.tolerance.to_bits(),0]),usage:wgpu::BufferUsages::UNIFORM});
        (pipe,previous,delta,stage,uniform,gx,words.div_ceil(gx*256))
    });
    let mut enc = d.create_command_encoder(&Default::default());
    let mut history=Vec::new();let mut completed=0;let mut pending=false;let mut omega=1.0f32;
    for i in 0..iterations {
        crate::cancel::check();
        if generated && i%uniform_slots==0 {
            if pending {
                rt.queue.submit([enc.finish()]);
                // Fixed execution has no convergence readback to bound queued
                // command resources. Finish each chunk before recycling it.
                if policy.is_none() { d.poll(wgpu::Maintain::Wait); }
                enc=d.create_command_encoder(&Default::default());pending=false;
            }
            let count=(iterations-i).min(uniform_slots);
            for local in 0..count {
                let step=i+local;
                omega=if step==0{1.0}else if step==1{1.9609766}else{1.0/((omega * -0.98010004)*0.25+1.0)};
                let offset=local as usize*256;
                uniform_chunk[offset..offset+32].copy_from_slice(&arrays[6][..32]);
                uniform_chunk[offset+16..offset+20].copy_from_slice(&omega.to_le_bytes());
            }
            rt.queue.write_buffer(&uniforms,0,&uniform_chunk);
        }
        let uniform_index=if generated{i%uniform_slots}else{i};
        let mut bindings: Vec<_> = static_buffers
            .iter()
            .enumerate()
            .map(|(i, b)| wgpu::BindGroupEntry {
                binding: i as u32,
                resource: b.as_entire_binding(),
            })
            .collect();
        bindings.extend([
            wgpu::BindGroupEntry {
                binding: 6,
                resource: a.as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 7,
                resource: b.as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 8,
                resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                    buffer: &uniforms,
                    offset: u64::from(uniform_index) * 256,
                    size: wgpu::BufferSize::new(32),
                }),
            },
        ]);
        let bg = d.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &pipeline.get_bind_group_layout(0),
            entries: &bindings,
        });
        let gx = u32::from_le_bytes(
            arrays[6][if generated{8..12}else{i as usize*256+8..i as usize*256+12}]
                .try_into()
                .unwrap(),
        );
        {
            let mut pass = enc.begin_compute_pass(&Default::default());
            pass.set_pipeline(&pipeline);
            pass.set_bind_group(0, &bg, &[]);
            // Original dense and sparse hosts cap X at 32768 and carry the
            // remaining work in Y; shaders flatten through params.grid_x.
            let slots=dimensions.unwrap().1 as usize;
            let groups=(points*(slots/if kind=="dense"{4}else{2})).div_ceil(256);
            let gy=groups.div_ceil(gx as usize) as u32;
            pass.dispatch_workgroups(gx, gy, 1);
        }
        pending=true;
        std::mem::swap(&mut a, &mut b);
        completed=i+1;
        if let (Some(p),Some((pipe,previous,delta,stage,uniform,gx,gy)))=(policy,convergence.as_ref()){
            if completed%p.batch==0 || completed==iterations{
                enc.clear_buffer(delta,0,None);
                let entries=[&a,previous,delta,uniform].iter().enumerate().map(|(i,b)|wgpu::BindGroupEntry{binding:i as u32,resource:b.as_entire_binding()}).collect::<Vec<_>>();
                let bg=d.create_bind_group(&wgpu::BindGroupDescriptor{label:None,layout:&pipe.get_bind_group_layout(0),entries:&entries});
                {let mut pass=enc.begin_compute_pass(&Default::default());pass.set_pipeline(pipe);pass.set_bind_group(0,&bg,&[]);pass.dispatch_workgroups(*gx,*gy,1);}
                enc.copy_buffer_to_buffer(&a,0,previous,0,initial.len() as u64);
                enc.copy_buffer_to_buffer(delta,0,stage,0,8);
                rt.queue.submit([enc.finish()]);pending=false;
                let raw=read_mapped(d,stage)?;
                let delta=f32::from_le_bytes(raw[..4].try_into().unwrap());let moving=u32::from_le_bytes(raw[4..].try_into().unwrap());
                history.push((completed,delta,moving));
                enc=d.create_command_encoder(&Default::default());
                if delta<=p.tolerance || moving as f64<=p.fraction as f64*(initial.len()/2) as f64{break;}
            }
        }
    }
    let readback = match readback {
        Some(buffer) => buffer,
        None => {
            // Every automatic exit is a completed checkpoint, including a cap
            // shorter than its batch. Do not destroy buffers with queued work.
            assert!(!pending, "automatic final readback requires completed checkpoint");
            b.destroy();
            if let Some((_,previous,_,_,_,_,_)) = convergence.as_ref() { previous.destroy(); }
            create_readback()
        }
    };
    enc.copy_buffer_to_buffer(&a, 0, &readback, 0, initial.len() as u64);
    rt.queue.submit([enc.finish()]);
    Ok((read_mapped(d,&readback)?,completed,history))
}
fn read_mapped(d:&wgpu::Device,readback:&wgpu::Buffer)->Result<Vec<u8>,String>{
    crate::readback::read(d,readback,CAPTURE_DEVICE_ERRORS.with(|flag|flag.get()))
}

/// Owned mesh-generated winding buffers; only called by the checked mesh wrapper.
pub fn winding(nodes:&[u8],triangles:&[u8],points:&[u8])->Result<Vec<u8>,String>{
    if points.is_empty(){return Ok(Vec::new());}
    if nodes.is_empty(){return Ok(vec![0;points.len()/3]);}
    let r=runtime()?;let d=&r.device;
    let size=(points.len()/3) as u64;
    if [nodes.len(),triangles.len(),points.len(),size as usize].iter().any(|&n|n>d.limits().max_storage_buffer_binding_size as usize){return Err("winding buffers exceed device limits".into());}
    let buffers:Vec<_>=[nodes,triangles,points].into_iter().map(|bytes|d.create_buffer_init(&wgpu::util::BufferInitDescriptor{label:Some("recovered winding input"),contents:bytes,usage:wgpu::BufferUsages::STORAGE})).collect();
    let output=d.create_buffer(&wgpu::BufferDescriptor{label:Some("recovered winding output"),size,usage:wgpu::BufferUsages::STORAGE|wgpu::BufferUsages::COPY_SRC,mapped_at_creation:false});
    let readback=d.create_buffer(&wgpu::BufferDescriptor{label:Some("recovered winding readback"),size,usage:wgpu::BufferUsages::MAP_READ|wgpu::BufferUsages::COPY_DST,mapped_at_creation:false});
    let shader=d.create_shader_module(wgpu::ShaderModuleDescriptor{label:Some("recovered winding"),source:wgpu::ShaderSource::Wgsl(Cow::Borrowed(include_str!("../../../recovered/winding.wgsl")))});
    let pipe=d.create_compute_pipeline(&wgpu::ComputePipelineDescriptor{label:None,layout:None,module:&shader,entry_point:Some("main"),compilation_options:Default::default(),cache:None});
    let entries:Vec<_>=buffers.iter().chain([&output]).enumerate().map(|(i,b)|wgpu::BindGroupEntry{binding:i as u32,resource:b.as_entire_binding()}).collect();
    let bind=d.create_bind_group(&wgpu::BindGroupDescriptor{label:None,layout:&pipe.get_bind_group_layout(0),entries:&entries});
    let groups=(points.len()/12).div_ceil(64) as u32;let gx=groups.min(65535);let gy=groups.div_ceil(gx);
    if gy>65535{return Err("winding dispatch exceeds device limits".into());}
    let mut enc=d.create_command_encoder(&Default::default());
    {let mut pass=enc.begin_compute_pass(&wgpu::ComputePassDescriptor{label:None,timestamp_writes:None});pass.set_pipeline(&pipe);pass.set_bind_group(0,&bind,&[]);pass.dispatch_workgroups(gx,gy,1);}
    enc.copy_buffer_to_buffer(&output,0,&readback,0,size);r.queue.submit([enc.finish()]);read_mapped(d,&readback)
}

/// Detector-owned immutable geometry. The device lease keeps its buffers and
/// pipeline together. No process-global mesh or query-result cache is created.
pub struct PreparedWinding {
    owner: Arc<Runtime>,
    nodes: wgpu::Buffer,
    triangles: wgpu::Buffer,
    pipeline: wgpu::ComputePipeline,
}
impl PreparedWinding {
    pub fn new(nodes:&[u8],triangles:&[u8])->Result<Self,String>{
        let owner=runtime()?;let d=&owner.device;
        if [nodes.len(),triangles.len()].iter().any(|&n|n>d.limits().max_storage_buffer_binding_size as usize){return Err("winding buffers exceed device limits".into());}
        let upload=|bytes:&[u8]|d.create_buffer_init(&wgpu::util::BufferInitDescriptor{label:Some("prepared winding geometry"),contents:bytes,usage:wgpu::BufferUsages::STORAGE});
        let nodes=upload(nodes);let triangles=upload(triangles);
        let shader=d.create_shader_module(wgpu::ShaderModuleDescriptor{label:Some("prepared winding"),source:wgpu::ShaderSource::Wgsl(Cow::Borrowed(include_str!("../../../recovered/winding.wgsl")))});
        let pipeline=d.create_compute_pipeline(&wgpu::ComputePipelineDescriptor{label:None,layout:None,module:&shader,entry_point:Some("main"),compilation_options:Default::default(),cache:None});
        Ok(Self{owner,nodes,triangles,pipeline})
    }
    pub fn healthy(&self)->bool{!self.owner.lost.load(Ordering::Acquire)}
    pub fn query(&self,points:&[u8])->Result<Vec<u8>,String>{
        if points.is_empty(){return Ok(Vec::new());}
        let r=&self.owner;let d=&r.device;let size=(points.len()/3) as u64;
        if [points.len(),size as usize].iter().any(|&n|n>d.limits().max_storage_buffer_binding_size as usize){return Err("winding buffers exceed device limits".into());}
        let points=d.create_buffer_init(&wgpu::util::BufferInitDescriptor{label:Some("prepared winding points"),contents:points,usage:wgpu::BufferUsages::STORAGE});
        let output=d.create_buffer(&wgpu::BufferDescriptor{label:None,size,usage:wgpu::BufferUsages::STORAGE|wgpu::BufferUsages::COPY_SRC,mapped_at_creation:false});
        let readback=d.create_buffer(&wgpu::BufferDescriptor{label:None,size,usage:wgpu::BufferUsages::MAP_READ|wgpu::BufferUsages::COPY_DST,mapped_at_creation:false});
        let entries:Vec<_>=[&self.nodes,&self.triangles,&points,&output].into_iter().enumerate().map(|(i,b)|wgpu::BindGroupEntry{binding:i as u32,resource:b.as_entire_binding()}).collect();
        let bind=d.create_bind_group(&wgpu::BindGroupDescriptor{label:None,layout:&self.pipeline.get_bind_group_layout(0),entries:&entries});
        let groups=(size/4).div_ceil(64) as u32;let gx=groups.min(65535);let gy=groups.div_ceil(gx);
        if gy>65535{return Err("winding dispatch exceeds device limits".into());}
        let mut enc=d.create_command_encoder(&Default::default());
        {let mut pass=enc.begin_compute_pass(&wgpu::ComputePassDescriptor{label:None,timestamp_writes:None});pass.set_pipeline(&self.pipeline);pass.set_bind_group(0,&bind,&[]);pass.dispatch_workgroups(gx,gy,1);}
        enc.copy_buffer_to_buffer(&output,0,&readback,0,size);r.queue.submit([enc.finish()]);read_mapped(d,&readback)
    }
}
