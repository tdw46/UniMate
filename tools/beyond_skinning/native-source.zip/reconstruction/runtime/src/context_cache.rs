//! Retain healthy contexts; failed initialization and lost devices are retryable.
use std::sync::{Arc,Mutex};
pub struct ContextCache<T>{slot:Mutex<Option<Arc<T>>>}
impl<T> ContextCache<T>{
    pub const fn new()->Self{Self{slot:Mutex::new(None)}}
    pub fn get<E>(&self,healthy:impl Fn(&T)->bool,create:impl FnOnce()->Result<T,E>)->Result<Arc<T>,E>{
        // A panic during construction must not permanently poison later retry.
        let mut slot=self.slot.lock().unwrap_or_else(|e|e.into_inner());
        if let Some(value)=slot.as_ref(){if healthy(value){return Ok(value.clone());}}
        *slot=None;
        let value=Arc::new(create()?);
        *slot=Some(value.clone());
        Ok(value)
    }
}
