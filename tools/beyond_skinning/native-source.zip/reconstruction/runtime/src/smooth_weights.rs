//! Standalone smoothing: recovered public extraction and ordered f32 arithmetic.
use numpy::{PyReadonlyArray1,PyReadonlyArray2,PyArray2};
use pyo3::{prelude::*,exceptions::PyRuntimeError,panic::PanicException};
use std::collections::HashMap;
#[pyfunction]
#[pyo3(signature=(weights,bones,edges,selected,factor,repeat,limit))]
pub fn smooth_weights<'py>(py:Python<'py>,weights:PyReadonlyArray2<'py,f32>,bones:PyReadonlyArray2<'py,i32>,edges:PyReadonlyArray2<'py,i64>,selected:PyReadonlyArray1<'py,bool>,factor:f32,repeat:u32,limit:usize)->PyResult<(Bound<'py,PyArray2<f32>>,Bound<'py,PyArray2<i32>>)>{
 let w=crate::array_input::two(&weights);let b=crate::array_input::two(&bones);let mask=crate::array_input::one(&selected);
 if w.dim()!=b.dim(){return Err(PyRuntimeError::new_err("weights and bones must have the same shape"));}
 let (n,k)=w.dim();if mask.len()!=n{return Err(PyRuntimeError::new_err("selected must have one entry per vertex"));}
 let mut ow=ndarray::Array2::from_shape_fn((n,k),|ij|w[ij]);let mut ob=ndarray::Array2::from_shape_fn((n,k),|ij|b[ij]);
 let e=crate::array_input::two(&edges);
 if e.nrows()>0&&e.ncols()<2{return Err(PanicException::new_err("ndarray: index out of bounds"));}
 if n>0&&k>0&&repeat>0&&!(factor<=0.)&&mask.iter().any(|&v|v) {
  let mut near=vec![Vec::new();n];
  for row in e.rows(){let (a,z)=(row[0],row[1]);if a>=0&&z>=0&&(a as usize)<n&&(z as usize)<n&&a!=z{near[a as usize].push(z as usize);near[z as usize].push(a as usize);}}
  let mut rows:Vec<HashMap<i32,f32>>=(0..n).map(|i|{let mut r=HashMap::new();for j in 0..k{if b[(i,j)]>=0&&w[(i,j)]>0.{*r.entry(b[(i,j)]).or_insert(0.)+=w[(i,j)];}}r}).collect();
  for _ in 0..repeat{
   let mut next=rows.clone();
   for i in 0..n{if !mask[i]||near[i].is_empty(){continue;}
    let mut r=HashMap::new();let inv=1.0f32/near[i].len() as f32;
    for (&id,&v) in &rows[i]{r.insert(id,(1.0-factor)*v);}
    for &j in &near[i]{for (&id,&v) in &rows[j]{*r.entry(id).or_insert(0.)+=inv*(factor*v);}}
    r.retain(|_,v|*v>0.);next[i]=r;
   }rows=next;
  }
  for i in 0..n{if !mask[i]{continue;}
   let total=rows[i].values().fold(-0.0f32,|a,&v|a+v);
   let mut pairs:Vec<_>=rows[i].iter().map(|(&id,&v)|(id,if total>0.{v/total}else{v})).collect();
   pairs.sort_by(|a,b|b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal).then_with(||b.0.cmp(&a.0)));
   for j in 0..k{ow[(i,j)]=0.;ob[(i,j)]=-1;}
   for (j,(id,v)) in pairs.into_iter().take(limit.min(k)).enumerate(){ow[(i,j)]=v;ob[(i,j)]=id;}
  }
 }
 Ok((PyArray2::from_owned_array(py,ow),PyArray2::from_owned_array(py,ob)))
}
