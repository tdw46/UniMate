//! Sorted unique mouth adjacency and strict f32 distance construction.
//! Borrow inputs under the GIL, no RNG or shared state. Admission stays in Python.
use numpy::PyReadonlyArray2;
use pyo3::{prelude::*,exceptions::PyValueError};
#[pyfunction]
pub fn mouth_mesh_graph(vertices:PyReadonlyArray2<'_,f32>,edges:PyReadonlyArray2<'_,i64>)->PyResult<(Vec<usize>,Vec<usize>,Vec<f32>)>{
 let v=crate::array_input::two(&vertices);let e=crate::array_input::two(&edges);
 if v.ncols()!=3 || e.ncols()!=2 {return Err(PyValueError::new_err("mouth graph shape mismatch"));}
 let n=v.nrows();let mut adj=vec![Vec::<usize>::new();n];
 for edge in e.rows(){let (a,b)=(edge[0],edge[1]);
  if a<0 || b<0 || a as usize>=n || b as usize>=n {return Err(PyValueError::new_err("edge outside vertices"));}
  if a!=b {adj[a as usize].push(b as usize);adj[b as usize].push(a as usize);}
 }
 let mut rows=Vec::with_capacity(n+1);let mut columns=Vec::new();let mut weights=Vec::new();rows.push(0);
 for (i,near) in adj.iter_mut().enumerate(){
  near.sort_unstable();near.dedup();
  for &j in near.iter(){
   let x=v[(i,0)]-v[(j,0)];let y=v[(i,1)]-v[(j,1)];let z=v[(i,2)]-v[(j,2)];
   let distance=((x*x+y*y)+z*z).sqrt();
   columns.push(j);weights.push(distance);
  }
  rows.push(columns.len());
 }
 Ok((rows,columns,weights))
}
