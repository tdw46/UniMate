//! Adaptive graph contraction, recovered from 0x92454/0x922dc/0x199364.
//! Finite bounded input only; no original library or external runtime calls.
use numpy::{IntoPyArray, PyReadonlyArray1, PyReadonlyArray2};
use pyo3::{exceptions::PyValueError, prelude::*, types::PyDict};
use std::collections::{BTreeMap, HashMap, VecDeque};

#[pyfunction]
#[pyo3(signature=(points,radii,max_radius,rows,columns,weights,fixed,labels,values,bones,dense=None,level=0))]
pub fn coarsen_level_graph<'py>(py:Python<'py>,points:PyReadonlyArray2<'py,f32>,radii:PyReadonlyArray1<'py,f32>,max_radius:f32,rows:PyReadonlyArray1<'py,u32>,columns:PyReadonlyArray1<'py,u32>,weights:PyReadonlyArray1<'py,f32>,fixed:PyReadonlyArray1<'py,u8>,labels:PyReadonlyArray1<'py,u32>,values:PyReadonlyArray1<'py,f32>,bones:usize,dense:Option<PyReadonlyArray2<'py,f32>>,level:u8)->PyResult<Bound<'py,PyDict>>{
 coarsen_owned(py,points,radii,max_radius,rows,columns,weights,fixed,labels,values,bones,dense,level,false,usize::MAX)
}

#[pyfunction]
#[pyo3(signature=(points,radii,max_radius,rows,columns,weights,fixed,labels,values,bones,dense=None,level=0,scratch_budget=134217728))]
pub fn coarsen_level_array<'py>(py:Python<'py>,points:PyReadonlyArray2<'py,f32>,radii:PyReadonlyArray1<'py,f32>,max_radius:f32,rows:PyReadonlyArray1<'py,u32>,columns:PyReadonlyArray1<'py,u32>,weights:PyReadonlyArray1<'py,f32>,fixed:PyReadonlyArray1<'py,u8>,labels:PyReadonlyArray1<'py,u32>,values:PyReadonlyArray1<'py,f32>,bones:usize,dense:Option<PyReadonlyArray2<'py,f32>>,level:u8,scratch_budget:usize)->PyResult<Bound<'py,PyDict>>{
 coarsen_owned(py,points,radii,max_radius,rows,columns,weights,fixed,labels,values,bones,dense,level,true,scratch_budget)
}

fn coarsen_owned<'py>(py:Python<'py>,points:PyReadonlyArray2<'py,f32>,radii:PyReadonlyArray1<'py,f32>,max_radius:f32,rows:PyReadonlyArray1<'py,u32>,columns:PyReadonlyArray1<'py,u32>,weights:PyReadonlyArray1<'py,f32>,fixed:PyReadonlyArray1<'py,u8>,labels:PyReadonlyArray1<'py,u32>,values:PyReadonlyArray1<'py,f32>,bones:usize,dense:Option<PyReadonlyArray2<'py,f32>>,level:u8,public_array:bool,scratch_budget:usize)->PyResult<Bound<'py,PyDict>>{
 let p=points.as_array();let r=radii.as_slice()?;let rs=rows.as_slice()?;let cs=columns.as_slice()?;let w=weights.as_slice()?;let f=fixed.as_slice()?;let ids=labels.as_slice()?;let val=values.as_slice()?;let n=p.nrows();
 if n==0 || (!public_array && n>100_000) || p.ncols()!=3 || r.len()!=n || f.len()!=n || ids.len()!=n || val.len()!=n || rs.len()!=n+1 || rs[0]!=0 || rs[n] as usize!=cs.len() || w.len()!=cs.len() || rs.windows(2).any(|a|a[0]>a[1]) || cs.iter().any(|&c|c as usize>=n) || !max_radius.is_finite() || p.iter().chain(r).chain(w).chain(val).any(|x|!x.is_finite()) || f.iter().any(|&a|a>1) || bones==0 || bones>65534 {return Err(PyValueError::new_err("invalid bounded level graph"))}
 let d=dense.as_ref().map(|a|a.as_array());
 if let Some(ref d)=d{if d.nrows()!=n || d.ncols()!=bones || d.iter().any(|x|!x.is_finite()) {return Err(PyValueError::new_err("invalid dense seed field"))}}
 // Admission includes hash-table/member storage, grown output vectors and a
 // bounded per-region edge accumulator. Check before any graph allocation.
 if public_array {
  let bytes=n.saturating_mul(224);
  if bytes>scratch_budget || cs.len()>u32::MAX as usize {return Err(PyValueError::new_err("coarse graph working-set budget exceeded"))}
  crate::cancel::check();
 }
 let cell=((max_radius+max_radius)/1.7320508f32).max(1e-6);
 let mut cells:HashMap<[i32;3],usize>=HashMap::new();
 for i in 0..n{
  if public_array && i%1024==0 {crate::cancel::check();}
  let mut key=[0i32;3];for j in 0..3{let x=(p[[i,j]]/cell).floor();if !x.is_finite() || x.abs()>2147483000. {return Err(PyValueError::new_err("level cell outside bounded integer range"))}key[j]=x as i32;}
  cells.entry(key).and_modify(|old|{if (f[i]==1 && f[*old]==0) || (f[i]==f[*old] && r[i]>r[*old]){*old=i}}).or_insert(i);
 }
 let mut reps:Vec<usize>=cells.into_values().collect();reps.sort_unstable();
 let mut mapping=vec![u32::MAX;n];let mut queue=VecDeque::new();
 for (j,&i) in reps.iter().enumerate(){mapping[i]=j as u32;queue.push_back(i);}
 fn flood(queue:&mut VecDeque<usize>,mapping:&mut [u32],rs:&[u32],cs:&[u32]){while let Some(i)=queue.pop_front(){for e in rs[i] as usize..rs[i+1] as usize{let j=cs[e] as usize;if mapping[j]==u32::MAX{mapping[j]=mapping[i];queue.push_back(j);}}}}
 flood(&mut queue,&mut mapping,rs,cs);
 for i in 0..n{if mapping[i]==u32::MAX{mapping[i]=reps.len() as u32;reps.push(i);queue.push_back(i);flood(&mut queue,&mut mapping,rs,cs);}}
 let mut members=vec![Vec::new();reps.len()];for i in 0..n{members[mapping[i] as usize].push(i);}
 // Count distinct outgoing region pairs, not fine edges that disappear in
 // contraction. Stamps are bounded by representative count and dropped before
 // the floating-point accumulator. This pass performs no weight arithmetic.
 let (edge_capacity,max_region_edges)=if public_array {
  let preflight=n.saturating_mul(224).saturating_add(reps.len().saturating_mul(8));
  if preflight>scratch_budget{return Err(PyValueError::new_err("coarse graph working-set budget exceeded"))}
  let mut seen=vec![usize::MAX;reps.len()];let mut count=0usize;let mut maximum=0usize;
  for (region,member) in members.iter().enumerate(){
   if region%1024==0{crate::cancel::check();}
   let mut distinct=0usize;
   for &i in member {for e in rs[i] as usize..rs[i+1] as usize {
    let target=mapping[cs[e] as usize] as usize;
    if target!=region && seen[target]!=region{seen[target]=region;distinct+=1;}
   }}
   count=count.saturating_add(distinct);maximum=maximum.max(distinct);
  }
  (count,maximum)
 }else{(cs.len(),members.iter().map(|member|member.iter().fold(0usize,|s,&i|s.saturating_add((rs[i+1]-rs[i]) as usize))).max().unwrap_or(0))};
 let scratch_bytes=if public_array {
  // Fixed output capacities avoid Vec geometric growth; only one BTree is
  // alive. Keep conservative member/queue/hash reserves and stamp storage.
  n.saturating_mul(224).saturating_add(reps.len().saturating_mul(8)).saturating_add(edge_capacity.saturating_mul(8)).saturating_add(max_region_edges.saturating_mul(64)).saturating_add(if d.is_some(){reps.len().saturating_mul(bones).saturating_mul(4)}else{0})
 }else{n.saturating_mul(224).saturating_add(cs.len().saturating_mul(24)).saturating_add(max_region_edges.saturating_mul(64)).saturating_add(if d.is_some(){n.saturating_mul(bones).saturating_mul(8)}else{0})};
 if public_array && scratch_bytes>scratch_budget {return Err(PyValueError::new_err("coarse graph working-set budget exceeded"))}
 let mut out_rows=Vec::with_capacity(if public_array{reps.len()+1}else{0});out_rows.push(0u32);
 let mut out_columns=Vec::with_capacity(if public_array{edge_capacity}else{0});let mut out_weights=Vec::with_capacity(if public_array{edge_capacity}else{0});let mut diagonal=Vec::with_capacity(if public_array{reps.len()}else{0});
 // The public array route already reserves eight bytes per representative
 // and 64 bytes per outgoing region in scratch_bytes. Reuse that envelope for
 // stamped sums (8/representative) and sorted touched IDs (4/outgoing region),
 // replacing per-edge BTree searches without changing accumulation order.
 if public_array && reps.len()<u32::MAX as usize {
  let mut stamps=vec![u32::MAX;reps.len()];let mut sums=vec![0.0f32;reps.len()];
  let mut touched=Vec::<u32>::with_capacity(max_region_edges);
  for (region,member) in members.iter().enumerate(){
   if region%1024==0{crate::cancel::check();}touched.clear();
   for &i in member{for e in rs[i] as usize..rs[i+1] as usize{
    let target=mapping[cs[e] as usize];let j=target as usize;
    if j==region{continue;}
    if stamps[j]!=region as u32{stamps[j]=region as u32;sums[j]=0.0;touched.push(target);}
    sums[j]+=w[e];
   }}
   touched.sort_unstable();let mut sum=-0.0f32;
   for &j in &touched{let weight=sums[j as usize];out_columns.push(j);out_weights.push(weight);sum+=weight;}
   out_rows.push(out_columns.len() as u32);diagonal.push(if sum<=1e-12{0.0}else{1.0/sum});
  }
 }else{
  for (region,member) in members.iter().enumerate(){if public_array && region%1024==0 {crate::cancel::check();}let mut edges:BTreeMap<u32,f32>=BTreeMap::new();for &i in member{for e in rs[i] as usize..rs[i+1] as usize{let j=mapping[cs[e] as usize];if j as usize!=region{*edges.entry(j).or_insert(0.)+=w[e];}}}
   let mut sum=-0.0f32;for (j,weight) in edges{out_columns.push(j);out_weights.push(weight);sum+=weight;}
   out_rows.push(out_columns.len() as u32);diagonal.push(if sum<=1e-12 {0.}else{1./sum});
  }
 }
 let out_fixed:Vec<u8>=reps.iter().map(|&i|f[i]).collect();let mut out_labels=Vec::with_capacity(if public_array{reps.len()}else{0});let mut out_values=Vec::with_capacity(if public_array{reps.len()}else{0});let mut out_dense=Vec::with_capacity(if public_array && d.is_some(){reps.len()*bones}else{0});
 for &i in &reps{if let Some(ref d)=d{let mut best=u32::MAX;let mut value=0.0f32;for b in 0..bones{let x=d[[i,b]];out_dense.push(x);if x>value{best=b as u32;value=x;}}out_labels.push(best);out_values.push(value);}else{out_labels.push(ids[i]);out_values.push(val[i]);}}
 let out=PyDict::new(py);out.set_item("representatives",reps.into_iter().map(|v|v as u64).collect::<Vec<_>>().into_pyarray(py))?;out.set_item("mapping",mapping.into_pyarray(py))?;out.set_item("rows",out_rows.into_pyarray(py))?;out.set_item("columns",out_columns.into_pyarray(py))?;out.set_item("weights",out_weights.into_pyarray(py))?;out.set_item("diagonal",diagonal.into_pyarray(py))?;out.set_item("fixed",out_fixed.into_pyarray(py))?;out.set_item("labels",out_labels.into_pyarray(py))?;out.set_item("values",out_values.into_pyarray(py))?;
 if d.is_some(){out.set_item("dense",out_dense.into_pyarray(py))?}else{out.set_item("dense",py.None())?}out.set_item("cell",cell)?;out.set_item("level",level)?;if public_array{out.set_item("scratch_estimate_bytes",scratch_bytes)?;}Ok(out)
}

/// Interlevel mapping (0x5cb40): self region plus weighted graph neighbors.
fn interlevel_owned(rows:PyReadonlyArray1<'_,u32>,columns:PyReadonlyArray1<'_,u32>,weights:PyReadonlyArray1<'_,f32>,mapping:PyReadonlyArray1<'_,u32>,queries:PyReadonlyArray1<'_,u64>,public_array:bool,scratch_budget:usize)->PyResult<(Vec<u32>,Vec<f32>)>{
 let rs=rows.as_slice()?;let cs=columns.as_slice()?;let w=weights.as_slice()?;let m=mapping.as_slice()?;let q=queries.as_slice()?;let n=m.len();
 if (!public_array && (n>100_000 || q.len()>100_000)) || rs.len()!=n+1 || rs[0]!=0 || rs[n] as usize!=cs.len() || w.len()!=cs.len() || rs.windows(2).any(|a|a[0]>a[1]) || cs.iter().any(|&c|c as usize>=n) || q.iter().any(|&i|i as usize>=n) || w.iter().any(|x|!x.is_finite()){return Err(PyValueError::new_err("invalid bounded interlevel map"))}
 if public_array {
  let max_degree=rs.windows(2).map(|a|(a[1]-a[0]) as usize).max().unwrap_or(0);
  let bytes=q.len().saturating_mul(32).saturating_add(max_degree.saturating_add(1).saturating_mul(64));
  if bytes>scratch_budget {return Err(PyValueError::new_err("interlevel map resource budget exceeded"))}
  crate::cancel::check();
 }
 let mut ids=vec![u32::MAX;q.len()*4];let mut values=vec![0.;q.len()*4];
 let mut selected=Vec::new();let mut slots=rustc_hash::FxHashMap::default();
 for (row,&query) in q.iter().enumerate(){
  if public_array && row%1024==0 {crate::cancel::check();}
  let i=query as usize;let start=rs[i] as usize;let end=rs[i+1] as usize;let mut sum=-0.0f32;for &weight in &w[start..end]{sum+=weight;}
  selected.clear();selected.push((m[i],1.0f32));
  slots.clear();slots.insert(m[i],0usize);
  if sum>1e-12{for edge in start..end{let id=m[cs[edge] as usize];let weight=w[edge]/sum;
   if let Some(&slot)=slots.get(&id){selected[slot].1+=weight;}else{slots.insert(id,selected.len());selected.push((id,weight));}}
   selected.sort_by(|a,b|b.1.partial_cmp(&a.1).unwrap().then(a.0.cmp(&b.0)));
  }
  for (j,(id,value)) in selected.iter().copied().take(4).enumerate(){ids[row*4+j]=id;values[row*4+j]=value;}
 }Ok((ids,values))
}
#[pyfunction]
pub fn build_interlevel_map(rows:PyReadonlyArray1<'_,u32>,columns:PyReadonlyArray1<'_,u32>,weights:PyReadonlyArray1<'_,f32>,mapping:PyReadonlyArray1<'_,u32>,queries:PyReadonlyArray1<'_,u64>)->PyResult<(Vec<Vec<u32>>,Vec<Vec<f32>>)>{
 let (ids,values)=interlevel_owned(rows,columns,weights,mapping,queries,false,usize::MAX)?;
 Ok((ids.chunks(4).map(|r|r.to_vec()).collect(),values.chunks(4).map(|r|r.to_vec()).collect()))
}
#[pyfunction]
#[pyo3(signature=(rows,columns,weights,mapping,queries,scratch_budget=67108864))]
pub fn build_interlevel_arrays<'py>(py:Python<'py>,rows:PyReadonlyArray1<'py,u32>,columns:PyReadonlyArray1<'py,u32>,weights:PyReadonlyArray1<'py,f32>,mapping:PyReadonlyArray1<'py,u32>,queries:PyReadonlyArray1<'py,u64>,scratch_budget:usize)->PyResult<(Bound<'py,numpy::PyArray2<u32>>,Bound<'py,numpy::PyArray2<f32>>)>{
 let n=queries.len()?;
 let (ids,values)=interlevel_owned(rows,columns,weights,mapping,queries,true,scratch_budget)?;
 Ok((ndarray::Array2::from_shape_vec((n,4),ids).unwrap().into_pyarray(py),ndarray::Array2::from_shape_vec((n,4),values).unwrap().into_pyarray(py)))
}
